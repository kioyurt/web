

import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import styles from './styles.module.css';

const CommunityOverviewPage: React.FC = () => {
  const navigate = useNavigate();
  const [globalSearchValue, setGlobalSearchValue] = useState('');

  useEffect(() => {
    const originalTitle = document.title;
    document.title = '社区概览 - 模学苑';
    return () => { document.title = originalTitle; };
  }, []);

  const handleGlobalSearchKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      const keyword = globalSearchValue.trim();
      if (keyword) {
        navigate(`/search-results?q=${encodeURIComponent(keyword)}`);
      }
    }
  };

  const handleDiscussionEntranceClick = () => {
    navigate('/discussion-forum');
  };

  const handleQaEntranceClick = () => {
    navigate('/question-answer');
  };

  const handleStudyGroupEntranceClick = () => {
    navigate('/study-group-list');
  };

  const handleDiscussionPostClick = (postId: number) => {
    navigate(`/discussion-forum?postId=${postId}`);
  };

  const handleQaQuestionClick = (questionId: number) => {
    navigate(`/question-answer?questionId=${questionId}`);
  };

  const handleStudyGroupCardClick = (groupId: number) => {
    navigate(`/study-group-detail?groupId=${groupId}`);
  };

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <header className="fixed top-0 left-0 right-0 bg-white/90 backdrop-blur-md border-b border-border-light z-50">
        <div className="flex items-center justify-between px-6 py-3">
          {/* Logo区域 */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-primary rounded-xl flex items-center justify-center">
              <i className="fas fa-graduation-cap text-white text-lg"></i>
            </div>
            <h1 className={`text-xl font-bold ${styles.gradientText}`}>模学苑</h1>
          </div>
          
          {/* 主导航 */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/home" className="text-text-secondary hover:text-primary py-1 transition-colors">首页</Link>
            <Link to="/course-list" className="text-text-secondary hover:text-primary py-1 transition-colors">课程</Link>
            <span className="text-primary font-medium border-b-2 border-primary py-1">社区</span>
            <Link to="/resource-center" className="text-text-secondary hover:text-primary py-1 transition-colors">资源中心</Link>
          </nav>
          
          {/* 搜索和用户区域 */}
          <div className="flex items-center space-x-4">
            {/* 全局搜索 */}
            <div className="relative hidden lg:block">
              <input 
                type="text" 
                placeholder="搜索课程、资源..." 
                value={globalSearchValue}
                onChange={(e) => setGlobalSearchValue(e.target.value)}
                onKeyPress={handleGlobalSearchKeyPress}
                className="w-80 pl-10 pr-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary"></i>
            </div>
            
            {/* 消息通知 */}
            <button className="relative p-2 text-text-secondary hover:text-primary transition-colors">
              <i className="fas fa-bell text-lg"></i>
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-danger rounded-full"></span>
            </button>
            
            {/* 用户头像 */}
            <div className="flex items-center space-x-2 cursor-pointer">
              <img 
                src="https://s.coze.cn/image/KNo7yPof_g4/" 
                alt="用户头像" 
                className="w-8 h-8 rounded-full border-2 border-primary/20"
              />
              <span className="hidden md:block text-text-primary font-medium">张同学</span>
              <i className="fas fa-chevron-down text-text-secondary text-sm"></i>
            </div>
          </div>
        </div>
      </header>

      <div className="flex pt-16">
        {/* 左侧菜单 */}
        <aside className={`fixed left-0 top-16 bottom-0 w-60 ${styles.sidebarGradient} text-white overflow-y-auto`}>
          <div className="p-4">
            <nav className="space-y-2">
              <Link to="/home" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-home text-lg"></i>
                <span>首页</span>
              </Link>
              <Link to="/course-list" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-book text-lg"></i>
                <span>课程中心</span>
              </Link>
              <div className="flex items-center space-x-3 px-4 py-3 rounded-xl bg-white/20 backdrop-blur-sm">
                <i className="fas fa-users text-lg"></i>
                <span className="font-medium">社区互动</span>
              </div>
              <Link to="/resource-center" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-database text-lg"></i>
                <span>资源中心</span>
              </Link>
              <Link to="/user-profile" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-user text-lg"></i>
                <span>个人中心</span>
              </Link>
            </nav>
            
            {/* 学习进度卡片 */}
            <div className="mt-8 p-4 bg-white/10 backdrop-blur-sm rounded-xl">
              <h3 className="font-semibold mb-3">今日学习</h3>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>进度</span>
                  <span>75%</span>
                </div>
                <div className="w-full bg-white/20 rounded-full h-2">
                  <div className="bg-white h-2 rounded-full" style={{width: '75%'}}></div>
                </div>
                <div className="flex justify-between text-sm">
                  <span>已学时长</span>
                  <span>2.5小时</span>
                </div>
              </div>
            </div>
          </div>
        </aside>

        {/* 主内容区域 */}
        <main className="flex-1 ml-60 min-h-screen">
          <div className="max-w-7xl mx-auto p-6">
            {/* 页面头部 */}
            <div className="mb-6">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-3xl font-bold text-white mb-2">社区概览</h1>
                  <nav className="text-white/80">
                    <Link to="/home" className="hover:text-white transition-colors">首页</Link>
                    <span className="mx-2">{'>'}</span>
                    <span>社区</span>
                  </nav>
                </div>
              </div>
            </div>

            {/* 社区功能入口区 */}
            <section className="mb-8">
              <h2 className="text-2xl font-bold text-white mb-6">社区功能</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {/* 讨论区入口 */}
                <div 
                  onClick={handleDiscussionEntranceClick}
                  className={`${styles.cardGradient} rounded-2xl p-8 shadow-card hover:shadow-card-hover transition-all cursor-pointer group`}
                >
                  <div className="text-center">
                    <div className="w-16 h-16 bg-gradient-primary rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                      <i className="fas fa-comments text-white text-2xl"></i>
                    </div>
                    <h3 className="text-xl font-semibold text-text-primary mb-2">讨论区</h3>
                    <p className="text-text-secondary text-sm mb-4">与其他学习者交流技术心得，分享学习经验</p>
                    <div className="flex items-center justify-center space-x-4 text-sm text-text-secondary">
                      <span><i className="fas fa-fire text-danger mr-1"></i>128个热门话题</span>
                      <span><i className="fas fa-eye mr-1"></i>5.2k浏览</span>
                    </div>
                  </div>
                </div>

                {/* 问答区入口 */}
                <div 
                  onClick={handleQaEntranceClick}
                  className={`${styles.cardGradient} rounded-2xl p-8 shadow-card hover:shadow-card-hover transition-all cursor-pointer group`}
                >
                  <div className="text-center">
                    <div className="w-16 h-16 bg-gradient-secondary rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                      <i className="fas fa-question-circle text-white text-2xl"></i>
                    </div>
                    <h3 className="text-xl font-semibold text-text-primary mb-2">问答区</h3>
                    <p className="text-text-secondary text-sm mb-4">提问解惑，获得专业解答和技术指导</p>
                    <div className="flex items-center justify-center space-x-4 text-sm text-text-secondary">
                      <span><i className="fas fa-check-circle text-success mr-1"></i>89个已解决</span>
                      <span><i className="fas fa-clock text-warning mr-1"></i>15个待回答</span>
                    </div>
                  </div>
                </div>

                {/* 学习小组入口 */}
                <div 
                  onClick={handleStudyGroupEntranceClick}
                  className={`${styles.cardGradient} rounded-2xl p-8 shadow-card hover:shadow-card-hover transition-all cursor-pointer group`}
                >
                  <div className="text-center">
                    <div className="w-16 h-16 bg-gradient-tertiary rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                      <i className="fas fa-users text-white text-2xl"></i>
                    </div>
                    <h3 className="text-xl font-semibold text-text-primary mb-2">学习小组</h3>
                    <p className="text-text-secondary text-sm mb-4">组建或加入学习小组，共同进步成长</p>
                    <div className="flex items-center justify-center space-x-4 text-sm text-text-secondary">
                      <span><i className="fas fa-star text-warning mr-1"></i>25个活跃小组</span>
                      <span><i className="fas fa-user-plus text-info mr-1"></i>1.2k成员</span>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* 热门讨论区 */}
            <section className="mb-8">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-white">热门讨论</h2>
                <Link to="/discussion-forum" className="text-white/80 hover:text-white transition-colors">
                  查看全部 <i className="fas fa-arrow-right ml-1"></i>
                </Link>
              </div>
              
              <div className={`${styles.cardGradient} rounded-xl p-6 shadow-card`}>
                <div className="space-y-4">
                  <div 
                    onClick={() => handleDiscussionPostClick(1)}
                    className="border-b border-border-light pb-4 last:border-b-0 last:pb-0 cursor-pointer hover:bg-bg-secondary rounded-lg p-2 transition-colors"
                  >
                    <div className="flex items-start space-x-3">
                      <img 
                        src="https://s.coze.cn/image/XjEWvaxauY0/" 
                        alt="AI学习者头像" 
                        className="w-10 h-10 rounded-full flex-shrink-0" 
                      />
                      <div className="flex-1">
                        <h3 className="font-semibold text-text-primary mb-1">如何选择适合的多模态模型？</h3>
                        <p className="text-text-secondary text-sm mb-2">最近在学习多模态模型，想问问大家在不同场景下如何选择合适的模型...</p>
                        <div className="flex items-center space-x-4 text-sm text-text-secondary">
                          <span>AI学习者</span>
                          <span><i className="fas fa-comment mr-1"></i>23回复</span>
                          <span><i className="fas fa-eye mr-1"></i>1.2k浏览</span>
                          <span><i className="fas fa-heart mr-1"></i>45点赞</span>
                          <span>2小时前</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div 
                    onClick={() => handleDiscussionPostClick(2)}
                    className="border-b border-border-light pb-4 last:border-b-0 last:pb-0 cursor-pointer hover:bg-bg-secondary rounded-lg p-2 transition-colors"
                  >
                    <div className="flex items-start space-x-3">
                      <img 
                        src="https://s.coze.cn/image/Z98ir65khdI/" 
                        alt="数据科学家头像" 
                        className="w-10 h-10 rounded-full flex-shrink-0"
                      />
                      <div className="flex-1">
                        <h3 className="font-semibold text-text-primary mb-1">分享我的CLIP模型训练经验</h3>
                        <p className="text-text-secondary text-sm mb-2">花了一个月时间训练CLIP模型，遇到了很多坑，分享一下经验...</p>
                        <div className="flex items-center space-x-4 text-sm text-text-secondary">
                          <span>数据科学家</span>
                          <span><i className="fas fa-comment mr-1"></i>18回复</span>
                          <span><i className="fas fa-eye mr-1"></i>856浏览</span>
                          <span><i className="fas fa-heart mr-1"></i>67点赞</span>
                          <span>5小时前</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div 
                    onClick={() => handleDiscussionPostClick(3)}
                    className="border-b border-border-light pb-4 last:border-b-0 last:pb-0 cursor-pointer hover:bg-bg-secondary rounded-lg p-2 transition-colors"
                  >
                    <div className="flex items-start space-x-3">
                      <img 
                        src="https://s.coze.cn/image/E0hd6EEDeqo/" 
                        alt="后端工程师头像" 
                        className="w-10 h-10 rounded-full flex-shrink-0"
                      />
                      <div className="flex-1">
                        <h3 className="font-semibold text-text-primary mb-1">多模态模型部署遇到的问题</h3>
                        <p className="text-text-secondary text-sm mb-2">在生产环境部署多模态模型时遇到了性能问题，大家有什么优化建议吗？</p>
                        <div className="flex items-center space-x-4 text-sm text-text-secondary">
                          <span>后端工程师</span>
                          <span><i className="fas fa-comment mr-1"></i>31回复</span>
                          <span><i className="fas fa-eye mr-1"></i>2.1k浏览</span>
                          <span><i className="fas fa-heart mr-1"></i>89点赞</span>
                          <span>1天前</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* 最新问答区 */}
            <section className="mb-8">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-white">最新问答</h2>
                <Link to="/question-answer" className="text-white/80 hover:text-white transition-colors">
                  查看全部 <i className="fas fa-arrow-right ml-1"></i>
                </Link>
              </div>
              
              <div className={`${styles.cardGradient} rounded-xl p-6 shadow-card`}>
                <div className="space-y-4">
                  <div 
                    onClick={() => handleQaQuestionClick(1)}
                    className="border-b border-border-light pb-4 last:border-b-0 last:pb-0 cursor-pointer hover:bg-bg-secondary rounded-lg p-2 transition-colors"
                  >
                    <div className="flex items-start space-x-3">
                      <img 
                        src="https://s.coze.cn/image/UhUveBFPOm4/" 
                        alt="机器学习新手头像" 
                        className="w-10 h-10 rounded-full flex-shrink-0"
                      />
                      <div className="flex-1">
                        <h3 className="font-semibold text-text-primary mb-1">GPT-4V的视觉理解能力如何？</h3>
                        <p className="text-text-secondary text-sm mb-2">想了解GPT-4V在图像理解方面的具体表现，有没有实际使用过的同学分享一下？</p>
                        <div className="flex items-center space-x-4 text-sm text-text-secondary">
                          <span>机器学习新手</span>
                          <span><i className="fas fa-reply mr-1"></i>5回答</span>
                          <span><i className="fas fa-eye mr-1"></i>342浏览</span>
                          <span className="px-2 py-1 bg-success/10 text-success rounded-full text-xs">已解决</span>
                          <span>1小时前</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div 
                    onClick={() => handleQaQuestionClick(2)}
                    className="border-b border-border-light pb-4 last:border-b-0 last:pb-0 cursor-pointer hover:bg-bg-secondary rounded-lg p-2 transition-colors"
                  >
                    <div className="flex items-start space-x-3">
                      <img 
                        src="https://s.coze.cn/image/bsvwP7w17ws/" 
                        alt="AI开发者头像" 
                        className="w-10 h-10 rounded-full flex-shrink-0"
                      />
                      <div className="flex-1">
                        <h3 className="font-semibold text-text-primary mb-1">如何优化多模态模型的推理速度？</h3>
                        <p className="text-text-secondary text-sm mb-2">模型推理速度太慢，影响用户体验，有哪些有效的优化方法？</p>
                        <div className="flex items-center space-x-4 text-sm text-text-secondary">
                          <span>AI开发者</span>
                          <span><i className="fas fa-reply mr-1"></i>8回答</span>
                          <span><i className="fas fa-eye mr-1"></i>567浏览</span>
                          <span className="px-2 py-1 bg-warning/10 text-warning rounded-full text-xs">讨论中</span>
                          <span>3小时前</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div 
                    onClick={() => handleQaQuestionClick(3)}
                    className="border-b border-border-light pb-4 last:border-b-0 last:pb-0 cursor-pointer hover:bg-bg-secondary rounded-lg p-2 transition-colors"
                  >
                    <div className="flex items-start space-x-3">
                      <img 
                        src="https://s.coze.cn/image/g_5RyI2REm8/" 
                        alt="算法工程师头像" 
                        className="w-10 h-10 rounded-full flex-shrink-0"
                      />
                      <div className="flex-1">
                        <h3 className="font-semibold text-text-primary mb-1">多模态数据预处理的最佳实践？</h3>
                        <p className="text-text-secondary text-sm mb-2">在处理图像、文本、音频等多模态数据时，有哪些预处理的最佳实践？</p>
                        <div className="flex items-center space-x-4 text-sm text-text-secondary">
                          <span>算法工程师</span>
                          <span><i className="fas fa-reply mr-1"></i>12回答</span>
                          <span><i className="fas fa-eye mr-1"></i>891浏览</span>
                          <span className="px-2 py-1 bg-success/10 text-success rounded-full text-xs">已解决</span>
                          <span>6小时前</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* 活跃学习小组区 */}
            <section className="mb-8">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-white">活跃学习小组</h2>
                <Link to="/study-group-list" className="text-white/80 hover:text-white transition-colors">
                  查看全部 <i className="fas fa-arrow-right ml-1"></i>
                </Link>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {/* 学习小组卡片1 */}
                <div 
                  onClick={() => handleStudyGroupCardClick(1)}
                  className={`${styles.cardGradient} rounded-xl p-6 shadow-card hover:shadow-card-hover transition-all cursor-pointer`}
                >
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-gradient-primary rounded-xl flex items-center justify-center flex-shrink-0">
                      <i className="fas fa-robot text-white text-lg"></i>
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-text-primary mb-2">GPT-4V开发者交流群</h3>
                      <p className="text-text-secondary text-sm mb-3">专注于GPT-4V模型的应用开发和技术分享</p>
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center space-x-2">
                          <i className="fas fa-users text-primary"></i>
                          <span className="text-text-secondary">156名成员</span>
                        </div>
                        <span className="text-xs text-success font-medium">今日活跃</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* 学习小组卡片2 */}
                <div 
                  onClick={() => handleStudyGroupCardClick(2)}
                  className={`${styles.cardGradient} rounded-xl p-6 shadow-card hover:shadow-card-hover transition-all cursor-pointer`}
                >
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-gradient-secondary rounded-xl flex items-center justify-center flex-shrink-0">
                      <i className="fas fa-code text-white text-lg"></i>
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-text-primary mb-2">多模态模型训练实战</h3>
                      <p className="text-text-secondary text-sm mb-3">从数据准备到模型训练的全流程实战讨论</p>
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center space-x-2">
                          <i className="fas fa-users text-primary"></i>
                          <span className="text-text-secondary">89名成员</span>
                        </div>
                        <span className="text-xs text-warning font-medium">昨日活跃</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* 学习小组卡片3 */}
                <div 
                  onClick={() => handleStudyGroupCardClick(3)}
                  className={`${styles.cardGradient} rounded-xl p-6 shadow-card hover:shadow-card-hover transition-all cursor-pointer`}
                >
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-gradient-tertiary rounded-xl flex items-center justify-center flex-shrink-0">
                      <i className="fas fa-palette text-white text-lg"></i>
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-text-primary mb-2">AI绘画技术分享</h3>
                      <p className="text-text-secondary text-sm mb-3">DALL-E、Midjourney等AI绘画工具的使用技巧</p>
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center space-x-2">
                          <i className="fas fa-users text-primary"></i>
                          <span className="text-text-secondary">203名成员</span>
                        </div>
                        <span className="text-xs text-text-secondary font-medium">3天前活跃</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          </div>
        </main>
      </div>
    </div>
  );
};

export default CommunityOverviewPage;

