

import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import styles from './styles.module.css';

interface CourseData {
  title: string;
  description: string;
  instructor: string;
  difficulty: string;
  duration: string;
  students: string;
  rating: string;
  chapters: number;
  lessons: number;
}

interface Comment {
  id: string;
  author: string;
  avatar: string;
  content: string;
  timeAgo: string;
  likes: number;
}

interface QAItem {
  id: string;
  title: string;
  content: string;
  author: string;
  timeAgo: string;
  answers: number;
  status: 'solved' | 'discussing';
}

const CourseDetailPage: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const courseId = searchParams.get('id') || '1';

  // 状态管理
  const [expandedSections, setExpandedSections] = useState<Set<number>>(new Set([1]));
  const [isCommentInputVisible, setIsCommentInputVisible] = useState(false);
  const [commentContent, setCommentContent] = useState('');
  const [isQuestionModalVisible, setIsQuestionModalVisible] = useState(false);
  const [questionTitle, setQuestionTitle] = useState('');
  const [questionContent, setQuestionContent] = useState('');
  const [isFavorited, setIsFavorited] = useState(false);
  const [sortType, setSortType] = useState<'latest' | 'hottest'>('latest');

  // 模拟课程数据
  const courseDataMap: Record<string, CourseData> = {
    '1': {
      title: 'GPT-4V多模态入门实战',
      description: '从零开始学习GPT-4V的多模态能力，掌握图像理解、文本生成、视觉问答等核心技术。本课程包含理论讲解、代码实践和项目案例，适合AI初学者和开发者。',
      instructor: '李教授',
      difficulty: '入门',
      duration: '12小时',
      students: '1.2万人',
      rating: '4.8分',
      chapters: 8,
      lessons: 32
    },
    '2': {
      title: 'CLIP模型训练与应用',
      description: '深入理解CLIP模型的工作原理，掌握图像文本匹配技术。',
      instructor: '王博士',
      difficulty: '中级',
      duration: '15小时',
      students: '8.5k人',
      rating: '4.9分',
      chapters: 6,
      lessons: 28
    }
  };

  const currentCourse = courseDataMap[courseId] || courseDataMap['1'];

  // 模拟评论数据
  const [comments] = useState<Comment[]>([
    {
      id: '1',
      author: 'AI学习者',
      avatar: 'https://s.coze.cn/image/EM4BTJ4gOvw/',
      content: '非常棒的入门课程！内容很详细，老师讲解得很清楚，实践项目也很有帮助。推荐给所有想学习多模态AI的朋友。',
      timeAgo: '2天前',
      likes: 128
    },
    {
      id: '2',
      author: '数据科学家',
      avatar: 'https://s.coze.cn/image/QPqjx6qkGU8/',
      content: '作为一名有经验的数据科学家，我觉得这门课程对GPT-4V的讲解很到位，特别是实践部分的代码示例很有参考价值。',
      timeAgo: '3天前',
      likes: 89
    },
    {
      id: '3',
      author: '前端开发者',
      avatar: 'https://s.coze.cn/image/bevCEsQ0CHA/',
      content: '课程内容很实用，API调用部分讲得很清楚，让我能够快速上手开发多模态应用。希望后续能有更高级的课程。',
      timeAgo: '1周前',
      likes: 67
    }
  ]);

  // 模拟问答数据
  const [qaItems] = useState<QAItem[]>([
    {
      id: '1',
      title: '如何解决API调用时的超时问题？',
      content: '在调用GPT-4V API时经常遇到超时错误，请问有什么解决方案吗？我已经尝试了增加超时时间，但效果不明显...',
      author: '初学者小明',
      timeAgo: '2小时前',
      answers: 5,
      status: 'solved'
    },
    {
      id: '2',
      title: '图像分辨率对模型性能的影响？',
      content: '想了解不同图像分辨率对GPT-4V识别效果的影响，以及如何选择最佳的图像尺寸...',
      author: 'AI研究员',
      timeAgo: '5小时前',
      answers: 2,
      status: 'discussing'
    },
    {
      id: '3',
      title: '多模态模型部署需要什么硬件配置？',
      content: '想在本地部署多模态模型进行开发测试，请问需要什么样的硬件配置？GPU显存要求多少？',
      author: '后端工程师',
      timeAgo: '1天前',
      answers: 1,
      status: 'discussing'
    }
  ]);

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = currentCourse.title + ' - 模学苑';
    return () => {
      document.title = originalTitle;
    };
  }, [currentCourse.title]);

  // 处理章节展开/折叠
  const handleSectionToggle = (sectionId: number) => {
    setExpandedSections(prev => {
      const newSet = new Set(prev);
      if (newSet.has(sectionId)) {
        newSet.delete(sectionId);
      } else {
        newSet.add(sectionId);
      }
      return newSet;
    });
  };

  // 处理开始学习
  const handleStartLearning = () => {
    navigate(`/course-learn?courseId=${courseId}&lessonId=1`);
  };

  // 处理收藏
  const handleFavoriteToggle = () => {
    setIsFavorited(!isFavorited);
  };

  // 处理分享
  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: document.title,
          text: '推荐一门很棒的课程',
          url: window.location.href
        });
      } catch (error) {
        console.log('分享取消');
      }
    } else {
      try {
        await navigator.clipboard.writeText(window.location.href);
        alert('链接已复制到剪贴板');
      } catch (error) {
        console.log('复制失败');
      }
    }
  };

  // 处理发表评论
  const handleCommentSubmit = () => {
    if (commentContent.trim()) {
      console.log('发表评论:', commentContent);
      alert('评论发表成功！');
      setCommentContent('');
      setIsCommentInputVisible(false);
    } else {
      alert('请输入评论内容');
    }
  };

  // 处理提问
  const handleQuestionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (questionTitle.trim() && questionContent.trim()) {
      console.log('提交问题:', { title: questionTitle, content: questionContent });
      alert('问题提交成功！');
      setQuestionTitle('');
      setQuestionContent('');
      setIsQuestionModalVisible(false);
    } else {
      alert('请填写完整的问题信息');
    }
  };

  // 处理全局搜索
  const handleGlobalSearch = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      const target = e.target as HTMLInputElement;
      const keyword = target.value.trim();
      if (keyword) {
        navigate(`/search-results?q=${encodeURIComponent(keyword)}`);
      }
    }
  };

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <header className="fixed top-0 left-0 right-0 bg-white/90 backdrop-blur-md border-b border-border-light z-50">
        <div className="flex items-center justify-between px-6 py-3">
          {/* Logo区域 */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-primary rounded-xl flex items-center justify-center">
              <i className="fas fa-graduation-cap text-white text-lg"></i>
            </div>
            <h1 className={`text-xl font-bold ${styles.gradientText}`}>模学苑</h1>
          </div>
          
          {/* 主导航 */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/home" className="text-text-secondary hover:text-primary py-1 transition-colors">首页</Link>
            <Link to="/course-list" className="text-primary font-medium border-b-2 border-primary py-1">课程</Link>
            <Link to="/community-overview" className="text-text-secondary hover:text-primary py-1 transition-colors">社区</Link>
            <Link to="/resource-center" className="text-text-secondary hover:text-primary py-1 transition-colors">资源中心</Link>
          </nav>
          
          {/* 搜索和用户区域 */}
          <div className="flex items-center space-x-4">
            {/* 全局搜索 */}
            <div className="relative hidden lg:block">
              <input 
                type="text" 
                placeholder="搜索课程、资源..." 
                className="w-80 pl-10 pr-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                onKeyPress={handleGlobalSearch}
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary"></i>
            </div>
            
            {/* 消息通知 */}
            <button className="relative p-2 text-text-secondary hover:text-primary transition-colors">
              <i className="fas fa-bell text-lg"></i>
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-danger rounded-full"></span>
            </button>
            
            {/* 用户头像 */}
            <div className="flex items-center space-x-2 cursor-pointer">
              <img 
                src="https://s.coze.cn/image/SEfKK-YpJXc/" 
                alt="用户头像" 
                className="w-8 h-8 rounded-full border-2 border-primary/20"
              />
              <span className="hidden md:block text-text-primary font-medium">张同学</span>
              <i className="fas fa-chevron-down text-text-secondary text-sm"></i>
            </div>
          </div>
        </div>
      </header>

      <div className="flex pt-16">
        {/* 左侧菜单 */}
        <aside className={`fixed left-0 top-16 bottom-0 w-60 ${styles.sidebarGradient} text-white overflow-y-auto`}>
          <div className="p-4">
            <nav className="space-y-2">
              <Link to="/home" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-home text-lg"></i>
                <span>首页</span>
              </Link>
              <Link to="/course-list" className="flex items-center space-x-3 px-4 py-3 rounded-xl bg-white/20 backdrop-blur-sm">
                <i className="fas fa-book text-lg"></i>
                <span className="font-medium">课程中心</span>
              </Link>
              <Link to="/community-overview" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-users text-lg"></i>
                <span>社区互动</span>
              </Link>
              <Link to="/resource-center" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-database text-lg"></i>
                <span>资源中心</span>
              </Link>
              <Link to="/user-profile" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-user text-lg"></i>
                <span>个人中心</span>
              </Link>
            </nav>
            
            {/* 学习进度卡片 */}
            <div className="mt-8 p-4 bg-white/10 backdrop-blur-sm rounded-xl">
              <h3 className="font-semibold mb-3">今日学习</h3>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>进度</span>
                  <span>75%</span>
                </div>
                <div className="w-full bg-white/20 rounded-full h-2">
                  <div className="bg-white h-2 rounded-full" style={{width: '75%'}}></div>
                </div>
                <div className="flex justify-between text-sm">
                  <span>已学时长</span>
                  <span>2.5小时</span>
                </div>
              </div>
            </div>
          </div>
        </aside>

        {/* 主内容区域 */}
        <main className="flex-1 ml-60 min-h-screen">
          <div className="max-w-7xl mx-auto p-6">
            {/* 页面头部 */}
            <div className="mb-6">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-3xl font-bold text-white mb-2">{currentCourse.title}</h1>
                  <nav className="text-white/80">
                    <Link to="/home" className="hover:text-white transition-colors">首页</Link>
                    <span className="mx-2">{'>'}</span>
                    <Link to="/course-list" className="hover:text-white transition-colors">课程</Link>
                    <span className="mx-2">{'>'}</span>
                    <span>{currentCourse.title}</span>
                  </nav>
                </div>
              </div>
            </div>

            {/* 课程概览区 */}
            <section className="mb-8">
              <div className={`${styles.cardGradient} rounded-2xl p-8 shadow-card`}>
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  {/* 课程封面和基本信息 */}
                  <div className="lg:col-span-2">
                    <div className="flex flex-col lg:flex-row lg:items-start space-y-6 lg:space-y-0 lg:space-x-6 mb-6">
                      <div className="relative">
                        <img 
                          src="https://s.coze.cn/image/K72jZcub5CU/" 
                          alt={currentCourse.title} 
                          className="w-full lg:w-80 h-64 object-cover rounded-xl"
                        />
                        <div className="absolute top-3 right-3 bg-primary text-white px-3 py-1 rounded-lg text-sm font-medium">
                          {currentCourse.difficulty}
                        </div>
                      </div>
                      <div className="flex-1">
                        <h2 className="text-2xl font-bold text-text-primary mb-4">{currentCourse.title}</h2>
                        <p className="text-text-secondary mb-6 leading-relaxed">
                          {currentCourse.description}
                        </p>
                        
                        {/* 课程信息 */}
                        <div className="grid grid-cols-2 gap-4 mb-6">
                          <div className="flex items-center space-x-2">
                            <i className="fas fa-clock text-primary"></i>
                            <span className="text-text-secondary">预计学习：{currentCourse.duration}</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <i className="fas fa-signal text-primary"></i>
                            <span className="text-text-secondary">{currentCourse.difficulty}级别</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <i className="fas fa-users text-primary"></i>
                            <span className="text-text-secondary">{currentCourse.students}学习</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <i className="fas fa-star text-warning"></i>
                            <span className="text-text-secondary">{currentCourse.rating} ({parseFloat(currentCourse.rating) * 300}评价)</span>
                          </div>
                        </div>

                        {/* 讲师信息 */}
                        <div className="flex items-center space-x-4 mb-6">
                          <Link to="/user-profile?userId=instructor_1">
                            <img 
                              src="https://s.coze.cn/image/CBsFM77Ov8Q/" 
                              alt={currentCourse.instructor} 
                              className="w-12 h-12 rounded-full border-2 border-primary/20 cursor-pointer"
                            />
                          </Link>
                          <div>
                            <Link to="/user-profile?userId=instructor_1" className="font-semibold text-text-primary cursor-pointer">
                              {currentCourse.instructor}
                            </Link>
                            <p className="text-sm text-text-secondary">AI领域专家，10年教学经验</p>
                          </div>
                        </div>

                        {/* 操作按钮 */}
                        <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4">
                          <button 
                            onClick={handleStartLearning}
                            className="bg-gradient-primary text-white px-8 py-3 rounded-xl font-semibold hover:shadow-gradient transition-all flex-1"
                          >
                            <i className="fas fa-play mr-2"></i>
                            开始学习
                          </button>
                          <button 
                            onClick={handleFavoriteToggle}
                            className={`${isFavorited ? 'bg-primary text-white' : 'border-2 border-primary text-primary'} px-6 py-3 rounded-xl font-semibold hover:bg-primary hover:text-white transition-all`}
                          >
                            <i className={`${isFavorited ? 'fas' : 'fas'} fa-heart mr-2`}></i>
                            {isFavorited ? '已收藏' : '收藏'}
                          </button>
                          <button 
                            onClick={handleShare}
                            className="border-2 border-border-light text-text-secondary px-6 py-3 rounded-xl font-semibold hover:border-primary hover:text-primary transition-all"
                          >
                            <i className="fas fa-share mr-2"></i>
                            分享
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* 课程统计 */}
                  <div className="lg:col-span-1">
                    <div className="bg-gradient-to-br from-primary/10 to-secondary/10 rounded-xl p-6">
                      <h3 className="font-semibold text-text-primary mb-4">课程信息</h3>
                      <div className="space-y-4">
                        <div className="flex justify-between">
                          <span className="text-text-secondary">课程章节</span>
                          <span className="font-medium">{currentCourse.chapters}章 {currentCourse.lessons}节</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-text-secondary">视频时长</span>
                          <span className="font-medium">{currentCourse.duration}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-text-secondary">实践项目</span>
                          <span className="font-medium">5个</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-text-secondary">发布日期</span>
                          <span className="font-medium">2024-01-10</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-text-secondary">最后更新</span>
                          <span className="font-medium">2024-01-15</span>
                        </div>
                      </div>
                      
                      {/* 学员评价 */}
                      <div className="mt-6 pt-6 border-t border-white/30">
                        <h4 className="font-semibold mb-3">学员评价</h4>
                        <div className="space-y-3">
                          <div className="flex items-center space-x-2">
                            <div className="flex text-warning">
                              <i className="fas fa-star"></i>
                              <i className="fas fa-star"></i>
                              <i className="fas fa-star"></i>
                              <i className="fas fa-star"></i>
                              <i className="fas fa-star"></i>
                            </div>
                            <span className="text-sm text-text-secondary">非常棒的入门课程！</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <div className="flex text-warning">
                              <i className="fas fa-star"></i>
                              <i className="fas fa-star"></i>
                              <i className="fas fa-star"></i>
                              <i className="fas fa-star"></i>
                              <i className="fas fa-star"></i>
                            </div>
                            <span className="text-sm text-text-secondary">内容很详细，推荐！</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* 课程大纲区 */}
            <section className="mb-8">
              <div className={`${styles.cardGradient} rounded-2xl p-8 shadow-card`}>
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-bold text-text-primary">课程大纲</h2>
                  <div className="flex items-center space-x-4">
                    <span className="text-text-secondary">共{currentCourse.chapters}章 {currentCourse.lessons}节</span>
                    <span className="text-text-secondary">{currentCourse.duration}</span>
                  </div>
                </div>

                <div className="space-y-4">
                  {/* 第1章 */}
                  <div className={`border border-border-light rounded-xl overflow-hidden ${!expandedSections.has(1) ? styles.sectionCollapsed : ''}`}>
                    <div 
                      className="flex items-center justify-between p-4 bg-bg-secondary cursor-pointer"
                      onClick={() => handleSectionToggle(1)}
                    >
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-primary text-white rounded-lg flex items-center justify-center font-semibold">1</div>
                        <div>
                          <h3 className="font-semibold text-text-primary">GPT-4V基础介绍</h3>
                          <p className="text-sm text-text-secondary">了解多模态AI的基本概念</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-4">
                        <span className="text-sm text-text-secondary">4节 · 1.5小时</span>
                        <i className={`fas ${expandedSections.has(1) ? 'fa-chevron-down' : 'fa-chevron-right'} text-text-secondary transform transition-transform`}></i>
                      </div>
                    </div>
                    <div className={styles.sectionContent}>
                      <div className="divide-y divide-border-light">
                        <div 
                          className="p-4 flex items-center justify-between hover:bg-bg-secondary/50 cursor-pointer"
                          onClick={() => navigate(`/course-learn?courseId=${courseId}&lessonId=1`)}
                        >
                          <div className="flex items-center space-x-3">
                            <i className="fas fa-play-circle text-primary"></i>
                            <span className="text-text-primary">1.1 多模态AI概述</span>
                            <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded">视频</span>
                          </div>
                          <span className="text-sm text-text-secondary">15分钟</span>
                        </div>
                        <div 
                          className="p-4 flex items-center justify-between hover:bg-bg-secondary/50 cursor-pointer"
                          onClick={() => navigate(`/course-learn?courseId=${courseId}&lessonId=2`)}
                        >
                          <div className="flex items-center space-x-3">
                            <i className="fas fa-file-alt text-secondary"></i>
                            <span className="text-text-primary">1.2 GPT-4V技术原理</span>
                            <span className="text-xs bg-secondary/10 text-secondary px-2 py-1 rounded">文档</span>
                          </div>
                          <span className="text-sm text-text-secondary">30分钟</span>
                        </div>
                        <div 
                          className="p-4 flex items-center justify-between hover:bg-bg-secondary/50 cursor-pointer"
                          onClick={() => navigate(`/course-learn?courseId=${courseId}&lessonId=3`)}
                        >
                          <div className="flex items-center space-x-3">
                            <i className="fas fa-code text-tertiary"></i>
                            <span className="text-text-primary">1.3 API调用入门</span>
                            <span className="text-xs bg-tertiary/10 text-tertiary px-2 py-1 rounded">实践</span>
                          </div>
                          <span className="text-sm text-text-secondary">30分钟</span>
                        </div>
                        <div 
                          className="p-4 flex items-center justify-between hover:bg-bg-secondary/50 cursor-pointer"
                          onClick={() => navigate(`/course-learn?courseId=${courseId}&lessonId=4`)}
                        >
                          <div className="flex items-center space-x-3">
                            <i className="fas fa-play-circle text-primary"></i>
                            <span className="text-text-primary">1.4 环境搭建</span>
                            <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded">视频</span>
                          </div>
                          <span className="text-sm text-text-secondary">15分钟</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* 第2章 */}
                  <div className={`border border-border-light rounded-xl overflow-hidden ${!expandedSections.has(2) ? styles.sectionCollapsed : ''}`}>
                    <div 
                      className="flex items-center justify-between p-4 bg-bg-secondary cursor-pointer"
                      onClick={() => handleSectionToggle(2)}
                    >
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-secondary text-white rounded-lg flex items-center justify-center font-semibold">2</div>
                        <div>
                          <h3 className="font-semibold text-text-primary">图像理解基础</h3>
                          <p className="text-sm text-text-secondary">学习图像识别和分析技术</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-4">
                        <span className="text-sm text-text-secondary">6节 · 2小时</span>
                        <i className={`fas ${expandedSections.has(2) ? 'fa-chevron-down' : 'fa-chevron-right'} text-text-secondary transform transition-transform`}></i>
                      </div>
                    </div>
                    <div className={styles.sectionContent}>
                      <div className="divide-y divide-border-light">
                        <div 
                          className="p-4 flex items-center justify-between hover:bg-bg-secondary/50 cursor-pointer"
                          onClick={() => navigate(`/course-learn?courseId=${courseId}&lessonId=5`)}
                        >
                          <div className="flex items-center space-x-3">
                            <i className="fas fa-play-circle text-primary"></i>
                            <span className="text-text-primary">2.1 图像识别原理</span>
                            <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded">视频</span>
                          </div>
                          <span className="text-sm text-text-secondary">20分钟</span>
                        </div>
                        <div 
                          className="p-4 flex items-center justify-between hover:bg-bg-secondary/50 cursor-pointer"
                          onClick={() => navigate(`/course-learn?courseId=${courseId}&lessonId=6`)}
                        >
                          <div className="flex items-center space-x-3">
                            <i className="fas fa-code text-tertiary"></i>
                            <span className="text-text-primary">2.2 图像分类实践</span>
                            <span className="text-xs bg-tertiary/10 text-tertiary px-2 py-1 rounded">实践</span>
                          </div>
                          <span className="text-sm text-text-secondary">40分钟</span>
                        </div>
                        <div 
                          className="p-4 flex items-center justify-between hover:bg-bg-secondary/50 cursor-pointer"
                          onClick={() => navigate(`/course-learn?courseId=${courseId}&lessonId=7`)}
                        >
                          <div className="flex items-center space-x-3">
                            <i className="fas fa-play-circle text-primary"></i>
                            <span className="text-text-primary">2.3 目标检测技术</span>
                            <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded">视频</span>
                          </div>
                          <span className="text-sm text-text-secondary">25分钟</span>
                        </div>
                        <div 
                          className="p-4 flex items-center justify-between hover:bg-bg-secondary/50 cursor-pointer"
                          onClick={() => navigate(`/course-learn?courseId=${courseId}&lessonId=8`)}
                        >
                          <div className="flex items-center space-x-3">
                            <i className="fas fa-code text-tertiary"></i>
                            <span className="text-text-primary">2.4 目标检测实战</span>
                            <span className="text-xs bg-tertiary/10 text-tertiary px-2 py-1 rounded">实践</span>
                          </div>
                          <span className="text-sm text-text-secondary">35分钟</span>
                        </div>
                        <div 
                          className="p-4 flex items-center justify-between hover:bg-bg-secondary/50 cursor-pointer"
                          onClick={() => navigate(`/course-learn?courseId=${courseId}&lessonId=9`)}
                        >
                          <div className="flex items-center space-x-3">
                            <i className="fas fa-play-circle text-primary"></i>
                            <span className="text-text-primary">2.5 图像分割介绍</span>
                            <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded">视频</span>
                          </div>
                          <span className="text-sm text-text-secondary">15分钟</span>
                        </div>
                        <div 
                          className="p-4 flex items-center justify-between hover:bg-bg-secondary/50 cursor-pointer"
                          onClick={() => navigate(`/course-learn?courseId=${courseId}&lessonId=10`)}
                        >
                          <div className="flex items-center space-x-3">
                            <i className="fas fa-file-alt text-secondary"></i>
                            <span className="text-text-primary">2.6 图像理解总结</span>
                            <span className="text-xs bg-secondary/10 text-secondary px-2 py-1 rounded">文档</span>
                          </div>
                          <span className="text-sm text-text-secondary">15分钟</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* 第3章 */}
                  <div className={`border border-border-light rounded-xl overflow-hidden ${!expandedSections.has(3) ? styles.sectionCollapsed : ''}`}>
                    <div 
                      className="flex items-center justify-between p-4 bg-bg-secondary cursor-pointer"
                      onClick={() => handleSectionToggle(3)}
                    >
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-tertiary text-white rounded-lg flex items-center justify-center font-semibold">3</div>
                        <div>
                          <h3 className="font-semibold text-text-primary">文本生成与理解</h3>
                          <p className="text-sm text-text-secondary">掌握文本处理核心技术</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-4">
                        <span className="text-sm text-text-secondary">5节 · 1.8小时</span>
                        <i className={`fas ${expandedSections.has(3) ? 'fa-chevron-down' : 'fa-chevron-right'} text-text-secondary transform transition-transform`}></i>
                      </div>
                    </div>
                    <div className={styles.sectionContent}>
                      <div className="divide-y divide-border-light">
                        <div 
                          className="p-4 flex items-center justify-between hover:bg-bg-secondary/50 cursor-pointer"
                          onClick={() => navigate(`/course-learn?courseId=${courseId}&lessonId=11`)}
                        >
                          <div className="flex items-center space-x-3">
                            <i className="fas fa-play-circle text-primary"></i>
                            <span className="text-text-primary">3.1 文本生成原理</span>
                            <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded">视频</span>
                          </div>
                          <span className="text-sm text-text-secondary">25分钟</span>
                        </div>
                        <div 
                          className="p-4 flex items-center justify-between hover:bg-bg-secondary/50 cursor-pointer"
                          onClick={() => navigate(`/course-learn?courseId=${courseId}&lessonId=12`)}
                        >
                          <div className="flex items-center space-x-3">
                            <i className="fas fa-code text-tertiary"></i>
                            <span className="text-text-primary">3.2 文本补全实践</span>
                            <span className="text-xs bg-tertiary/10 text-tertiary px-2 py-1 rounded">实践</span>
                          </div>
                          <span className="text-sm text-text-secondary">35分钟</span>
                        </div>
                        <div 
                          className="p-4 flex items-center justify-between hover:bg-bg-secondary/50 cursor-pointer"
                          onClick={() => navigate(`/course-learn?courseId=${courseId}&lessonId=13`)}
                        >
                          <div className="flex items-center space-x-3">
                            <i className="fas fa-play-circle text-primary"></i>
                            <span className="text-text-primary">3.3 语义理解技术</span>
                            <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded">视频</span>
                          </div>
                          <span className="text-sm text-text-secondary">20分钟</span>
                        </div>
                        <div 
                          className="p-4 flex items-center justify-between hover:bg-bg-secondary/50 cursor-pointer"
                          onClick={() => navigate(`/course-learn?courseId=${courseId}&lessonId=14`)}
                        >
                          <div className="flex items-center space-x-3">
                            <i className="fas fa-code text-tertiary"></i>
                            <span className="text-text-primary">3.4 情感分析实战</span>
                            <span className="text-xs bg-tertiary/10 text-tertiary px-2 py-1 rounded">实践</span>
                          </div>
                          <span className="text-sm text-text-secondary">30分钟</span>
                        </div>
                        <div 
                          className="p-4 flex items-center justify-between hover:bg-bg-secondary/50 cursor-pointer"
                          onClick={() => navigate(`/course-learn?courseId=${courseId}&lessonId=15`)}
                        >
                          <div className="flex items-center space-x-3">
                            <i className="fas fa-file-alt text-secondary"></i>
                            <span className="text-text-primary">3.5 文本处理总结</span>
                            <span className="text-xs bg-secondary/10 text-secondary px-2 py-1 rounded">文档</span>
                          </div>
                          <span className="text-sm text-text-secondary">10分钟</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* 更多章节... */}
                  <div className="text-center py-4">
                    <button className="text-primary hover:text-secondary transition-colors">
                      查看更多章节 <i className="fas fa-arrow-down ml-1"></i>
                    </button>
                  </div>
                </div>
              </div>
            </section>

            {/* 课程资料区 */}
            <section className="mb-8">
              <div className={`${styles.cardGradient} rounded-2xl p-8 shadow-card`}>
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-bold text-text-primary">课程资料</h2>
                  <span className="text-text-secondary">共12个文件</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  <div className="border border-border-light rounded-xl p-4 hover:shadow-card transition-all">
                    <div className="flex items-center space-x-3 mb-3">
                      <i className="fas fa-file-pdf text-danger text-xl"></i>
                      <div>
                        <h4 className="font-medium text-text-primary">课程课件.pdf</h4>
                        <p className="text-sm text-text-secondary">完整课程PPT</p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-text-secondary">25.6 MB</span>
                      <button className="text-primary hover:text-secondary transition-colors">
                        <i className="fas fa-download"></i>
                      </button>
                    </div>
                  </div>

                  <div className="border border-border-light rounded-xl p-4 hover:shadow-card transition-all">
                    <div className="flex items-center space-x-3 mb-3">
                      <i className="fab fa-python text-blue-500 text-xl"></i>
                      <div>
                        <h4 className="font-medium text-text-primary">示例代码.zip</h4>
                        <p className="text-sm text-text-secondary">完整项目代码</p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-text-secondary">12.3 MB</span>
                      <button className="text-primary hover:text-secondary transition-colors">
                        <i className="fas fa-download"></i>
                      </button>
                    </div>
                  </div>

                  <div className="border border-border-light rounded-xl p-4 hover:shadow-card transition-all">
                    <div className="flex items-center space-x-3 mb-3">
                      <i className="fas fa-database text-success text-xl"></i>
                      <div>
                        <h4 className="font-medium text-text-primary">训练数据集.zip</h4>
                        <p className="text-sm text-text-secondary">实践用数据集</p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-text-secondary">89.2 MB</span>
                      <button className="text-primary hover:text-secondary transition-colors">
                        <i className="fas fa-download"></i>
                      </button>
                    </div>
                  </div>

                  <div className="border border-border-light rounded-xl p-4 hover:shadow-card transition-all">
                    <div className="flex items-center space-x-3 mb-3">
                      <i className="fas fa-file-alt text-info text-xl"></i>
                      <div>
                        <h4 className="font-medium text-text-primary">实验报告模板.docx</h4>
                        <p className="text-sm text-text-secondary">实践报告模板</p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-text-secondary">2.1 MB</span>
                      <button className="text-primary hover:text-secondary transition-colors">
                        <i className="fas fa-download"></i>
                      </button>
                    </div>
                  </div>

                  <div className="border border-border-light rounded-xl p-4 hover:shadow-card transition-all">
                    <div className="flex items-center space-x-3 mb-3">
                      <i className="fas fa-file-powerpoint text-warning text-xl"></i>
                      <div>
                        <h4 className="font-medium text-text-primary">技术分享.pptx</h4>
                        <p className="text-sm text-text-secondary">扩展学习材料</p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-text-secondary">18.7 MB</span>
                      <button className="text-primary hover:text-secondary transition-colors">
                        <i className="fas fa-download"></i>
                      </button>
                    </div>
                  </div>

                  <div className="border border-border-light rounded-xl p-4 hover:shadow-card transition-all">
                    <div className="flex items-center space-x-3 mb-3">
                      <i className="fas fa-file-code text-secondary text-xl"></i>
                      <div>
                        <h4 className="font-medium text-text-primary">环境配置指南.md</h4>
                        <p className="text-sm text-text-secondary">开发环境搭建</p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-text-secondary">1.2 MB</span>
                      <button className="text-primary hover:text-secondary transition-colors">
                        <i className="fas fa-download"></i>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* 评论区 */}
            <section className="mb-8">
              <div className={`${styles.cardGradient} rounded-2xl p-8 shadow-card`}>
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-bold text-text-primary">学员评论</h2>
                  <div className="flex items-center space-x-4">
                    <span className="text-text-secondary">共1.5k条评论</span>
                    <div className="flex items-center space-x-2">
                      <button 
                        onClick={() => setSortType('latest')}
                        className={`px-3 py-1 text-sm rounded-lg transition-colors ${sortType === 'latest' ? 'bg-primary text-white' : 'text-text-secondary hover:bg-bg-secondary'}`}
                      >
                        最新
                      </button>
                      <button 
                        onClick={() => setSortType('hottest')}
                        className={`px-3 py-1 text-sm rounded-lg transition-colors ${sortType === 'hottest' ? 'bg-primary text-white' : 'text-text-secondary hover:bg-bg-secondary'}`}
                      >
                        最热
                      </button>
                    </div>
                  </div>
                </div>

                {/* 发表评论 */}
                <div className="border border-border-light rounded-xl p-4 mb-6">
                  <div className="flex items-start space-x-3">
                    <img 
                      src="https://s.coze.cn/image/bpj9_V95r70/" 
                      alt="我的头像" 
                      className="w-10 h-10 rounded-full"
                    />
                    <div className="flex-1">
                      {!isCommentInputVisible ? (
                        <button 
                          onClick={() => setIsCommentInputVisible(true)}
                          className="w-full text-left p-3 border border-dashed border-border-light rounded-lg hover:border-primary hover:bg-primary/5 transition-colors"
                        >
                          写下你的学习心得...
                        </button>
                      ) : (
                        <div>
                          <textarea 
                            value={commentContent}
                            onChange={(e) => setCommentContent(e.target.value)}
                            className="w-full p-3 border border-border-light rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary" 
                            rows={3} 
                            placeholder="分享你的学习感受..."
                          />
                          <div className="flex items-center justify-end space-x-3 mt-3">
                            <button 
                              onClick={() => {
                                setIsCommentInputVisible(false);
                                setCommentContent('');
                              }}
                              className="px-4 py-2 text-text-secondary hover:text-text-primary transition-colors"
                            >
                              取消
                            </button>
                            <button 
                              onClick={handleCommentSubmit}
                              className="px-6 py-2 bg-primary text-white rounded-lg hover:bg-secondary transition-colors"
                            >
                              发布
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* 评论列表 */}
                <div className="space-y-4">
                  {comments.map((comment) => (
                    <div key={comment.id} className="border border-border-light rounded-xl p-4">
                      <div className="flex items-start space-x-3">
                        <img 
                          src={comment.avatar} 
                          alt="学员头像" 
                          className="w-10 h-10 rounded-full"
                        />
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <span className="font-medium text-text-primary">{comment.author}</span>
                            <span className="text-sm text-text-secondary">{comment.timeAgo}</span>
                          </div>
                          <p className="text-text-primary mb-3">
                            {comment.content}
                          </p>
                          <div className="flex items-center space-x-4">
                            <button className="flex items-center space-x-1 text-text-secondary hover:text-primary transition-colors">
                              <i className="fas fa-thumbs-up"></i>
                              <span>{comment.likes}</span>
                            </button>
                            <button className="text-text-secondary hover:text-primary transition-colors">回复</button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* 加载更多 */}
                <div className="text-center mt-6">
                  <button className="px-6 py-2 border border-border-light text-text-secondary rounded-lg hover:border-primary hover:text-primary transition-colors">
                    查看更多评论
                  </button>
                </div>
              </div>
            </section>

            {/* 问答区 */}
            <section className="mb-8">
              <div className={`${styles.cardGradient} rounded-2xl p-8 shadow-card`}>
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-bold text-text-primary">问答互动</h2>
                  <div className="flex items-center space-x-4">
                    <span className="text-text-secondary">共234个问题</span>
                    <button 
                      onClick={() => setIsQuestionModalVisible(true)}
                      className="px-6 py-2 bg-primary text-white rounded-lg hover:bg-secondary transition-colors"
                    >
                      <i className="fas fa-plus mr-2"></i>
                      我要提问
                    </button>
                  </div>
                </div>

                {/* 问答列表 */}
                <div className="space-y-4">
                  {qaItems.map((qa) => (
                    <div key={qa.id} className="border border-border-light rounded-xl p-4 hover:shadow-card transition-all cursor-pointer">
                      <div className="flex items-start space-x-3">
                        <div className="flex-shrink-0">
                          <div className={`w-8 h-8 ${qa.status === 'solved' ? 'bg-success' : 'bg-warning'} text-white rounded-lg flex items-center justify-center text-sm font-semibold`}>
                            <i className={`fas ${qa.status === 'solved' ? 'fa-check' : 'fa-clock'}`}></i>
                          </div>
                        </div>
                        <div className="flex-1">
                          <h4 className="font-medium text-text-primary mb-2">{qa.title}</h4>
                          <p className="text-sm text-text-secondary mb-3">
                            {qa.content}
                          </p>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-4 text-sm text-text-secondary">
                              <span><i className="fas fa-user mr-1"></i>{qa.author}</span>
                              <span><i className="fas fa-clock mr-1"></i>{qa.timeAgo}</span>
                              <span><i className="fas fa-comment mr-1"></i>{qa.answers}个回答</span>
                            </div>
                            <span className={`px-2 py-1 ${qa.status === 'solved' ? 'bg-success/10 text-success' : 'bg-warning/10 text-warning'} text-xs rounded`}>
                              {qa.status === 'solved' ? '已解决' : '讨论中'}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* 加载更多 */}
                <div className="text-center mt-6">
                  <button className="px-6 py-2 border border-border-light text-text-secondary rounded-lg hover:border-primary hover:text-primary transition-colors">
                    查看更多问答
                  </button>
                </div>
              </div>
            </section>
          </div>
        </main>
      </div>

      {/* 提问模态弹窗 */}
      {isQuestionModalVisible && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-border-light">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-bold text-text-primary">我要提问</h3>
                <button 
                  onClick={() => setIsQuestionModalVisible(false)}
                  className="text-text-secondary hover:text-text-primary transition-colors"
                >
                  <i className="fas fa-times text-xl"></i>
                </button>
              </div>
            </div>
            <div className="p-6">
              <form onSubmit={handleQuestionSubmit} className="space-y-4">
                <div>
                  <label htmlFor="question-title" className="block text-sm font-medium text-text-primary mb-2">问题标题 *</label>
                  <input 
                    type="text" 
                    id="question-title" 
                    value={questionTitle}
                    onChange={(e) => setQuestionTitle(e.target.value)}
                    className="w-full px-4 py-3 border border-border-light rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary" 
                    placeholder="请简要描述你的问题..." 
                    required
                  />
                </div>
                <div>
                  <label htmlFor="question-content" className="block text-sm font-medium text-text-primary mb-2">问题详情 *</label>
                  <textarea 
                    id="question-content" 
                    rows={6}
                    value={questionContent}
                    onChange={(e) => setQuestionContent(e.target.value)}
                    className="w-full px-4 py-3 border border-border-light rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary resize-none" 
                    placeholder="请详细描述你的问题，包括错误信息、代码示例等..." 
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-text-primary mb-2">上传图片（可选）</label>
                  <div className="border-2 border-dashed border-border-light rounded-lg p-6 text-center hover:border-primary transition-colors">
                    <i className="fas fa-cloud-upload-alt text-3xl text-text-secondary mb-2"></i>
                    <p className="text-text-secondary">点击上传或拖拽图片到此处</p>
                    <p className="text-sm text-text-secondary mt-1">支持 JPG、PNG 格式，最大 10MB</p>
                    <input type="file" multiple accept="image/*" className="hidden" />
                  </div>
                </div>
                <div className="flex items-center justify-end space-x-3 pt-4">
                  <button 
                    type="button" 
                    onClick={() => setIsQuestionModalVisible(false)}
                    className="px-6 py-2 text-text-secondary hover:text-text-primary transition-colors"
                  >
                    取消
                  </button>
                  <button 
                    type="submit" 
                    className="px-6 py-2 bg-primary text-white rounded-lg hover:bg-secondary transition-colors"
                  >
                    提交问题
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CourseDetailPage;

