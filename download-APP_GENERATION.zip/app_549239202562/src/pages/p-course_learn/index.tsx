

import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import styles from './styles.module.css';

interface CourseData {
  title: string;
  chapters: {
    [key: string]: string;
  };
}

interface CourseDatabase {
  [key: string]: CourseData;
}

const CourseLearnPage: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const videoPlayerRef = useRef<HTMLVideoElement>(null);
  
  // 状态管理
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(1530); // 25:30 in seconds
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [selectedTab, setSelectedTab] = useState('outline');
  const [expandedChapters, setExpandedChapters] = useState<Set<string>>(new Set(['1']));
  const [commentInput, setCommentInput] = useState('');
  const [codeContent, setCodeContent] = useState(`import openai

# 设置API密钥
openai.api_key = 'YOUR_API_KEY'

# 调用GPT-4V API
response = openai.ChatCompletion.create(
    model='gpt-4-vision-preview',
    messages=[
        {
            'role': 'user',
            'content': [
                {'type': 'text', 'text': '请描述这张图片的内容'},
                {'type': 'image_url', 'image_url': {'url': 'https://s.coze.cn/image/7dGrlzmpcsI/'}}
            ]
        }
    ]
)

print(response.choices[0].message.content)
`);
  const [codeOutput, setCodeOutput] = useState('>>> 等待运行...');
  const [isCodeRunning, setIsCodeRunning] = useState(false);

  // 模拟课程数据
  const courseData: CourseDatabase = {
    'course1': {
      title: 'GPT-4V多模态入门实战',
      chapters: {
        '1': '第一章：GPT-4V基础介绍',
        '2': '第二章：API调用基础',
        '3': '第三章：高级应用开发'
      }
    },
    'course2': {
      title: 'CLIP模型训练与应用',
      chapters: {
        '1': '第一章：CLIP模型原理',
        '2': '第二章：模型训练方法',
        '3': '第三章：实际应用案例'
      }
    }
  };

  // 获取URL参数
  const courseId = searchParams.get('courseId') || 'course1';
  const chapterId = searchParams.get('chapterId') || '1';
  const currentCourse = courseData[courseId];
  const currentChapter = currentCourse?.chapters[chapterId] || '第一章：GPT-4V基础介绍';

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = '课程学习 - 模学苑';
    return () => {
      document.title = originalTitle;
    };
  }, []);

  // 视频播放器事件处理
  useEffect(() => {
    const video = videoPlayerRef.current;
    if (!video) return;

    const handleTimeUpdate = () => {
      setCurrentTime(video.currentTime);
    };

    const handleLoadedMetadata = () => {
      setDuration(video.duration || 1530);
    };

    video.addEventListener('timeupdate', handleTimeUpdate);
    video.addEventListener('loadedmetadata', handleLoadedMetadata);

    return () => {
      video.removeEventListener('timeupdate', handleTimeUpdate);
      video.removeEventListener('loadedmetadata', handleLoadedMetadata);
    };
  }, []);

  // 格式化时间
  const formatTime = (seconds: number): string => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = Math.floor(seconds % 60);
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  // 播放/暂停控制
  const handlePlayPause = () => {
    const video = videoPlayerRef.current;
    if (!video) return;

    if (video.paused) {
      video.play();
      setIsPlaying(true);
    } else {
      video.pause();
      setIsPlaying(false);
    }
  };

  // 播放速度控制
  const handlePlaybackSpeedChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    const speed = parseFloat(event.target.value);
    setPlaybackSpeed(speed);
    if (videoPlayerRef.current) {
      videoPlayerRef.current.playbackRate = speed;
    }
  };

  // 全局搜索
  const handleGlobalSearch = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === 'Enter') {
      const keyword = (event.target as HTMLInputElement).value.trim();
      if (keyword) {
        navigate(`/search-results?q=${encodeURIComponent(keyword)}`);
      }
    }
  };

  // Tab切换
  const handleTabChange = (tabId: string) => {
    setSelectedTab(tabId);
  };

  // 章节展开/折叠
  const handleChapterToggle = (chapterId: string) => {
    const newExpandedChapters = new Set(expandedChapters);
    if (newExpandedChapters.has(chapterId)) {
      newExpandedChapters.delete(chapterId);
    } else {
      newExpandedChapters.add(chapterId);
    }
    setExpandedChapters(newExpandedChapters);
  };

  // 章节切换
  const handleLessonClick = (lessonId: string) => {
    console.log('切换到章节:', lessonId);
    // 实际应用中会更新视频内容和页面URL
  };

  // 代码运行
  const handleRunCode = () => {
    if (isCodeRunning) return;
    
    setIsCodeRunning(true);
    setCodeOutput('>>> 正在运行...');
    
    // 模拟代码运行
    setTimeout(() => {
      setCodeOutput('>>> 运行成功！\n这是一张包含美丽风景的图片，有山有水...');
      setIsCodeRunning(false);
    }, 2000);
  };

  // 代码停止
  const handleStopCode = () => {
    if (isCodeRunning) {
      setCodeOutput('>>> 已停止');
      setIsCodeRunning(false);
    }
  };

  // 代码重置
  const handleResetCode = () => {
    setCodeContent(`import openai

# 设置API密钥
openai.api_key = 'YOUR_API_KEY'

# 调用GPT-4V API
response = openai.ChatCompletion.create(
    model='gpt-4-vision-preview',
    messages=[
        {
            'role': 'user',
            'content': [
                {'type': 'text', 'text': '请描述这张图片的内容'},
                {'type': 'image_url', 'image_url': {'url': 'https://s.coze.cn/image/7dGrlzmpcsI/'}}
            ]
        }
    ]
)

print(response.choices[0].message.content)
`);
  };

  // 清空输出
  const handleClearOutput = () => {
    setCodeOutput('>>> 等待运行...');
  };

  // 提交评论
  const handleSubmitComment = () => {
    const content = commentInput.trim();
    if (content) {
      // 在实际应用中，这里会调用API提交评论
      console.log('提交评论:', content);
      setCommentInput('');
    }
  };

  // 添加笔记
  const handleAddNote = () => {
    setSelectedTab('notes');
    setTimeout(() => {
      const addNoteElement = document.getElementById('add-new-note');
      if (addNoteElement) {
        addNoteElement.scrollIntoView({ behavior: 'smooth' });
      }
    }, 100);
  };

  const progress = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <header className="fixed top-0 left-0 right-0 bg-white/90 backdrop-blur-md border-b border-border-light z-50">
        <div className="flex items-center justify-between px-6 py-3">
          {/* Logo区域 */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-primary rounded-xl flex items-center justify-center">
              <i className="fas fa-graduation-cap text-white text-lg"></i>
            </div>
            <h1 className={`text-xl font-bold ${styles.gradientText}`}>模学苑</h1>
          </div>
          
          {/* 主导航 */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/home" className="text-text-secondary hover:text-primary py-1 transition-colors">首页</Link>
            <Link to="/course-list" className="text-primary font-medium border-b-2 border-primary py-1">课程</Link>
            <Link to="/community-overview" className="text-text-secondary hover:text-primary py-1 transition-colors">社区</Link>
            <Link to="/resource-center" className="text-text-secondary hover:text-primary py-1 transition-colors">资源中心</Link>
          </nav>
          
          {/* 搜索和用户区域 */}
          <div className="flex items-center space-x-4">
            {/* 全局搜索 */}
            <div className="relative hidden lg:block">
              <input 
                type="text" 
                placeholder="搜索课程、资源..." 
                className="w-80 pl-10 pr-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                onKeyPress={handleGlobalSearch}
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary"></i>
            </div>
            
            {/* 消息通知 */}
            <button className="relative p-2 text-text-secondary hover:text-primary transition-colors">
              <i className="fas fa-bell text-lg"></i>
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-danger rounded-full"></span>
            </button>
            
            {/* 用户头像 */}
            <div className="flex items-center space-x-2 cursor-pointer">
              <img 
                src="https://s.coze.cn/image/LU6wV9lJLdk/" 
                alt="用户头像" 
                className="w-8 h-8 rounded-full border-2 border-primary/20"
              />
              <span className="hidden md:block text-text-primary font-medium">张同学</span>
              <i className="fas fa-chevron-down text-text-secondary text-sm"></i>
            </div>
          </div>
        </div>
      </header>

      <div className="flex pt-16">
        {/* 左侧菜单 */}
        <aside className={`fixed left-0 top-16 bottom-0 w-60 ${styles.sidebarGradient} text-white overflow-y-auto`}>
          <div className="p-4">
            <nav className="space-y-2">
              <Link to="/home" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-home text-lg"></i>
                <span>首页</span>
              </Link>
              <Link to="/course-list" className="flex items-center space-x-3 px-4 py-3 rounded-xl bg-white/20 backdrop-blur-sm">
                <i className="fas fa-book text-lg"></i>
                <span className="font-medium">课程中心</span>
              </Link>
              <Link to="/community-overview" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-users text-lg"></i>
                <span>社区互动</span>
              </Link>
              <Link to="/resource-center" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-database text-lg"></i>
                <span>资源中心</span>
              </Link>
              <Link to="/user-profile" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-user text-lg"></i>
                <span>个人中心</span>
              </Link>
            </nav>
            
            {/* 学习进度卡片 */}
            <div className="mt-8 p-4 bg-white/10 backdrop-blur-sm rounded-xl">
              <h3 className="font-semibold mb-3">今日学习</h3>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>进度</span>
                  <span>75%</span>
                </div>
                <div className="w-full bg-white/20 rounded-full h-2">
                  <div className="bg-white h-2 rounded-full" style={{ width: '75%' }}></div>
                </div>
                <div className="flex justify-between text-sm">
                  <span>已学时长</span>
                  <span>2.5小时</span>
                </div>
              </div>
            </div>
          </div>
        </aside>

        {/* 主内容区域 */}
        <main className="flex-1 ml-60 min-h-screen">
          <div className="max-w-7xl mx-auto p-6">
            {/* 页面头部 */}
            <div className="mb-6">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-3xl font-bold text-white mb-2">{currentCourse?.title || 'GPT-4V多模态入门实战'}</h1>
                  <nav className="text-white/80">
                    <Link to="/home" className="hover:text-white transition-colors">首页</Link>
                    <span className="mx-2">{'>'}</span>
                    <Link to="/course-list" className="hover:text-white transition-colors">课程</Link>
                    <span className="mx-2">{'>'}</span>
                    <Link to="/course-detail" className="hover:text-white transition-colors">GPT-4V多模态入门实战</Link>
                    <span className="mx-2">{'>'}</span>
                    <span>{currentChapter}</span>
                  </nav>
                </div>
                <div className="hidden xl:flex items-center space-x-4">
                  <button 
                    onClick={handleAddNote}
                    className="bg-white/20 backdrop-blur-sm text-white px-4 py-2 rounded-xl hover:bg-white/30 transition-colors"
                  >
                    <i className="fas fa-plus mr-2"></i>添加笔记
                  </button>
                  <button className="bg-white/20 backdrop-blur-sm text-white px-4 py-2 rounded-xl hover:bg-white/30 transition-colors">
                    <i className="fas fa-share mr-2"></i>分享课程
                  </button>
                </div>
              </div>
            </div>

            {/* 视频播放区 */}
            <section className="mb-8">
              <div className={`${styles.cardGradient} rounded-2xl p-6 shadow-card`}>
                <div className={`${styles.videoContainer} mb-4`}>
                  <div className={styles.videoPlayer}>
                    <video 
                      ref={videoPlayerRef}
                      className="w-full h-full object-cover" 
                      controls 
                      poster="https://s.coze.cn/image/5qjdtbFadO8/"
                    >
                      <source src="https://s.coze.cn/image/dZciVAP5azM/" type="video/mp4" />
                      您的浏览器不支持视频播放。
                    </video>
                  </div>
                </div>
                
                {/* 视频控制栏 */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <button 
                      onClick={handlePlayPause}
                      className="flex items-center space-x-2 bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary/90 transition-colors"
                    >
                      <i className={`fas ${isPlaying ? 'fa-pause' : 'fa-play'}`}></i>
                      <span>{isPlaying ? '暂停' : '播放'}</span>
                    </button>
                    <select 
                      value={playbackSpeed}
                      onChange={handlePlaybackSpeedChange}
                      className="bg-bg-secondary border border-border-light rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary/20"
                    >
                      <option value="0.5">0.5x</option>
                      <option value="0.75">0.75x</option>
                      <option value="1">1x</option>
                      <option value="1.25">1.25x</option>
                      <option value="1.5">1.5x</option>
                      <option value="2">2x</option>
                    </select>
                    <select className="bg-bg-secondary border border-border-light rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary/20">
                      <option value="auto">自动</option>
                      <option value="360">360p</option>
                      <option value="480">480p</option>
                      <option value="720">720p</option>
                      <option value="1080">1080p</option>
                    </select>
                    <button className="bg-bg-secondary text-text-primary px-3 py-2 rounded-lg hover:bg-border-light transition-colors">
                      <i className="fas fa-closed-captioning mr-1"></i>字幕
                    </button>
                  </div>
                  <div className="text-white/80 text-sm">
                    <span>{formatTime(currentTime)}</span> / <span>{formatTime(duration)}</span>
                  </div>
                </div>
                
                {/* 学习进度条 */}
                <div className="mt-4">
                  <div className="flex items-center justify-between text-white/80 text-sm mb-2">
                    <span>学习进度</span>
                    <span>{Math.round(progress)}%</span>
                  </div>
                  <div className="w-full bg-white/20 rounded-full h-2">
                    <div 
                      className={`${styles.progressBar} h-2 rounded-full transition-all duration-300`} 
                      style={{ width: `${progress}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            </section>

            {/* Tab切换区域 */}
            <section className="mb-8">
              <div className="flex space-x-4 mb-6" role="tablist">
                <button 
                  onClick={() => handleTabChange('outline')}
                  className={`px-6 py-3 text-sm font-medium rounded-xl focus:outline-none ${
                    selectedTab === 'outline' ? styles.tabActive : styles.tabInactive
                  }`}
                  role="tab" 
                  aria-controls="outline-content"
                >
                  <i className="fas fa-list mr-2"></i>课程大纲
                </button>
                <button 
                  onClick={() => handleTabChange('notes')}
                  className={`px-6 py-3 text-sm font-medium rounded-xl focus:outline-none ${
                    selectedTab === 'notes' ? styles.tabActive : styles.tabInactive
                  }`}
                  role="tab" 
                  aria-controls="notes-content"
                >
                  <i className="fas fa-sticky-note mr-2"></i>我的笔记
                </button>
                <button 
                  onClick={() => handleTabChange('practice')}
                  className={`px-6 py-3 text-sm font-medium rounded-xl focus:outline-none ${
                    selectedTab === 'practice' ? styles.tabActive : styles.tabInactive
                  }`}
                  role="tab" 
                  aria-controls="practice-content"
                >
                  <i className="fas fa-code mr-2"></i>实践环境
                </button>
              </div>

              {/* 课程大纲内容 */}
              {selectedTab === 'outline' && (
                <div className="tab-content">
                  <div className={`${styles.cardGradient} rounded-2xl p-6 shadow-card`}>
                    <h3 className="text-lg font-semibold text-text-primary mb-4">课程大纲</h3>
                    <div className="space-y-3">
                      {/* 章节1 */}
                      <div className="border border-border-light rounded-lg overflow-hidden">
                        <div 
                          className="bg-primary/10 px-4 py-3 flex items-center justify-between cursor-pointer"
                          onClick={() => handleChapterToggle('1')}
                        >
                          <div className="flex items-center space-x-3">
                            <i className={`fas ${expandedChapters.has('1') ? 'fa-chevron-down' : 'fa-chevron-right'} text-primary`}></i>
                            <div>
                              <h4 className="font-medium text-text-primary">第一章：GPT-4V基础介绍</h4>
                              <p className="text-sm text-text-secondary">3节 · 45分钟</p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            <span className="bg-success text-white text-xs px-2 py-1 rounded-full">已完成</span>
                          </div>
                        </div>
                        {expandedChapters.has('1') && (
                          <div className="px-4 py-3 space-y-2">
                            <div className="flex items-center space-x-3 p-2 rounded-lg bg-success/10 border-l-4 border-success">
                              <i className="fas fa-play-circle text-success"></i>
                              <div className="flex-1">
                                <p className="text-sm font-medium text-text-primary">1.1 GPT-4V概述</p>
                                <p className="text-xs text-text-secondary">15分钟 · 视频</p>
                              </div>
                              <i className="fas fa-check-circle text-success"></i>
                            </div>
                            <div className="flex items-center space-x-3 p-2 rounded-lg bg-success/10 border-l-4 border-success">
                              <i className="fas fa-play-circle text-success"></i>
                              <div className="flex-1">
                                <p className="text-sm font-medium text-text-primary">1.2 多模态能力演示</p>
                                <p className="text-xs text-text-secondary">20分钟 · 视频</p>
                              </div>
                              <i className="fas fa-check-circle text-success"></i>
                            </div>
                            <div className="flex items-center space-x-3 p-2 rounded-lg bg-success/10 border-l-4 border-success">
                              <i className="fas fa-file-alt text-success"></i>
                              <div className="flex-1">
                                <p className="text-sm font-medium text-text-primary">1.3 环境准备</p>
                                <p className="text-xs text-text-secondary">10分钟 · 文档</p>
                              </div>
                              <i className="fas fa-check-circle text-success"></i>
                            </div>
                          </div>
                        )}
                      </div>

                      {/* 章节2 */}
                      <div className="border border-border-light rounded-lg overflow-hidden">
                        <div 
                          className="bg-bg-secondary px-4 py-3 flex items-center justify-between cursor-pointer"
                          onClick={() => handleChapterToggle('2')}
                        >
                          <div className="flex items-center space-x-3">
                            <i className={`fas ${expandedChapters.has('2') ? 'fa-chevron-down' : 'fa-chevron-right'} text-text-secondary`}></i>
                            <div>
                              <h4 className="font-medium text-text-primary">第二章：API调用基础</h4>
                              <p className="text-sm text-text-secondary">4节 · 60分钟</p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            <span className="bg-primary text-white text-xs px-2 py-1 rounded-full">学习中</span>
                          </div>
                        </div>
                        {expandedChapters.has('2') && (
                          <div className="px-4 py-3 space-y-2">
                            <div 
                              className="flex items-center space-x-3 p-2 rounded-lg bg-primary/10 border-l-4 border-primary cursor-pointer"
                              onClick={() => handleLessonClick('2.1')}
                            >
                              <i className="fas fa-play-circle text-primary"></i>
                              <div className="flex-1">
                                <p className="text-sm font-medium text-text-primary">2.1 API密钥获取</p>
                                <p className="text-xs text-text-secondary">15分钟 · 视频</p>
                              </div>
                              <div className="flex items-center space-x-2">
                                <div className="w-4 h-4 border-2 border-primary rounded-full"></div>
                                <span className="text-xs text-primary">当前</span>
                              </div>
                            </div>
                            <div 
                              className="flex items-center space-x-3 p-2 rounded-lg hover:bg-bg-secondary cursor-pointer"
                              onClick={() => handleLessonClick('2.2')}
                            >
                              <i className="fas fa-play-circle text-text-secondary"></i>
                              <div className="flex-1">
                                <p className="text-sm font-medium text-text-primary">2.2 基础API调用</p>
                                <p className="text-xs text-text-secondary">20分钟 · 视频</p>
                              </div>
                              <div className="w-4 h-4 border-2 border-border-light rounded-full"></div>
                            </div>
                            <div 
                              className="flex items-center space-x-3 p-2 rounded-lg hover:bg-bg-secondary cursor-pointer"
                              onClick={() => handleLessonClick('2.3')}
                            >
                              <i className="fas fa-code text-text-secondary"></i>
                              <div className="flex-1">
                                <p className="text-sm font-medium text-text-primary">2.3 实践：第一个调用</p>
                                <p className="text-xs text-text-secondary">15分钟 · 实践</p>
                              </div>
                              <div className="w-4 h-4 border-2 border-border-light rounded-full"></div>
                            </div>
                            <div 
                              className="flex items-center space-x-3 p-2 rounded-lg hover:bg-bg-secondary cursor-pointer"
                              onClick={() => handleLessonClick('2.4')}
                            >
                              <i className="fas fa-file-alt text-text-secondary"></i>
                              <div className="flex-1">
                                <p className="text-sm font-medium text-text-primary">2.4 API文档详解</p>
                                <p className="text-xs text-text-secondary">10分钟 · 文档</p>
                              </div>
                              <div className="w-4 h-4 border-2 border-border-light rounded-full"></div>
                            </div>
                          </div>
                        )}
                      </div>

                      {/* 章节3 */}
                      <div className="border border-border-light rounded-lg overflow-hidden">
                        <div 
                          className="bg-bg-secondary px-4 py-3 flex items-center justify-between cursor-pointer"
                          onClick={() => handleChapterToggle('3')}
                        >
                          <div className="flex items-center space-x-3">
                            <i className={`fas ${expandedChapters.has('3') ? 'fa-chevron-down' : 'fa-chevron-right'} text-text-secondary`}></i>
                            <div>
                              <h4 className="font-medium text-text-primary">第三章：高级应用开发</h4>
                              <p className="text-sm text-text-secondary">5节 · 75分钟</p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            <span className="bg-text-secondary text-white text-xs px-2 py-1 rounded-full">未开始</span>
                          </div>
                        </div>
                        {expandedChapters.has('3') && (
                          <div className="px-4 py-3 space-y-2">
                            <div 
                              className="flex items-center space-x-3 p-2 rounded-lg hover:bg-bg-secondary cursor-pointer"
                              onClick={() => handleLessonClick('3.1')}
                            >
                              <i className="fas fa-play-circle text-text-secondary"></i>
                              <div className="flex-1">
                                <p className="text-sm font-medium text-text-primary">3.1 多模态输入处理</p>
                                <p className="text-xs text-text-secondary">20分钟 · 视频</p>
                              </div>
                              <div className="w-4 h-4 border-2 border-border-light rounded-full"></div>
                            </div>
                            <div 
                              className="flex items-center space-x-3 p-2 rounded-lg hover:bg-bg-secondary cursor-pointer"
                              onClick={() => handleLessonClick('3.2')}
                            >
                              <i className="fas fa-play-circle text-text-secondary"></i>
                              <div className="flex-1">
                                <p className="text-sm font-medium text-text-primary">3.2 图像理解深度应用</p>
                                <p className="text-xs text-text-secondary">15分钟 · 视频</p>
                              </div>
                              <div className="w-4 h-4 border-2 border-border-light rounded-full"></div>
                            </div>
                            <div 
                              className="flex items-center space-x-3 p-2 rounded-lg hover:bg-bg-secondary cursor-pointer"
                              onClick={() => handleLessonClick('3.3')}
                            >
                              <i className="fas fa-code text-text-secondary"></i>
                              <div className="flex-1">
                                <p className="text-sm font-medium text-text-primary">3.3 实践：智能助手</p>
                                <p className="text-xs text-text-secondary">20分钟 · 实践</p>
                              </div>
                              <div className="w-4 h-4 border-2 border-border-light rounded-full"></div>
                            </div>
                            <div 
                              className="flex items-center space-x-3 p-2 rounded-lg hover:bg-bg-secondary cursor-pointer"
                              onClick={() => handleLessonClick('3.4')}
                            >
                              <i className="fas fa-play-circle text-text-secondary"></i>
                              <div className="flex-1">
                                <p className="text-sm font-medium text-text-primary">3.4 性能优化技巧</p>
                                <p className="text-xs text-text-secondary">10分钟 · 视频</p>
                              </div>
                              <div className="w-4 h-4 border-2 border-border-light rounded-full"></div>
                            </div>
                            <div 
                              className="flex items-center space-x-3 p-2 rounded-lg hover:bg-bg-secondary cursor-pointer"
                              onClick={() => handleLessonClick('3.5')}
                            >
                              <i className="fas fa-flag-checkered text-text-secondary"></i>
                              <div className="flex-1">
                                <p className="text-sm font-medium text-text-primary">3.5 项目实战与总结</p>
                                <p className="text-xs text-text-secondary">10分钟 · 视频</p>
                              </div>
                              <div className="w-4 h-4 border-2 border-border-light rounded-full"></div>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* 我的笔记内容 */}
              {selectedTab === 'notes' && (
                <div className="tab-content">
                  <div className={`${styles.cardGradient} rounded-2xl p-6 shadow-card`}>
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-semibold text-text-primary">我的笔记</h3>
                      <button className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary/90 transition-colors">
                        <i className="fas fa-download mr-2"></i>导出笔记
                      </button>
                    </div>
                    
                    <div className="space-y-4">
                      {/* 笔记项1 */}
                      <div className="border border-border-light rounded-lg p-4">
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex items-center space-x-2">
                            <i className="fas fa-clock text-text-secondary"></i>
                            <span className="text-sm text-text-secondary">视频 05:32</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <button className="text-text-secondary hover:text-primary transition-colors">
                              <i className="fas fa-edit"></i>
                            </button>
                            <button className="text-text-secondary hover:text-danger transition-colors">
                              <i className="fas fa-trash"></i>
                            </button>
                          </div>
                        </div>
                        <h4 className="font-medium text-text-primary mb-2">GPT-4V的核心特性</h4>
                        <p className="text-text-secondary">GPT-4V相比之前的版本，最大的改进在于其多模态理解能力，能够同时处理文本和图像输入...</p>
                        <div className="mt-3 pt-3 border-t border-border-light">
                          <span className="text-xs text-text-secondary">2024-01-15 14:30</span>
                        </div>
                      </div>

                      {/* 笔记项2 */}
                      <div className="border border-border-light rounded-lg p-4">
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex items-center space-x-2">
                            <i className="fas fa-clock text-text-secondary"></i>
                            <span className="text-sm text-text-secondary">视频 12:18</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <button className="text-text-secondary hover:text-primary transition-colors">
                              <i className="fas fa-edit"></i>
                            </button>
                            <button className="text-text-secondary hover:text-danger transition-colors">
                              <i className="fas fa-trash"></i>
                            </button>
                          </div>
                        </div>
                        <h4 className="font-medium text-text-primary mb-2">API调用注意事项</h4>
                        <p className="text-text-secondary">在调用GPT-4V API时，需要注意请求参数的格式，特别是图像数据的处理方式...</p>
                        <div className="mt-3 pt-3 border-t border-border-light">
                          <span className="text-xs text-text-secondary">2024-01-15 14:45</span>
                        </div>
                      </div>

                      {/* 添加新笔记 */}
                      <div 
                        id="add-new-note"
                        className="border-2 border-dashed border-border-light rounded-lg p-6 text-center hover:border-primary/50 transition-colors cursor-pointer"
                        onClick={() => console.log('添加新笔记')}
                      >
                        <i className="fas fa-plus text-3xl text-text-secondary mb-2"></i>
                        <p className="text-text-secondary">添加新笔记</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* 实践环境内容 */}
              {selectedTab === 'practice' && (
                <div className="tab-content">
                  <div className={`${styles.cardGradient} rounded-2xl p-6 shadow-card`}>
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-semibold text-text-primary">实践环境</h3>
                      <div className="flex items-center space-x-2">
                        <button 
                          onClick={handleRunCode}
                          className="bg-success text-white px-4 py-2 rounded-lg hover:bg-success/90 transition-colors"
                        >
                          <i className="fas fa-play mr-2"></i>运行
                        </button>
                        <button 
                          onClick={handleStopCode}
                          className="bg-danger text-white px-4 py-2 rounded-lg hover:bg-danger/90 transition-colors"
                        >
                          <i className="fas fa-stop mr-2"></i>停止
                        </button>
                        <button 
                          onClick={handleResetCode}
                          className="bg-warning text-white px-4 py-2 rounded-lg hover:bg-warning/90 transition-colors"
                        >
                          <i className="fas fa-undo mr-2"></i>重置
                        </button>
                      </div>
                    </div>
                    
                    {/* 代码编辑器 */}
                    <div className="border border-border-light rounded-lg overflow-hidden mb-4">
                      <div className="bg-bg-secondary px-4 py-2 flex items-center justify-between border-b border-border-light">
                        <span className="text-sm font-medium text-text-primary">Python代码</span>
                        <div className="flex items-center space-x-2">
                          <span className="text-xs text-text-secondary">在线编辑器</span>
                          <div className={`w-2 h-2 rounded-full ${isCodeRunning ? 'bg-warning' : 'bg-success'}`}></div>
                        </div>
                      </div>
                      <textarea 
                        value={codeContent}
                        onChange={(e) => setCodeContent(e.target.value)}
                        className={`w-full h-80 p-4 ${styles.codeEditor} bg-white border-none outline-none resize-none`} 
                        placeholder={`# 在这里编写你的代码...
import openai

# 设置API密钥
openai.api_key = 'YOUR_API_KEY'

# 调用GPT-4V API
response = openai.ChatCompletion.create(
    model='gpt-4-vision-preview',
    messages=[
        {
            'role': 'user',
            'content': [
                {'type': 'text', 'text': '请描述这张图片的内容'},
                {'type': 'image_url', 'image_url': {'url': 'https://s.coze.cn/image/Da6Z7zaswIs/'}}
            ]
        }
    ]
)

print(response.choices[0].message.content)
`}
                      />
                    </div>
                    
                    {/* 运行结果 */}
                    <div className="border border-border-light rounded-lg overflow-hidden">
                      <div className="bg-bg-secondary px-4 py-2 flex items-center justify-between border-b border-border-light">
                        <span className="text-sm font-medium text-text-primary">运行结果</span>
                        <button 
                          onClick={handleClearOutput}
                          className="text-text-secondary hover:text-primary text-sm"
                        >
                          <i className="fas fa-trash mr-1"></i>清空
                        </button>
                      </div>
                      <div className="w-full h-40 p-4 bg-black text-green-400 text-sm overflow-y-auto font-mono">
                        {codeOutput.split('\n').map((line, index) => (
                          <div key={index}>{line}</div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </section>

            {/* 评论区 */}
            <section className="mb-8">
              <div className={`${styles.cardGradient} rounded-2xl p-6 shadow-card`}>
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-lg font-semibold text-text-primary">评论区</h3>
                  <div className="flex items-center space-x-2">
                    <button className="px-3 py-1 text-sm rounded-lg bg-primary text-white">最新</button>
                    <button className="px-3 py-1 text-sm rounded-lg bg-bg-secondary text-text-secondary hover:bg-border-light">最热</button>
                  </div>
                </div>
                
                {/* 发表评论 */}
                <div className="border border-border-light rounded-lg p-4 mb-6">
                  <div className="flex items-start space-x-3">
                    <img 
                      src="https://s.coze.cn/image/cMlIGwM24VA/" 
                      alt="用户头像" 
                      className="w-10 h-10 rounded-full"
                    />
                    <div className="flex-1">
                      <textarea 
                        value={commentInput}
                        onChange={(e) => setCommentInput(e.target.value)}
                        placeholder="写下你的想法..." 
                        className="w-full p-3 border border-border-light rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary resize-none"
                        rows={3}
                      />
                      <div className="flex items-center justify-between mt-3">
                        <div className="flex items-center space-x-3">
                          <button className="text-text-secondary hover:text-primary transition-colors">
                            <i className="fas fa-image"></i>
                          </button>
                          <button className="text-text-secondary hover:text-primary transition-colors">
                            <i className="fas fa-code"></i>
                          </button>
                        </div>
                        <button 
                          onClick={handleSubmitComment}
                          className="bg-primary text-white px-6 py-2 rounded-lg hover:bg-primary/90 transition-colors"
                        >
                          发表评论
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* 评论列表 */}
                <div className="space-y-4">
                  {/* 评论项1 */}
                  <div className="border border-border-light rounded-lg p-4">
                    <div className="flex items-start space-x-3">
                      <img 
                        src="https://s.coze.cn/image/DNfK75uo4BM/" 
                        alt="用户头像" 
                        className="w-10 h-10 rounded-full"
                      />
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <span className="font-medium text-text-primary">AI学习者</span>
                          <span className="text-sm text-text-secondary">2小时前</span>
                        </div>
                        <p className="text-text-primary mb-3">老师讲得很清晰，特别是API调用部分，让我对GPT-4V的使用有了更深入的理解。期待后续的实战课程！</p>
                        <div className="flex items-center space-x-4">
                          <button className="flex items-center space-x-1 text-text-secondary hover:text-danger transition-colors">
                            <i className="fas fa-heart"></i>
                            <span>24</span>
                          </button>
                          <button className="text-text-secondary hover:text-primary transition-colors">
                            <i className="fas fa-reply"></i>
                            <span>回复</span>
                          </button>
                        </div>
                        
                        {/* 回复列表 */}
                        <div className="mt-3 pl-4 border-l-2 border-border-light space-y-3">
                          <div className="flex items-start space-x-2">
                            <img 
                              src="https://s.coze.cn/image/FI83VZR2ogQ/" 
                              alt="用户头像" 
                              className="w-8 h-8 rounded-full"
                            />
                            <div className="flex-1">
                              <div className="flex items-center space-x-2 mb-1">
                                <span className="font-medium text-text-primary text-sm">张老师</span>
                                <span className="text-xs text-text-secondary">1小时前</span>
                              </div>
                              <p className="text-text-primary text-sm">谢谢支持！后续会有更多实战内容。</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* 评论项2 */}
                  <div className="border border-border-light rounded-lg p-4">
                    <div className="flex items-start space-x-3">
                      <img 
                        src="https://s.coze.cn/image/ISU0HcrrfCM/" 
                        alt="用户头像" 
                        className="w-10 h-10 rounded-full"
                      />
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <span className="font-medium text-text-primary">数据科学家</span>
                          <span className="text-sm text-text-secondary">5小时前</span>
                        </div>
                        <p className="text-text-primary mb-3">有没有关于模型性能优化的建议？在实际应用中遇到了一些延迟问题。</p>
                        <div className="flex items-center space-x-4">
                          <button className="flex items-center space-x-1 text-text-secondary hover:text-danger transition-colors">
                            <i className="fas fa-heart"></i>
                            <span>8</span>
                          </button>
                          <button className="text-text-secondary hover:text-primary transition-colors">
                            <i className="fas fa-reply"></i>
                            <span>回复</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* 评论项3 */}
                  <div className="border border-border-light rounded-lg p-4">
                    <div className="flex items-start space-x-3">
                      <img 
                        src="https://s.coze.cn/image/Kbp8qWGImlk/" 
                        alt="用户头像" 
                        className="w-10 h-10 rounded-full"
                      />
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <span className="font-medium text-text-primary">前端开发者</span>
                          <span className="text-sm text-text-secondary">1天前</span>
                        </div>
                        <p className="text-text-primary mb-3">实践环境很棒，可以直接在浏览器中测试代码，省去了本地配置的麻烦。</p>
                        <div className="flex items-center space-x-4">
                          <button className="flex items-center space-x-1 text-text-secondary hover:text-danger transition-colors">
                            <i className="fas fa-heart"></i>
                            <span>15</span>
                          </button>
                          <button className="text-text-secondary hover:text-primary transition-colors">
                            <i className="fas fa-reply"></i>
                            <span>回复</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* 加载更多 */}
                <div className="text-center mt-6">
                  <button className="bg-bg-secondary text-text-primary px-6 py-2 rounded-lg hover:bg-border-light transition-colors">
                    加载更多评论
                  </button>
                </div>
              </div>
            </section>
          </div>
        </main>
      </div>
    </div>
  );
};

export default CourseLearnPage;

