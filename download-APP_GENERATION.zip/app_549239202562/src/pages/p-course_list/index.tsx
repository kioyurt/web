

import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import styles from './styles.module.css';

interface CourseData {
  id: string;
  title: string;
  description: string;
  instructor: string;
  rating: number;
  students: string;
  duration: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced' | 'expert';
  image: string;
  updated: string;
}

const CourseListPage: React.FC = () => {
  const navigate = useNavigate();
  
  // 状态管理
  const [globalSearchValue, setGlobalSearchValue] = useState('');
  const [courseSearchValue, setCourseSearchValue] = useState('');
  const [difficultyFilter, setDifficultyFilter] = useState('');
  const [scenarioFilter, setScenarioFilter] = useState('');
  const [modelFilter, setModelFilter] = useState('');
  const [sortBy, setSortBy] = useState('popularity');
  const [viewMode, setViewMode] = useState<'card' | 'list'>('card');
  const [currentPage, setCurrentPage] = useState(1);

  // 课程数据
  const coursesData: CourseData[] = [
    {
      id: 'course1',
      title: 'GPT-4V多模态入门实战',
      description: '从零开始学习GPT-4V的多模态能力，掌握图像理解和文本生成的核心技术',
      instructor: '李教授',
      rating: 4.8,
      students: '1.2万人学习',
      duration: '8小时',
      difficulty: 'beginner',
      image: 'https://s.coze.cn/image/xicnqW0qlXk/',
      updated: '2024-01-15'
    },
    {
      id: 'course2',
      title: 'CLIP模型训练与应用',
      description: '深入理解CLIP模型的工作原理，学习如何训练和部署图像文本匹配模型',
      instructor: '王博士',
      rating: 4.9,
      students: '8.5k人学习',
      duration: '12小时',
      difficulty: 'intermediate',
      image: 'https://s.coze.cn/image/XWsZ3-f05eg/',
      updated: '2024-01-14'
    },
    {
      id: 'course3',
      title: 'DALL-E图像生成技术',
      description: '掌握文本到图像的生成技术，学习提示词工程和图像生成模型调优',
      instructor: '张老师',
      rating: 4.7,
      students: '6.3k人学习',
      duration: '15小时',
      difficulty: 'advanced',
      image: 'https://s.coze.cn/image/NT2MZjFf8a4/',
      updated: '2024-01-13'
    },
    {
      id: 'course4',
      title: '多模态模型部署优化',
      description: '生产环境下的模型部署最佳实践，包括性能优化、模型压缩和服务架构设计',
      instructor: '陈工程师',
      rating: 4.6,
      students: '4.2k人学习',
      duration: '20小时',
      difficulty: 'expert',
      image: 'https://s.coze.cn/image/SXZXklRWDwM/',
      updated: '2024-01-12'
    },
    {
      id: 'course5',
      title: 'Stable Diffusion实战指南',
      description: '全面学习Stable Diffusion模型，从基础使用到高级图像生成技巧',
      instructor: '刘研究员',
      rating: 4.8,
      students: '9.8k人学习',
      duration: '10小时',
      difficulty: 'intermediate',
      image: 'https://s.coze.cn/image/KS_VEgNEWr8/',
      updated: '2024-01-11'
    },
    {
      id: 'course6',
      title: '多模态Transformer架构详解',
      description: '深入研究Transformer在多模态任务中的应用，包括模型结构和训练方法',
      instructor: '赵教授',
      rating: 4.9,
      students: '3.5k人学习',
      duration: '18小时',
      difficulty: 'advanced',
      image: 'https://s.coze.cn/image/KdVnxKDZeHM/',
      updated: '2024-01-10'
    },
    {
      id: 'course7',
      title: '语音识别与合成技术',
      description: '学习现代语音处理技术，包括ASR、TTS以及多语言语音处理',
      instructor: '孙老师',
      rating: 4.7,
      students: '5.7k人学习',
      duration: '14小时',
      difficulty: 'intermediate',
      image: 'https://s.coze.cn/image/cvRFQAon5tM/',
      updated: '2024-01-09'
    },
    {
      id: 'course8',
      title: '多模态模型评估与优化',
      description: '学习如何评估多模态模型性能，掌握模型优化和调参的关键技术',
      instructor: '周博士',
      rating: 4.8,
      students: '2.8k人学习',
      duration: '22小时',
      difficulty: 'expert',
      image: 'https://s.coze.cn/image/iXavXOAXRXE/',
      updated: '2024-01-08'
    }
  ];

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = '课程中心 - 模学苑';
    return () => { document.title = originalTitle; };
  }, []);

  // 处理全局搜索
  const handleGlobalSearchKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      const keyword = globalSearchValue.trim();
      if (keyword) {
        navigate(`/search-results?q=${encodeURIComponent(keyword)}`);
      }
    }
  };

  // 处理课程搜索
  const handleCourseSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setCourseSearchValue(e.target.value);
    console.log('搜索课程:', e.target.value);
  };

  // 处理筛选器变化
  const handleFilterChange = (e: React.ChangeEvent<HTMLSelectElement>, filterType: string) => {
    const value = e.target.value;
    switch (filterType) {
      case 'difficulty':
        setDifficultyFilter(value);
        break;
      case 'scenario':
        setScenarioFilter(value);
        break;
      case 'model':
        setModelFilter(value);
        break;
    }
    console.log('筛选条件变化:', {
      difficulty: difficultyFilter,
      scenario: scenarioFilter,
      model: modelFilter
    });
  };

  // 处理排序变化
  const handleSortChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSortBy(e.target.value);
    console.log('排序方式:', e.target.value);
  };

  // 处理视图切换
  const handleViewModeChange = (mode: 'card' | 'list') => {
    setViewMode(mode);
  };

  // 处理课程卡片点击
  const handleCourseCardClick = (courseId: string) => {
    navigate(`/course-detail?id=${courseId}`);
  };

  // 处理表格排序
  const handleTableSort = (sortField: string) => {
    console.log('排序字段:', sortField);
  };

  // 处理分页
  const handlePrevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
      console.log('上一页');
    }
  };

  const handleNextPage = () => {
    setCurrentPage(currentPage + 1);
    console.log('下一页');
  };

  // 获取难度样式类名
  const getDifficultyClassName = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner':
        return styles.difficultyBeginner;
      case 'intermediate':
        return styles.difficultyIntermediate;
      case 'advanced':
        return styles.difficultyAdvanced;
      case 'expert':
        return styles.difficultyExpert;
      default:
        return '';
    }
  };

  // 获取难度中文名称
  const getDifficultyChinese = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner':
        return '入门';
      case 'intermediate':
        return '初级';
      case 'advanced':
        return '中级';
      case 'expert':
        return '高级';
      default:
        return '';
    }
  };

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <header className="fixed top-0 left-0 right-0 bg-white/90 backdrop-blur-md border-b border-border-light z-50">
        <div className="flex items-center justify-between px-6 py-3">
          {/* Logo区域 */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-primary rounded-xl flex items-center justify-center">
              <i className="fas fa-graduation-cap text-white text-lg"></i>
            </div>
            <h1 className={`text-xl font-bold ${styles.gradientText}`}>模学苑</h1>
          </div>
          
          {/* 主导航 */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/home" className="text-text-secondary hover:text-primary py-1 transition-colors">首页</Link>
            <span className="text-primary font-medium border-b-2 border-primary py-1">课程</span>
            <Link to="/community-overview" className="text-text-secondary hover:text-primary py-1 transition-colors">社区</Link>
            <Link to="/resource-center" className="text-text-secondary hover:text-primary py-1 transition-colors">资源中心</Link>
          </nav>
          
          {/* 搜索和用户区域 */}
          <div className="flex items-center space-x-4">
            {/* 全局搜索 */}
            <div className="relative hidden lg:block">
              <input 
                type="text" 
                placeholder="搜索课程、资源..." 
                value={globalSearchValue}
                onChange={(e) => setGlobalSearchValue(e.target.value)}
                onKeyPress={handleGlobalSearchKeyPress}
                className="w-80 pl-10 pr-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary"></i>
            </div>
            
            {/* 消息通知 */}
            <button className="relative p-2 text-text-secondary hover:text-primary transition-colors">
              <i className="fas fa-bell text-lg"></i>
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-danger rounded-full"></span>
            </button>
            
            {/* 用户头像 */}
            <div className="flex items-center space-x-2 cursor-pointer">
              <img 
                src="https://s.coze.cn/image/w72VpYeg-VY/" 
                alt="用户头像" 
                className="w-8 h-8 rounded-full border-2 border-primary/20"
              />
              <span className="hidden md:block text-text-primary font-medium">张同学</span>
              <i className="fas fa-chevron-down text-text-secondary text-sm"></i>
            </div>
          </div>
        </div>
      </header>

      <div className="flex pt-16">
        {/* 左侧菜单 */}
        <aside className={`fixed left-0 top-16 bottom-0 w-60 ${styles.sidebarGradient} text-white overflow-y-auto`}>
          <div className="p-4">
            <nav className="space-y-2">
              <Link to="/home" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-home text-lg"></i>
                <span>首页</span>
              </Link>
              <span className="flex items-center space-x-3 px-4 py-3 rounded-xl bg-white/20 backdrop-blur-sm">
                <i className="fas fa-book text-lg"></i>
                <span className="font-medium">课程中心</span>
              </span>
              <Link to="/community-overview" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-users text-lg"></i>
                <span>社区互动</span>
              </Link>
              <Link to="/resource-center" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-database text-lg"></i>
                <span>资源中心</span>
              </Link>
              <Link to="/user-profile" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-user text-lg"></i>
                <span>个人中心</span>
              </Link>
            </nav>
            
            {/* 学习进度卡片 */}
            <div className="mt-8 p-4 bg-white/10 backdrop-blur-sm rounded-xl">
              <h3 className="font-semibold mb-3">今日学习</h3>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>进度</span>
                  <span>75%</span>
                </div>
                <div className="w-full bg-white/20 rounded-full h-2">
                  <div className="bg-white h-2 rounded-full" style={{width: '75%'}}></div>
                </div>
                <div className="flex justify-between text-sm">
                  <span>已学时长</span>
                  <span>2.5小时</span>
                </div>
              </div>
            </div>
          </div>
        </aside>

        {/* 主内容区域 */}
        <main className="flex-1 ml-60 min-h-screen">
          <div className="max-w-7xl mx-auto p-6">
            {/* 页面头部 */}
            <div className="mb-6">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-3xl font-bold text-white mb-2">全部课程</h1>
                  <nav className="text-white/80">
                    <Link to="/home" className="hover:text-white transition-colors">首页</Link>
                    <span className="mx-2">{'>'}</span>
                    <span>课程</span>
                  </nav>
                </div>
              </div>
            </div>

            {/* 工具栏区域 */}
            <div className={`${styles.cardGradient} rounded-xl p-6 shadow-card mb-6`}>
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
                {/* 搜索和筛选 */}
                <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 flex-1">
                  {/* 搜索框 */}
                  <div className="relative flex-1 max-w-md">
                    <input 
                      type="text" 
                      placeholder="搜索课程名称、讲师..." 
                      value={courseSearchValue}
                      onChange={handleCourseSearchChange}
                      className="w-full pl-10 pr-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                    />
                    <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary"></i>
                  </div>

                  {/* 难度筛选 */}
                  <select 
                    value={difficultyFilter}
                    onChange={(e) => handleFilterChange(e, 'difficulty')}
                    className="px-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                  >
                    <option value="">全部难度</option>
                    <option value="beginner">入门</option>
                    <option value="intermediate">初级</option>
                    <option value="advanced">中级</option>
                    <option value="expert">高级</option>
                  </select>

                  {/* 应用场景筛选 */}
                  <select 
                    value={scenarioFilter}
                    onChange={(e) => handleFilterChange(e, 'scenario')}
                    className="px-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                  >
                    <option value="">全部场景</option>
                    <option value="image-generation">图像生成</option>
                    <option value="video-understanding">视频理解</option>
                    <option value="speech-interaction">语音交互</option>
                    <option value="text-analysis">文本分析</option>
                  </select>

                  {/* 模型类型筛选 */}
                  <select 
                    value={modelFilter}
                    onChange={(e) => handleFilterChange(e, 'model')}
                    className="px-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                  >
                    <option value="">全部模型</option>
                    <option value="gpt">GPT系列</option>
                    <option value="clip">CLIP</option>
                    <option value="dalle">DALL-E</option>
                    <option value="stable-diffusion">Stable Diffusion</option>
                  </select>
                </div>

                {/* 排序和视图切换 */}
                <div className="flex items-center space-x-4">
                  {/* 排序 */}
                  <select 
                    value={sortBy}
                    onChange={handleSortChange}
                    className="px-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                  >
                    <option value="popularity">学习人数</option>
                    <option value="date">发布时间</option>
                    <option value="rating">评分</option>
                  </select>

                  {/* 视图切换 */}
                  <div className="flex bg-bg-secondary rounded-xl p-1">
                    <button 
                      onClick={() => handleViewModeChange('card')}
                      className={`px-3 py-1 rounded-lg transition-all ${
                        viewMode === 'card' ? styles.viewActive : styles.viewInactive
                      }`}
                    >
                      <i className="fas fa-th-large"></i>
                    </button>
                    <button 
                      onClick={() => handleViewModeChange('list')}
                      className={`px-3 py-1 rounded-lg transition-all ${
                        viewMode === 'list' ? styles.viewActive : styles.viewInactive
                      }`}
                    >
                      <i className="fas fa-list"></i>
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* 数据展示区域 */}
            <div className="mb-6">
              {/* 卡片视图 */}
              {viewMode === 'card' && (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {coursesData.map((course) => (
                    <div 
                      key={course.id}
                      onClick={() => handleCourseCardClick(course.id)}
                      className={`${styles.cardGradient} rounded-2xl p-6 shadow-card hover:shadow-card-hover transition-all cursor-pointer`}
                    >
                      <div className="relative mb-4">
                        <img 
                          src={course.image} 
                          alt={course.title} 
                          className="w-full h-48 object-cover rounded-xl"
                        />
                        <div className={`absolute top-3 right-3 px-2 py-1 rounded-lg text-sm ${getDifficultyClassName(course.difficulty)}`}>
                          {getDifficultyChinese(course.difficulty)}
                        </div>
                      </div>
                      <h3 className="font-semibold text-text-primary mb-2">{course.title}</h3>
                      <p className="text-text-secondary text-sm mb-3">{course.description}</p>
                      <div className="flex items-center justify-between text-sm mb-3">
                        <span className="text-text-secondary">{course.instructor}</span>
                        <div className="flex items-center space-x-1">
                          <i className="fas fa-star text-warning"></i>
                          <span className="text-text-secondary">{course.rating}</span>
                        </div>
                      </div>
                      <div className="flex items-center justify-between text-sm text-text-secondary">
                        <span><i className="fas fa-users mr-1"></i>{course.students}</span>
                        <span><i className="fas fa-clock mr-1"></i>{course.duration}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* 列表视图 */}
              {viewMode === 'list' && (
                <div className={`${styles.cardGradient} rounded-xl shadow-card overflow-hidden`}>
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-bg-secondary">
                        <tr>
                          <th 
                            className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider cursor-pointer hover:text-text-primary"
                            onClick={() => handleTableSort('name')}
                          >
                            课程名称 <i className="fas fa-sort ml-1"></i>
                          </th>
                          <th 
                            className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider cursor-pointer hover:text-text-primary"
                            onClick={() => handleTableSort('instructor')}
                          >
                            讲师 <i className="fas fa-sort ml-1"></i>
                          </th>
                          <th 
                            className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider cursor-pointer hover:text-text-primary"
                            onClick={() => handleTableSort('difficulty')}
                          >
                            难度 <i className="fas fa-sort ml-1"></i>
                          </th>
                          <th 
                            className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider cursor-pointer hover:text-text-primary"
                            onClick={() => handleTableSort('students')}
                          >
                            学习人数 <i className="fas fa-sort ml-1"></i>
                          </th>
                          <th 
                            className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider cursor-pointer hover:text-text-primary"
                            onClick={() => handleTableSort('rating')}
                          >
                            评分 <i className="fas fa-sort ml-1"></i>
                          </th>
                          <th 
                            className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider cursor-pointer hover:text-text-primary"
                            onClick={() => handleTableSort('updated')}
                          >
                            更新时间 <i className="fas fa-sort ml-1"></i>
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                            操作
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-border-light">
                        {coursesData.slice(0, 4).map((course) => (
                          <tr 
                            key={course.id}
                            onClick={() => handleCourseCardClick(course.id)}
                            className="hover:bg-bg-secondary transition-colors cursor-pointer"
                          >
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="flex items-center">
                                <img 
                                  className="h-12 w-12 rounded-lg object-cover" 
                                  src={course.image} 
                                  alt=""
                                />
                                <div className="ml-4">
                                  <div className="text-sm font-medium text-text-primary">{course.title}</div>
                                  <div className="text-sm text-text-secondary">{course.description}</div>
                                </div>
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary">{course.instructor}</td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className={`px-2 py-1 rounded-lg text-xs ${getDifficultyClassName(course.difficulty)}`}>
                                {getDifficultyChinese(course.difficulty)}
                              </span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary">
                              {course.students.replace('万人学习', '000').replace('k人学习', '00')}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary">{course.rating}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary">{course.updated}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm">
                              <button className="text-primary hover:text-secondary transition-colors">查看详情</button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>

            {/* 分页区域 */}
            <div className="flex items-center justify-between">
              <div className="text-sm text-white/80">
                显示第 <span className="font-medium">1</span> 到 <span className="font-medium">8</span> 条，共 <span className="font-medium">24</span> 条结果
              </div>
              <div className="flex items-center space-x-2">
                <button 
                  onClick={handlePrevPage}
                  disabled={currentPage === 1}
                  className="px-3 py-1 border border-border-light rounded-lg text-white/80 hover:text-white hover:border-white/20 transition-colors disabled:opacity-50"
                >
                  <i className="fas fa-chevron-left"></i>
                </button>
                <button className="px-3 py-1 bg-primary text-white rounded-lg">1</button>
                <button className="px-3 py-1 border border-border-light rounded-lg text-white/80 hover:text-white hover:border-white/20 transition-colors">2</button>
                <button className="px-3 py-1 border border-border-light rounded-lg text-white/80 hover:text-white hover:border-white/20 transition-colors">3</button>
                <span className="px-2 text-white/60">...</span>
                <button className="px-3 py-1 border border-border-light rounded-lg text-white/80 hover:text-white hover:border-white/20 transition-colors">5</button>
                <button 
                  onClick={handleNextPage}
                  className="px-3 py-1 border border-border-light rounded-lg text-white/80 hover:text-white hover:border-white/20 transition-colors"
                >
                  <i className="fas fa-chevron-right"></i>
                </button>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default CourseListPage;

