

import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import styles from './styles.module.css';
import { DiscussionPost, FormData } from './types';

const DiscussionForumPage: React.FC = () => {
  const navigate = useNavigate();

  // 模拟讨论帖子数据
  const mockPosts: DiscussionPost[] = [
    {
      id: 1,
      title: '如何选择适合的多模态模型？',
      author: 'AI学习者',
      category: 'tech',
      publishTime: '2024-01-15 14:30',
      replies: 23,
      views: 1256,
      lastReplyTime: '2024-01-15 16:45',
      isHot: true
    },
    {
      id: 2,
      title: '分享我的CLIP模型训练经验',
      author: '数据科学家',
      category: 'experience',
      publishTime: '2024-01-15 10:15',
      replies: 18,
      views: 856,
      lastReplyTime: '2024-01-15 15:20',
      isHot: false
    },
    {
      id: 3,
      title: '多模态模型部署遇到的问题',
      author: '后端工程师',
      category: 'help',
      publishTime: '2024-01-14 16:20',
      replies: 31,
      views: 2103,
      lastReplyTime: '2024-01-15 13:10',
      isHot: true
    },
    {
      id: 4,
      title: 'GPT-4V在实际项目中的应用案例',
      author: '全栈开发者',
      category: 'project',
      publishTime: '2024-01-14 09:45',
      replies: 12,
      views: 678,
      lastReplyTime: '2024-01-14 20:30',
      isHot: false
    },
    {
      id: 5,
      title: '多模态大模型招聘信息分享',
      author: 'HR招聘',
      category: 'job',
      publishTime: '2024-01-13 15:30',
      replies: 8,
      views: 432,
      lastReplyTime: '2024-01-14 11:15',
      isHot: false
    },
    {
      id: 6,
      title: 'DALL-E图像生成技巧分享',
      author: 'AI艺术家',
      category: 'experience',
      publishTime: '2024-01-13 11:20',
      replies: 15,
      views: 945,
      lastReplyTime: '2024-01-14 08:45',
      isHot: false
    },
    {
      id: 7,
      title: '多模态模型评估指标详解',
      author: '机器学习专家',
      category: 'tech',
      publishTime: '2024-01-12 16:45',
      replies: 27,
      views: 1567,
      lastReplyTime: '2024-01-14 17:20',
      isHot: true
    },
    {
      id: 8,
      title: '求推荐多模态相关的学习资源',
      author: 'AI初学者',
      category: 'help',
      publishTime: '2024-01-12 09:30',
      replies: 19,
      views: 789,
      lastReplyTime: '2024-01-13 14:10',
      isHot: false
    },
    {
      id: 9,
      title: '多模态模型训练环境搭建指南',
      author: '系统管理员',
      category: 'experience',
      publishTime: '2024-01-11 14:20',
      replies: 14,
      views: 1123,
      lastReplyTime: '2024-01-13 10:30',
      isHot: false
    },
    {
      id: 10,
      title: 'AI公司招聘多模态算法工程师',
      author: '猎头顾问',
      category: 'job',
      publishTime: '2024-01-11 10:15',
      replies: 6,
      views: 356,
      lastReplyTime: '2024-01-12 16:25',
      isHot: false
    }
  ];

  // 状态管理
  const [currentPosts, setCurrentPosts] = useState<DiscussionPost[]>([...mockPosts]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalCount, setTotalCount] = useState(mockPosts.length);
  const [discussionSearchTerm, setDiscussionSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [timeFilter, setTimeFilter] = useState('');
  const [sortBy, setSortBy] = useState('latest');
  const [isPublishModalVisible, setIsPublishModalVisible] = useState(false);
  const [formData, setFormData] = useState<FormData>({
    title: '',
    category: '',
    content: ''
  });
  const [globalSearchTerm, setGlobalSearchTerm] = useState('');

  const pageSize = 10;

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = '讨论区 - 模学苑';
    return () => { document.title = originalTitle; };
  }, []);

  // 获取分类中文名称
  const getCategoryName = (category: string): string => {
    const categoryMap: Record<string, string> = {
      'tech': '技术交流',
      'project': '项目分享',
      'experience': '经验交流',
      'help': '求助问答',
      'job': '招聘信息'
    };
    return categoryMap[category] || category;
  };

  // 格式化时间显示
  const formatTime = (timeStr: string): string => {
    const now = new Date();
    const time = new Date(timeStr);
    const diff = now.getTime() - time.getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (minutes < 60) {
      return `${minutes}分钟前`;
    } else if (hours < 24) {
      return `${hours}小时前`;
    } else if (days < 7) {
      return `${days}天前`;
    } else {
      return time.toLocaleDateString('zh-CN');
    }
  };

  // 时间筛选检查
  const checkTimeFilter = (timeStr: string, filter: string): boolean => {
    const postTime = new Date(timeStr);
    const now = new Date();
    const diffDays = (now.getTime() - postTime.getTime()) / (1000 * 60 * 60 * 24);

    switch (filter) {
      case 'today':
        return diffDays < 1;
      case 'week':
        return diffDays < 7;
      case 'month':
        return diffDays < 30;
      case 'quarter':
        return diffDays < 90;
      default:
        return true;
    }
  };

  // 搜索和筛选功能
  const handleSearchAndFilter = () => {
    let filteredPosts = mockPosts.filter(post => {
      const matchesSearch = !discussionSearchTerm || 
        post.title.toLowerCase().includes(discussionSearchTerm.toLowerCase()) ||
        post.author.toLowerCase().includes(discussionSearchTerm.toLowerCase());
      
      const matchesCategory = !categoryFilter || post.category === categoryFilter;
      
      const matchesTime = !timeFilter || checkTimeFilter(post.publishTime, timeFilter);

      return matchesSearch && matchesCategory && matchesTime;
    });

    // 应用排序
    filteredPosts = sortPosts(filteredPosts, sortBy);

    setCurrentPosts(filteredPosts);
    setTotalCount(filteredPosts.length);
    setCurrentPage(1);
  };

  // 排序功能
  const sortPosts = (posts: DiscussionPost[], sortBy: string): DiscussionPost[] => {
    const sortedPosts = [...posts];
    switch (sortBy) {
      case 'latest':
        return sortedPosts.sort((a, b) => new Date(b.publishTime).getTime() - new Date(a.publishTime).getTime());
      case 'hot':
        return sortedPosts.sort((a, b) => (b.views + b.replies * 5) - (a.views + a.replies * 5));
      case 'most-replies':
        return sortedPosts.sort((a, b) => b.replies - a.replies);
      case 'title':
        return sortedPosts.sort((a, b) => a.title.localeCompare(b.title));
      case 'author':
        return sortedPosts.sort((a, b) => a.author.localeCompare(b.author));
      case 'time':
        return sortedPosts.sort((a, b) => new Date(b.publishTime).getTime() - new Date(a.publishTime).getTime());
      case 'replies':
        return sortedPosts.sort((a, b) => b.replies - a.replies);
      case 'views':
        return sortedPosts.sort((a, b) => b.views - a.views);
      case 'last-reply':
        return sortedPosts.sort((a, b) => new Date(b.lastReplyTime).getTime() - new Date(a.lastReplyTime).getTime());
      default:
        return sortedPosts;
    }
  };

  // 处理排序
  const handleSort = (newSortBy: string) => {
    setSortBy(newSortBy);
    setCurrentPosts(prev => sortPosts(prev, newSortBy));
  };

  // 处理分页
  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };

  // 处理表单提交
  const handleFormSubmit = () => {
    // 模拟发布成功
    alert('帖子发布成功！');
    setIsPublishModalVisible(false);
    setFormData({ title: '', category: '', content: '' });
  };

  // 处理全局搜索
  const handleGlobalSearch = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      const keyword = globalSearchTerm.trim();
      if (keyword) {
        navigate(`/search-results?q=${encodeURIComponent(keyword)}`);
      }
    }
  };

  // 处理帖子行点击
  const handlePostClick = (postId: number) => {
    navigate(`/discussion-forum?postId=${postId}`);
  };

  // 计算当前页数据
  const totalPages = Math.ceil(totalCount / pageSize);
  const startIndex = (currentPage - 1) * pageSize;
  const endIndex = startIndex + pageSize;
  const currentPagePosts = currentPosts.slice(startIndex, endIndex);
  const startItem = (currentPage - 1) * pageSize + 1;
  const endItem = Math.min(currentPage * pageSize, totalCount);

  // 生成页码
  const generatePageNumbers = () => {
    const pageNumbers = [];
    for (let i = 1; i <= totalPages; i++) {
      if (i === 1 || i === totalPages || (i >= currentPage - 1 && i <= currentPage + 1)) {
        pageNumbers.push(
          <button
            key={i}
            className={`px-3 py-1 rounded-lg transition-colors ${
              i === currentPage 
                ? 'bg-primary text-white' 
                : 'border border-border-light text-white/80 hover:text-white hover:border-primary'
            }`}
            onClick={() => handlePageChange(i)}
          >
            {i}
          </button>
        );
      } else if (i === currentPage - 2 || i === currentPage + 2) {
        pageNumbers.push(
          <span key={`ellipsis-${i}`} className="px-2 text-white/50">
            ...
          </span>
        );
      }
    }
    return pageNumbers;
  };

  // 监听搜索和筛选条件变化
  useEffect(() => {
    handleSearchAndFilter();
  }, [discussionSearchTerm, categoryFilter, timeFilter, sortBy]);

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <header className="fixed top-0 left-0 right-0 bg-white/90 backdrop-blur-md border-b border-border-light z-50">
        <div className="flex items-center justify-between px-6 py-3">
          {/* Logo区域 */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-primary rounded-xl flex items-center justify-center">
              <i className="fas fa-graduation-cap text-white text-lg"></i>
            </div>
            <h1 className={`text-xl font-bold ${styles.gradientText}`}>模学苑</h1>
          </div>
          
          {/* 主导航 */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/home" className="text-text-secondary hover:text-primary py-1 transition-colors">首页</Link>
            <Link to="/course-list" className="text-text-secondary hover:text-primary py-1 transition-colors">课程</Link>
            <Link to="/community-overview" className="text-primary font-medium border-b-2 border-primary py-1">社区</Link>
            <Link to="/resource-center" className="text-text-secondary hover:text-primary py-1 transition-colors">资源中心</Link>
          </nav>
          
          {/* 搜索和用户区域 */}
          <div className="flex items-center space-x-4">
            {/* 全局搜索 */}
            <div className="relative hidden lg:block">
              <input 
                type="text" 
                placeholder="搜索课程、资源..." 
                value={globalSearchTerm}
                onChange={(e) => setGlobalSearchTerm(e.target.value)}
                onKeyPress={handleGlobalSearch}
                className="w-80 pl-10 pr-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary"></i>
            </div>
            
            {/* 消息通知 */}
            <button className="relative p-2 text-text-secondary hover:text-primary transition-colors">
              <i className="fas fa-bell text-lg"></i>
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-danger rounded-full"></span>
            </button>
            
            {/* 用户头像 */}
            <div className="flex items-center space-x-2 cursor-pointer">
              <img 
                src="https://s.coze.cn/image/JH3qlBfXcYM/" 
                alt="用户头像" 
                className="w-8 h-8 rounded-full border-2 border-primary/20"
              />
              <span className="hidden md:block text-text-primary font-medium">张同学</span>
              <i className="fas fa-chevron-down text-text-secondary text-sm"></i>
            </div>
          </div>
        </div>
      </header>

      <div className="flex pt-16">
        {/* 左侧菜单 */}
        <aside className={`fixed left-0 top-16 bottom-0 w-60 ${styles.sidebarGradient} text-white overflow-y-auto`}>
          <div className="p-4">
            <nav className="space-y-2">
              <Link to="/home" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-home text-lg"></i>
                <span>首页</span>
              </Link>
              <Link to="/course-list" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-book text-lg"></i>
                <span>课程中心</span>
              </Link>
              <Link to="/community-overview" className="flex items-center space-x-3 px-4 py-3 rounded-xl bg-white/20 backdrop-blur-sm">
                <i className="fas fa-users text-lg"></i>
                <span className="font-medium">社区互动</span>
              </Link>
              <Link to="/resource-center" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-database text-lg"></i>
                <span>资源中心</span>
              </Link>
              <Link to="/user-profile" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-user text-lg"></i>
                <span>个人中心</span>
              </Link>
            </nav>
            
            {/* 学习进度卡片 */}
            <div className="mt-8 p-4 bg-white/10 backdrop-blur-sm rounded-xl">
              <h3 className="font-semibold mb-3">今日学习</h3>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>进度</span>
                  <span>75%</span>
                </div>
                <div className="w-full bg-white/20 rounded-full h-2">
                  <div className="bg-white h-2 rounded-full" style={{width: '75%'}}></div>
                </div>
                <div className="flex justify-between text-sm">
                  <span>已学时长</span>
                  <span>2.5小时</span>
                </div>
              </div>
            </div>
          </div>
        </aside>

        {/* 主内容区域 */}
        <main className="flex-1 ml-60 min-h-screen">
          <div className="max-w-7xl mx-auto p-6">
            {/* 页面头部 */}
            <div className="mb-6">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-3xl font-bold text-white mb-2">讨论区</h1>
                  <nav className="text-white/80">
                    <Link to="/home" className="hover:text-white transition-colors">首页</Link>
                    <span className="mx-2">{'>'}</span>
                    <Link to="/community-overview" className="hover:text-white transition-colors">社区</Link>
                    <span className="mx-2">{'>'}</span>
                    <span>讨论区</span>
                  </nav>
                </div>
              </div>
            </div>

            {/* 工具栏区域 */}
            <div className={`${styles.cardGradient} rounded-xl p-6 shadow-card mb-6`}>
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
                {/* 搜索和筛选 */}
                <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-3 sm:space-y-0 sm:space-x-4">
                  {/* 搜索框 */}
                  <div className="relative">
                    <input 
                      type="text" 
                      placeholder="搜索帖子标题、内容、作者..." 
                      value={discussionSearchTerm}
                      onChange={(e) => setDiscussionSearchTerm(e.target.value)}
                      className="w-full sm:w-80 pl-10 pr-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                    />
                    <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary"></i>
                  </div>
                  
                  {/* 分类筛选 */}
                  <select 
                    value={categoryFilter}
                    onChange={(e) => setCategoryFilter(e.target.value)}
                    className="px-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                  >
                    <option value="">全部分类</option>
                    <option value="tech">技术交流</option>
                    <option value="project">项目分享</option>
                    <option value="experience">经验交流</option>
                    <option value="help">求助问答</option>
                    <option value="job">招聘信息</option>
                  </select>
                  
                  {/* 时间筛选 */}
                  <select 
                    value={timeFilter}
                    onChange={(e) => setTimeFilter(e.target.value)}
                    className="px-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                  >
                    <option value="">全部时间</option>
                    <option value="today">今天</option>
                    <option value="week">本周</option>
                    <option value="month">本月</option>
                    <option value="quarter">本季度</option>
                  </select>
                </div>
                
                {/* 排序和发布 */}
                <div className="flex items-center space-x-4">
                  {/* 排序方式 */}
                  <select 
                    value={sortBy}
                    onChange={(e) => handleSort(e.target.value)}
                    className="px-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                  >
                    <option value="latest">最新发布</option>
                    <option value="hot">最热讨论</option>
                    <option value="most-replies">最多回复</option>
                  </select>
                  
                  {/* 发布新帖按钮 */}
                  <button 
                    onClick={() => setIsPublishModalVisible(true)}
                    className="bg-gradient-primary text-white px-6 py-2 rounded-xl font-semibold hover:shadow-gradient transition-all"
                  >
                    <i className="fas fa-plus mr-2"></i>发布新帖
                  </button>
                </div>
              </div>
            </div>

            {/* 讨论帖子列表 */}
            <div className={`${styles.cardGradient} rounded-xl shadow-card mb-6`}>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-bg-secondary">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                        <button 
                          onClick={() => handleSort('title')}
                          className="flex items-center space-x-1 hover:text-primary transition-colors"
                        >
                          <span>帖子标题</span>
                          <i className="fas fa-sort text-xs"></i>
                        </button>
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                        <button 
                          onClick={() => handleSort('author')}
                          className="flex items-center space-x-1 hover:text-primary transition-colors"
                        >
                          <span>作者</span>
                          <i className="fas fa-sort text-xs"></i>
                        </button>
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                        <button 
                          onClick={() => handleSort('time')}
                          className="flex items-center space-x-1 hover:text-primary transition-colors"
                        >
                          <span>发布时间</span>
                          <i className="fas fa-sort text-xs"></i>
                        </button>
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                        <button 
                          onClick={() => handleSort('replies')}
                          className="flex items-center space-x-1 hover:text-primary transition-colors"
                        >
                          <span>回复数</span>
                          <i className="fas fa-sort text-xs"></i>
                        </button>
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                        <button 
                          onClick={() => handleSort('views')}
                          className="flex items-center space-x-1 hover:text-primary transition-colors"
                        >
                          <span>浏览量</span>
                          <i className="fas fa-sort text-xs"></i>
                        </button>
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                        <button 
                          onClick={() => handleSort('last-reply')}
                          className="flex items-center space-x-1 hover:text-primary transition-colors"
                        >
                          <span>最后回复</span>
                          <i className="fas fa-sort text-xs"></i>
                        </button>
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-border-light">
                    {currentPagePosts.map(post => (
                      <tr 
                        key={post.id}
                        className={`${styles.tableRowHover} cursor-pointer`}
                        onClick={() => handlePostClick(post.id)}
                      >
                        <td className="px-6 py-4">
                          <div className="flex items-center space-x-2">
                            {post.isHot && <i className="fas fa-fire text-danger text-sm"></i>}
                            <span className="text-text-primary font-medium hover:text-primary transition-colors">{post.title}</span>
                            <span className="px-2 py-1 bg-primary/10 text-primary text-xs rounded-full">{getCategoryName(post.category)}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-text-secondary">{post.author}</td>
                        <td className="px-6 py-4 text-text-secondary">{formatTime(post.publishTime)}</td>
                        <td className="px-6 py-4">
                          <span className="px-2 py-1 bg-success/10 text-success text-xs rounded-full">{post.replies}</span>
                        </td>
                        <td className="px-6 py-4 text-text-secondary">{post.views}</td>
                        <td className="px-6 py-4 text-text-secondary">{formatTime(post.lastReplyTime)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* 分页区域 */}
            <div className="flex items-center justify-between">
              <div className="text-white/80 text-sm">
                显示 <span>{startItem}-{endItem}</span> 条，共 <span>{totalCount}</span> 条记录
              </div>
              <div className="flex items-center space-x-2">
                <button 
                  onClick={() => handlePageChange(currentPage - 1)}
                  disabled={currentPage <= 1}
                  className="px-3 py-1 border border-border-light rounded-lg text-white/80 hover:text-white hover:border-primary transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <i className="fas fa-chevron-left"></i>
                </button>
                <div className="flex items-center space-x-1">
                  {generatePageNumbers()}
                </div>
                <button 
                  onClick={() => handlePageChange(currentPage + 1)}
                  disabled={currentPage >= totalPages}
                  className="px-3 py-1 border border-border-light rounded-lg text-white/80 hover:text-white hover:border-primary transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <i className="fas fa-chevron-right"></i>
                </button>
              </div>
            </div>
          </div>
        </main>
      </div>

      {/* 发布新帖模态框 */}
      {isPublishModalVisible && (
        <div className="fixed inset-0 z-50">
          <div className={styles.modalBackdrop} onClick={() => setIsPublishModalVisible(false)}></div>
          <div className="relative flex items-center justify-center min-h-screen p-4">
            <div className="bg-white rounded-2xl shadow-gradient max-w-2xl w-full max-h-[90vh] overflow-y-auto">
              {/* 模态框头部 */}
              <div className="flex items-center justify-between p-6 border-b border-border-light">
                <h2 className="text-xl font-semibold text-text-primary">发布新帖</h2>
                <button 
                  onClick={() => setIsPublishModalVisible(false)}
                  className="p-2 text-text-secondary hover:text-text-primary transition-colors"
                >
                  <i className="fas fa-times"></i>
                </button>
              </div>
              
              {/* 模态框内容 */}
              <div className="p-6">
                <form className="space-y-4">
                  <div>
                    <label htmlFor="post-title" className="block text-sm font-medium text-text-primary mb-2">帖子标题 *</label>
                    <input 
                      type="text" 
                      id="post-title" 
                      value={formData.title}
                      onChange={(e) => setFormData({...formData, title: e.target.value})}
                      required
                      className="w-full px-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="post-category" className="block text-sm font-medium text-text-primary mb-2">分类 *</label>
                    <select 
                      id="post-category" 
                      value={formData.category}
                      onChange={(e) => setFormData({...formData, category: e.target.value})}
                      required
                      className="w-full px-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                    >
                      <option value="">请选择分类</option>
                      <option value="tech">技术交流</option>
                      <option value="project">项目分享</option>
                      <option value="experience">经验交流</option>
                      <option value="help">求助问答</option>
                      <option value="job">招聘信息</option>
                    </select>
                  </div>
                  
                  <div>
                    <label htmlFor="post-content" className="block text-sm font-medium text-text-primary mb-2">帖子内容 *</label>
                    <textarea 
                      id="post-content" 
                      rows={8}
                      value={formData.content}
                      onChange={(e) => setFormData({...formData, content: e.target.value})}
                      required
                      className="w-full px-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary resize-none"
                      placeholder="请详细描述您的问题或分享的内容..."
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-text-primary mb-2">上传图片（可选）</label>
                    <div className="border-2 border-dashed border-border-light rounded-xl p-6 text-center">
                      <i className="fas fa-cloud-upload-alt text-3xl text-text-secondary mb-2"></i>
                      <p className="text-text-secondary">点击或拖拽图片到此处上传</p>
                      <p className="text-xs text-text-secondary mt-1">支持 JPG、PNG 格式，最大 10MB</p>
                      <input type="file" multiple accept="image/*" className="hidden" />
                    </div>
                  </div>
                </form>
              </div>
              
              {/* 模态框底部 */}
              <div className="flex items-center justify-end space-x-3 p-6 border-t border-border-light">
                <button 
                  onClick={() => setIsPublishModalVisible(false)}
                  className="px-6 py-2 border border-border-light rounded-xl text-text-secondary hover:text-text-primary hover:border-primary transition-colors"
                >
                  取消
                </button>
                <button 
                  onClick={handleFormSubmit}
                  className="bg-gradient-primary text-white px-6 py-2 rounded-xl font-semibold hover:shadow-gradient transition-all"
                >
                  发布
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DiscussionForumPage;

