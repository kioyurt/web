

export interface DiscussionPost {
  id: number;
  title: string;
  author: string;
  category: string;
  publishTime: string;
  replies: number;
  views: number;
  lastReplyTime: string;
  isHot: boolean;
}

export interface FormData {
  title: string;
  category: string;
  content: string;
}

