

import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import styles from './styles.module.css';

const HomePage: React.FC = () => {
  const navigate = useNavigate();
  const [globalSearchValue, setGlobalSearchValue] = useState('');

  useEffect(() => {
    const originalTitle = document.title;
    document.title = '模学苑 - 多模态大模型学习平台';
    return () => { document.title = originalTitle; };
  }, []);

  const handleGlobalSearchKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      const keyword = globalSearchValue.trim();
      if (keyword) {
        navigate(`/search-results?q=${encodeURIComponent(keyword)}`);
      }
    }
  };

  const handleCourseCardClick = (courseId: string) => {
    navigate(`/course-detail?id=${courseId}`);
  };

  const handleNewsItemClick = (newsId: string) => {
    navigate(`/industry-news?id=${newsId}`);
  };

  const handleDiscussionPostClick = (postId: string) => {
    navigate(`/discussion-forum?id=${postId}`);
  };

  const handleStudyGroupClick = (groupId: string) => {
    navigate(`/study-group-detail?id=${groupId}`);
  };

  const handleStartLearningClick = () => {
    navigate('/course-list');
  };

  const handleUserAvatarClick = () => {
    navigate('/user-profile');
  };

  const handleNotificationClick = () => {
    // 通知功能待实现
  };

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <header className="fixed top-0 left-0 right-0 bg-white/90 backdrop-blur-md border-b border-border-light z-50">
        <div className="flex items-center justify-between px-6 py-3">
          {/* Logo区域 */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-primary rounded-xl flex items-center justify-center">
              <i className="fas fa-graduation-cap text-white text-lg"></i>
            </div>
            <h1 className={`text-xl font-bold ${styles.gradientText}`}>模学苑</h1>
          </div>
          
          {/* 主导航 */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/home" className="text-primary font-medium border-b-2 border-primary py-1">首页</Link>
            <Link to="/course-list" className="text-text-secondary hover:text-primary py-1 transition-colors">课程</Link>
            <Link to="/community-overview" className="text-text-secondary hover:text-primary py-1 transition-colors">社区</Link>
            <Link to="/resource-center" className="text-text-secondary hover:text-primary py-1 transition-colors">资源中心</Link>
          </nav>
          
          {/* 搜索和用户区域 */}
          <div className="flex items-center space-x-4">
            {/* 全局搜索 */}
            <div className="relative hidden lg:block">
              <input 
                type="text" 
                placeholder="搜索课程、资源..." 
                value={globalSearchValue}
                onChange={(e) => setGlobalSearchValue(e.target.value)}
                onKeyPress={handleGlobalSearchKeyPress}
                className="w-80 pl-10 pr-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary"></i>
            </div>
            
            {/* 消息通知 */}
            <button 
              onClick={handleNotificationClick}
              className="relative p-2 text-text-secondary hover:text-primary transition-colors"
            >
              <i className="fas fa-bell text-lg"></i>
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-danger rounded-full"></span>
            </button>
            
            {/* 用户头像 */}
            <div 
              onClick={handleUserAvatarClick}
              className="flex items-center space-x-2 cursor-pointer"
            >
              <img 
                src="https://s.coze.cn/image/V3UayeVoarg/" 
                alt="用户头像" 
                className="w-8 h-8 rounded-full border-2 border-primary/20"
              />
              <span className="hidden md:block text-text-primary font-medium">张同学</span>
              <i className="fas fa-chevron-down text-text-secondary text-sm"></i>
            </div>
          </div>
        </div>
      </header>

      <div className="flex pt-16">
        {/* 左侧菜单 */}
        <aside className={`fixed left-0 top-16 bottom-0 w-60 ${styles.sidebarGradient} text-white overflow-y-auto`}>
          <div className="p-4">
            <nav className="space-y-2">
              <Link to="/home" className="flex items-center space-x-3 px-4 py-3 rounded-xl bg-white/20 backdrop-blur-sm">
                <i className="fas fa-home text-lg"></i>
                <span className="font-medium">首页</span>
              </Link>
              <Link to="/course-list" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-book text-lg"></i>
                <span>课程中心</span>
              </Link>
              <Link to="/community-overview" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-users text-lg"></i>
                <span>社区互动</span>
              </Link>
              <Link to="/resource-center" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-database text-lg"></i>
                <span>资源中心</span>
              </Link>
              <Link to="/user-profile" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-user text-lg"></i>
                <span>个人中心</span>
              </Link>
            </nav>
            
            {/* 学习进度卡片 */}
            <div className="mt-8 p-4 bg-white/10 backdrop-blur-sm rounded-xl">
              <h3 className="font-semibold mb-3">今日学习</h3>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>进度</span>
                  <span>75%</span>
                </div>
                <div className="w-full bg-white/20 rounded-full h-2">
                  <div className="bg-white h-2 rounded-full" style={{width: '75%'}}></div>
                </div>
                <div className="flex justify-between text-sm">
                  <span>已学时长</span>
                  <span>2.5小时</span>
                </div>
              </div>
            </div>
          </div>
        </aside>

        {/* 主内容区域 */}
        <main className="flex-1 ml-60 min-h-screen">
          <div className="max-w-7xl mx-auto p-6">
            {/* 页面头部 */}
            <div className="mb-6">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-3xl font-bold text-white mb-2">欢迎回来，张同学！</h1>
                  <nav className="text-white/80">
                    <span>首页</span>
                  </nav>
                </div>
                <div className="hidden xl:flex items-center space-x-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-white">12</div>
                    <div className="text-sm text-white/80">已学课程</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-white">86</div>
                    <div className="text-sm text-white/80">学习时长(h)</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-white">5</div>
                    <div className="text-sm text-white/80">获得证书</div>
                  </div>
                </div>
              </div>
            </div>

            {/* 轮播图/焦点图 */}
            <section className="mb-8">
              <div className="relative h-80 rounded-2xl overflow-hidden shadow-gradient">
                <div className="absolute inset-0 bg-gradient-to-r from-primary/90 to-secondary/90"></div>
                <div className="relative z-10 h-full flex items-center justify-between px-12">
                  <div className="text-white max-w-lg">
                    <h2 className="text-4xl font-bold mb-4">掌握多模态大模型技术</h2>
                    <p className="text-xl mb-6 text-white/90">从入门到进阶，系统学习前沿AI技术</p>
                    <button 
                      onClick={handleStartLearningClick}
                      className="bg-white text-primary px-8 py-3 rounded-xl font-semibold hover:bg-gray-50 transition-colors"
                    >
                      开始学习
                    </button>
                  </div>
                  <div className="hidden lg:block">
                    <img 
                      src="https://s.coze.cn/image/OLllTcYz4fc/" 
                      alt="AI技术展示" 
                      className={`w-96 h-64 object-cover rounded-xl ${styles.animateFloat}`}
                    />
                  </div>
                </div>
              </div>
            </section>

            {/* 课程推荐区 */}
            <section className="mb-8">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-white">精选课程</h2>
                <Link to="/course-list" className="text-white/80 hover:text-white transition-colors">
                  查看全部 <i className="fas fa-arrow-right ml-1"></i>
                </Link>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {/* 课程卡片1 */}
                <div 
                  onClick={() => handleCourseCardClick('course1')}
                  className={`${styles.cardGradient} rounded-2xl p-6 shadow-card hover:shadow-card-hover transition-all cursor-pointer`}
                >
                  <div className="relative mb-4">
                    <img 
                      src="https://s.coze.cn/image/7nw-jajEZAw/" 
                      alt="GPT-4V多模态入门" 
                      className="w-full h-48 object-cover rounded-xl"
                    />
                    <div className="absolute top-3 right-3 bg-primary text-white px-2 py-1 rounded-lg text-sm">
                      入门
                    </div>
                  </div>
                  <h3 className="font-semibold text-text-primary mb-2">GPT-4V多模态入门实战</h3>
                  <p className="text-text-secondary text-sm mb-3">从零开始学习GPT-4V的多模态能力</p>
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center space-x-1">
                      <i className="fas fa-star text-warning"></i>
                      <span className="text-text-secondary">4.8</span>
                    </div>
                    <span className="text-text-secondary">1.2万人学习</span>
                  </div>
                </div>

                {/* 课程卡片2 */}
                <div 
                  onClick={() => handleCourseCardClick('course2')}
                  className={`${styles.cardGradient} rounded-2xl p-6 shadow-card hover:shadow-card-hover transition-all cursor-pointer`}
                >
                  <div className="relative mb-4">
                    <img 
                      src="https://s.coze.cn/image/WVWFtoD5hvc/" 
                      alt="CLIP模型训练" 
                      className="w-full h-48 object-cover rounded-xl"
                    />
                    <div className="absolute top-3 right-3 bg-secondary text-white px-2 py-1 rounded-lg text-sm">
                      中级
                    </div>
                  </div>
                  <h3 className="font-semibold text-text-primary mb-2">CLIP模型训练与应用</h3>
                  <p className="text-text-secondary text-sm mb-3">深入理解CLIP模型的工作原理</p>
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center space-x-1">
                      <i className="fas fa-star text-warning"></i>
                      <span className="text-text-secondary">4.9</span>
                    </div>
                    <span className="text-text-secondary">8.5k人学习</span>
                  </div>
                </div>

                {/* 课程卡片3 */}
                <div 
                  onClick={() => handleCourseCardClick('course3')}
                  className={`${styles.cardGradient} rounded-2xl p-6 shadow-card hover:shadow-card-hover transition-all cursor-pointer`}
                >
                  <div className="relative mb-4">
                    <img 
                      src="https://s.coze.cn/image/z2gYoinaSNA/" 
                      alt="DALL-E图像生成" 
                      className="w-full h-48 object-cover rounded-xl"
                    />
                    <div className="absolute top-3 right-3 bg-tertiary text-white px-2 py-1 rounded-lg text-sm">
                      高级
                    </div>
                  </div>
                  <h3 className="font-semibold text-text-primary mb-2">DALL-E图像生成技术</h3>
                  <p className="text-text-secondary text-sm mb-3">掌握文本到图像的生成技术</p>
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center space-x-1">
                      <i className="fas fa-star text-warning"></i>
                      <span className="text-text-secondary">4.7</span>
                    </div>
                    <span className="text-text-secondary">6.3k人学习</span>
                  </div>
                </div>

                {/* 课程卡片4 */}
                <div 
                  onClick={() => handleCourseCardClick('course4')}
                  className={`${styles.cardGradient} rounded-2xl p-6 shadow-card hover:shadow-card-hover transition-all cursor-pointer`}
                >
                  <div className="relative mb-4">
                    <img 
                      src="https://s.coze.cn/image/9LmkFSZCrDk/" 
                      alt="多模态模型部署" 
                      className="w-full h-48 object-cover rounded-xl"
                    />
                    <div className="absolute top-3 right-3 bg-success text-white px-2 py-1 rounded-lg text-sm">
                      实战
                    </div>
                  </div>
                  <h3 className="font-semibold text-text-primary mb-2">多模态模型部署优化</h3>
                  <p className="text-text-secondary text-sm mb-3">生产环境下的模型部署最佳实践</p>
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center space-x-1">
                      <i className="fas fa-star text-warning"></i>
                      <span className="text-text-secondary">4.6</span>
                    </div>
                    <span className="text-text-secondary">4.2k人学习</span>
                  </div>
                </div>
              </div>
            </section>

            {/* 最新资讯区 */}
            <section className="mb-8">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-white">最新资讯</h2>
                <Link to="/industry-news" className="text-white/80 hover:text-white transition-colors">
                  查看全部 <i className="fas fa-arrow-right ml-1"></i>
                </Link>
              </div>
              
              <div className="space-y-4">
                <div 
                  onClick={() => handleNewsItemClick('news1')}
                  className={`${styles.cardGradient} rounded-xl p-6 shadow-card hover:shadow-card-hover transition-all cursor-pointer`}
                >
                  <div className="flex items-start space-x-4">
                    <img 
                      src="https://s.coze.cn/image/1CvIga41Z1c/" 
                      alt="AI技术突破" 
                      className="w-28 h-20 object-cover rounded-lg flex-shrink-0"
                    />
                    <div className="flex-1">
                      <h3 className="font-semibold text-text-primary mb-2">GPT-5即将发布，多模态能力再次突破</h3>
                      <p className="text-text-secondary text-sm mb-2">OpenAI宣布GPT-5将在明年初发布，将具备更强的多模态理解和生成能力...</p>
                      <div className="flex items-center space-x-4 text-sm text-text-secondary">
                        <span><i className="fas fa-calendar mr-1"></i>2024-01-15</span>
                        <span><i className="fas fa-eye mr-1"></i>2.3k阅读</span>
                        <span><i className="fas fa-tag mr-1"></i>技术动态</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div 
                  onClick={() => handleNewsItemClick('news2')}
                  className={`${styles.cardGradient} rounded-xl p-6 shadow-card hover:shadow-card-hover transition-all cursor-pointer`}
                >
                  <div className="flex items-start space-x-4">
                    <img 
                      src="https://s.coze.cn/image/pVkBWsZaFn0/" 
                      alt="研究论文" 
                      className="w-28 h-20 object-cover rounded-lg flex-shrink-0"
                    />
                    <div className="flex-1">
                      <h3 className="font-semibold text-text-primary mb-2">谷歌发布新的多模态Transformer架构</h3>
                      <p className="text-text-secondary text-sm mb-2">谷歌AI团队在最新论文中提出了一种新的多模态Transformer架构，在多项基准测试中取得了SOTA...</p>
                      <div className="flex items-center space-x-4 text-sm text-text-secondary">
                        <span><i className="fas fa-calendar mr-1"></i>2024-01-14</span>
                        <span><i className="fas fa-eye mr-1"></i>1.8k阅读</span>
                        <span><i className="fas fa-tag mr-1"></i>研究成果</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div 
                  onClick={() => handleNewsItemClick('news3')}
                  className={`${styles.cardGradient} rounded-xl p-6 shadow-card hover:shadow-card-hover transition-all cursor-pointer`}
                >
                  <div className="flex items-start space-x-4">
                    <img 
                      src="https://s.coze.cn/image/qNFcreysNCM/" 
                      alt="应用案例" 
                      className="w-28 h-20 object-cover rounded-lg flex-shrink-0"
                    />
                    <div className="flex-1">
                      <h3 className="font-semibold text-text-primary mb-2">多模态AI在医疗诊断中的最新应用</h3>
                      <p className="text-text-secondary text-sm mb-2">某知名医院成功应用多模态AI技术，将诊断准确率提升了25%，为患者带来了更好的治疗效果...</p>
                      <div className="flex items-center space-x-4 text-sm text-text-secondary">
                        <span><i className="fas fa-calendar mr-1"></i>2024-01-13</span>
                        <span><i className="fas fa-eye mr-1"></i>3.1k阅读</span>
                        <span><i className="fas fa-tag mr-1"></i>应用案例</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* 社区动态区 */}
            <section className="mb-8">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-white">社区动态</h2>
                <Link to="/community-overview" className="text-white/80 hover:text-white transition-colors">
                  查看全部 <i className="fas fa-arrow-right ml-1"></i>
                </Link>
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* 热门讨论 */}
                <div className={`${styles.cardGradient} rounded-xl p-6 shadow-card`}>
                  <h3 className="font-semibold text-text-primary mb-4 flex items-center">
                    <i className="fas fa-fire text-danger mr-2"></i>
                    热门讨论
                  </h3>
                  <div className="space-y-3">
                    <div 
                      onClick={() => handleDiscussionPostClick('post1')}
                      className="border-b border-border-light pb-3 last:border-b-0 last:pb-0 cursor-pointer"
                    >
                      <h4 className="text-sm font-medium text-text-primary mb-1">如何选择适合的多模态模型？</h4>
                      <div className="flex items-center space-x-3 text-xs text-text-secondary">
                        <span>AI学习者</span>
                        <span>23回复</span>
                        <span>1.2k浏览</span>
                      </div>
                    </div>
                    <div 
                      onClick={() => handleDiscussionPostClick('post2')}
                      className="border-b border-border-light pb-3 last:border-b-0 last:pb-0 cursor-pointer"
                    >
                      <h4 className="text-sm font-medium text-text-primary mb-1">分享我的CLIP模型训练经验</h4>
                      <div className="flex items-center space-x-3 text-xs text-text-secondary">
                        <span>数据科学家</span>
                        <span>18回复</span>
                        <span>856浏览</span>
                      </div>
                    </div>
                    <div 
                      onClick={() => handleDiscussionPostClick('post3')}
                      className="border-b border-border-light pb-3 last:border-b-0 last:pb-0 cursor-pointer"
                    >
                      <h4 className="text-sm font-medium text-text-primary mb-1">多模态模型部署遇到的问题</h4>
                      <div className="flex items-center space-x-3 text-xs text-text-secondary">
                        <span>后端工程师</span>
                        <span>31回复</span>
                        <span>2.1k浏览</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* 活跃小组 */}
                <div className={`${styles.cardGradient} rounded-xl p-6 shadow-card`}>
                  <h3 className="font-semibold text-text-primary mb-4 flex items-center">
                    <i className="fas fa-users text-primary mr-2"></i>
                    活跃小组
                  </h3>
                  <div className="space-y-3">
                    <div 
                      onClick={() => handleStudyGroupClick('group1')}
                      className="border-b border-border-light pb-3 last:border-b-0 last:pb-0 cursor-pointer"
                    >
                      <h4 className="text-sm font-medium text-text-primary mb-1">GPT-4V开发者交流群</h4>
                      <div className="flex items-center space-x-3 text-xs text-text-secondary">
                        <span>156名成员</span>
                        <span>今日活跃</span>
                      </div>
                    </div>
                    <div 
                      onClick={() => handleStudyGroupClick('group2')}
                      className="border-b border-border-light pb-3 last:border-b-0 last:pb-0 cursor-pointer"
                    >
                      <h4 className="text-sm font-medium text-text-primary mb-1">多模态模型训练实战</h4>
                      <div className="flex items-center space-x-3 text-xs text-text-secondary">
                        <span>89名成员</span>
                        <span>昨日活跃</span>
                      </div>
                    </div>
                    <div 
                      onClick={() => handleStudyGroupClick('group3')}
                      className="border-b border-border-light pb-3 last:border-b-0 last:pb-0 cursor-pointer"
                    >
                      <h4 className="text-sm font-medium text-text-primary mb-1">AI绘画技术分享</h4>
                      <div className="flex items-center space-x-3 text-xs text-text-secondary">
                        <span>203名成员</span>
                        <span>3天前活跃</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          </div>
        </main>

        {/* 右侧面板 (仅在大屏幕显示) */}
        <aside className="hidden xl:block fixed right-0 top-16 bottom-0 w-80 bg-white/90 backdrop-blur-md border-l border-border-light overflow-y-auto">
          <div className="p-6">
            {/* 热门课程排行榜 */}
            <div className="mb-8">
              <h3 className="font-semibold text-text-primary mb-4 flex items-center">
                <i className="fas fa-trophy text-warning mr-2"></i>
                热门课程排行
              </h3>
              <div className="space-y-3">
                <div 
                  onClick={() => handleCourseCardClick('course1')}
                  className="flex items-center space-x-3 p-3 rounded-lg hover:bg-bg-secondary transition-colors cursor-pointer"
                >
                  <div className="w-6 h-6 bg-gradient-primary rounded-full flex items-center justify-center text-white text-xs font-bold">1</div>
                  <div className="flex-1">
                    <h4 className="text-sm font-medium text-text-primary">GPT-4V多模态入门</h4>
                    <p className="text-xs text-text-secondary">1.2万人学习</p>
                  </div>
                </div>
                <div 
                  onClick={() => handleCourseCardClick('course2')}
                  className="flex items-center space-x-3 p-3 rounded-lg hover:bg-bg-secondary transition-colors cursor-pointer"
                >
                  <div className="w-6 h-6 bg-gradient-secondary rounded-full flex items-center justify-center text-white text-xs font-bold">2</div>
                  <div className="flex-1">
                    <h4 className="text-sm font-medium text-text-primary">CLIP模型训练</h4>
                    <p className="text-xs text-text-secondary">8.5k人学习</p>
                  </div>
                </div>
                <div 
                  onClick={() => handleCourseCardClick('course3')}
                  className="flex items-center space-x-3 p-3 rounded-lg hover:bg-bg-secondary transition-colors cursor-pointer"
                >
                  <div className="w-6 h-6 bg-gradient-tertiary rounded-full flex items-center justify-center text-white text-xs font-bold">3</div>
                  <div className="flex-1">
                    <h4 className="text-sm font-medium text-text-primary">DALL-E图像生成</h4>
                    <p className="text-xs text-text-secondary">6.3k人学习</p>
                  </div>
                </div>
              </div>
            </div>

            {/* 最新公告 */}
            <div className="mb-8">
              <h3 className="font-semibold text-text-primary mb-4 flex items-center">
                <i className="fas fa-bullhorn text-info mr-2"></i>
                最新公告
              </h3>
              <div className="space-y-3">
                <div className="p-3 bg-gradient-to-r from-primary/10 to-secondary/10 rounded-lg">
                  <h4 className="text-sm font-medium text-text-primary mb-1">🎉 新功能上线</h4>
                  <p className="text-xs text-text-secondary">在线代码编辑器功能正式上线，支持实时运行多模态模型代码</p>
                  <span className="text-xs text-text-secondary">2小时前</span>
                </div>
                <div className="p-3 bg-gradient-to-r from-success/10 to-tertiary/10 rounded-lg">
                  <h4 className="text-sm font-medium text-text-primary mb-1">📚 新课程发布</h4>
                  <p className="text-xs text-text-secondary">《多模态大模型评估与优化》课程已上线，限时免费</p>
                  <span className="text-xs text-text-secondary">1天前</span>
                </div>
              </div>
            </div>

            {/* 快速入口 */}
            <div>
              <h3 className="font-semibold text-text-primary mb-4 flex items-center">
                <i className="fas fa-rocket text-success mr-2"></i>
                快速入口
              </h3>
              <div className="grid grid-cols-2 gap-3">
                <Link to="/user-profile" className="p-3 bg-gradient-card rounded-lg text-center hover:shadow-card transition-all">
                  <i className="fas fa-bookmark text-primary text-lg mb-1"></i>
                  <p className="text-xs text-text-primary">我的收藏</p>
                </Link>
                <Link to="/user-profile" className="p-3 bg-gradient-card rounded-lg text-center hover:shadow-card transition-all">
                  <i className="fas fa-history text-secondary text-lg mb-1"></i>
                  <p className="text-xs text-text-primary">学习记录</p>
                </Link>
                <Link to="/community-overview" className="p-3 bg-gradient-card rounded-lg text-center hover:shadow-card transition-all">
                  <i className="fas fa-question-circle text-tertiary text-lg mb-1"></i>
                  <p className="text-xs text-text-primary">问答社区</p>
                </Link>
                <Link to="/resource-center" className="p-3 bg-gradient-card rounded-lg text-center hover:shadow-card transition-all">
                  <i className="fas fa-download text-success text-lg mb-1"></i>
                  <p className="text-xs text-text-primary">资源下载</p>
                </Link>
              </div>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
};

export default HomePage;

