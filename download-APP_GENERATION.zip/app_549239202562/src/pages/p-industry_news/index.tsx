

import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import styles from './styles.module.css';

interface NewsItem {
  id: string;
  title: string;
  type: string;
  source: string;
  date: string;
  views: string;
  readTime: string;
  image: string;
  content: string;
  category: string;
}

interface NewsDetail extends Omit<NewsItem, 'id' | 'category'> {}

const IndustryNewsPage: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const newsId = searchParams.get('id');

  const [isNewsDetailView, setIsNewsDetailView] = useState(false);
  const [currentNewsDetail, setCurrentNewsDetail] = useState<NewsDetail | null>(null);
  const [newsSearchKeyword, setNewsSearchKeyword] = useState('');
  const [selectedNewsType, setSelectedNewsType] = useState('');
  const [selectedTimeFilter, setSelectedTimeFilter] = useState('');
  const [selectedSortOrder, setSelectedSortOrder] = useState('latest');

  // 模拟资讯数据
  const newsData: NewsItem[] = [
    {
      id: 'news1',
      title: 'GPT-5即将发布，多模态能力再次突破',
      type: '技术动态',
      source: 'OpenAI',
      date: '2024-01-15',
      views: '2.3k',
      readTime: '5分钟',
      image: 'https://s.coze.cn/image/bFls-vQgG4Y/',
      content: `
        <p>OpenAI在最新的开发者大会上正式宣布，GPT-5将于2024年初发布。这是继GPT-4V之后，OpenAI在多模态大模型领域的又一次重大突破。</p>
        
        <h2>主要功能升级</h2>
        <ul>
          <li><strong>更强的多模态理解能力</strong>：能够同时处理文本、图像、音频和视频输入</li>
          <li><strong>更高的推理能力</strong>：在数学、逻辑推理等任务上有显著提升</li>
          <li><strong>更快的响应速度</strong>：推理速度提升30%，支持实时交互</li>
          <li><strong>更低的幻觉率</strong>：事实准确性大幅提升</li>
        </ul>

        <h2>技术架构改进</h2>
        <p>GPT-5采用了全新的混合专家模型架构，结合了Transformer和MoE（Mixture of Experts）技术，在保持模型性能的同时显著降低了计算成本。</p>

        <h2>应用前景</h2>
        <p>新模型将在教育、医疗、创意设计、软件开发等多个领域带来革命性变化。特别是在个性化教育和智能医疗诊断方面，GPT-5有望提供前所未有的服务质量。</p>

        <h2>发布时间表</h2>
        <p>OpenAI计划在2024年第一季度发布GPT-5的beta版本，面向开发者开放API接口。正式版预计将在第二季度发布，届时将提供更完整的功能支持。</p>
      `,
      category: '商业科技'
    },
    {
      id: 'news2',
      title: '谷歌发布新的多模态Transformer架构',
      type: '研究成果',
      source: 'Google AI',
      date: '2024-01-14',
      views: '1.8k',
      readTime: '8分钟',
      image: 'https://s.coze.cn/image/JxIDQTj4wK0/',
      content: `
        <p>谷歌AI团队在最新论文中提出了一种新的多模态Transformer架构，在多项基准测试中取得了SOTA结果，特别是在跨模态理解任务上表现优异。</p>
        
        <h2>架构创新点</h2>
        <ul>
          <li><strong>动态模态融合</strong>：根据输入内容自动调整模态融合策略</li>
          <li><strong>注意力机制优化</strong>：改进的跨模态注意力机制，提升特征对齐效果</li>
          <li><strong>轻量化设计</strong>：模型参数量减少40%，推理速度提升60%</li>
        </ul>

        <h2>实验结果</h2>
        <p>在MSCOCO、Flickr30K等标准数据集上，新架构在图像描述生成、视觉问答等任务中均超越了现有最佳模型，平均性能提升15-20%。</p>

        <h2>开源计划</h2>
        <p>谷歌计划在论文正式发表后开源该架构的预训练模型和训练代码，为学术界和工业界提供更好的多模态研究工具。</p>
      `,
      category: '商业科技'
    },
    {
      id: 'news3',
      title: '多模态AI在医疗诊断中的最新应用',
      type: '应用案例',
      source: '某知名医院',
      date: '2024-01-13',
      views: '3.1k',
      readTime: '6分钟',
      image: 'https://s.coze.cn/image/mqVONS8Xh6c/',
      content: `
        <p>某知名医院成功应用多模态AI技术，将诊断准确率提升了25%，为患者带来了更好的治疗效果，特别是在癌症早期筛查方面取得重大突破。</p>
        
        <h2>技术应用</h2>
        <ul>
          <li><strong>医学影像分析</strong>：结合CT、MRI、病理切片等多模态数据</li>
          <li><strong>临床数据整合</strong>：电子病历、实验室检查结果智能分析</li>
          <li><strong>治疗方案推荐</strong>：基于多模态分析的个性化治疗建议</li>
        </ul>

        <h2>实施效果</h2>
        <p>在为期6个月的临床试验中，多模态AI系统帮助医生：</p>
        <ul>
          <li>早期癌症检出率提升35%</li>
          <li>诊断时间缩短60%</li>
          <li>误诊率降低40%</li>
          <li>患者满意度提升28%</li>
        </ul>

        <h2>未来展望</h2>
        <p>该医院计划在未来一年内将该技术推广到更多科室，并与其他医疗机构合作，推动AI辅助诊断技术的标准化和普及化。</p>
      `,
      category: '商业科技'
    },
    {
      id: 'news4',
      title: '多模态大模型的注意力机制优化研究',
      type: '前沿论文',
      source: 'arXiv',
      date: '2024-01-12',
      views: '1.2k',
      readTime: '12分钟',
      image: 'https://s.coze.cn/image/GcVY14LhQGM/',
      content: `
        <p>最新发表在arXiv上的论文深入分析了多模态大模型中的注意力机制，提出了一种新的跨模态注意力优化方法，显著提升了模型性能。</p>
        
        <h2>研究背景</h2>
        <p>现有多模态模型在处理不同类型数据时，往往存在模态间信息对齐不充分的问题。传统的注意力机制难以有效捕捉跨模态的语义关联。</p>

        <h2>创新方法</h2>
        <ul>
          <li><strong>动态模态权重</strong>：根据输入模态的重要性自动调整注意力权重</li>
          <li><strong>跨模态注意力池化</strong>：改进的池化策略，保留更丰富的模态信息</li>
          <li><strong>注意力正则化</strong>：防止过拟合，提升模型泛化能力</li>
        </ul>

        <h2>实验验证</h2>
        <p>在多个标准数据集上的实验表明，新方法：</p>
        <ul>
          <li>平均准确率提升8-12%</li>
          <li>训练收敛速度加快30%</li>
          <li>模型鲁棒性显著提升</li>
        </ul>

        <h2>代码开源</h2>
        <p>作者已在GitHub上开源了相关代码和预训练模型，为后续研究提供了良好的基础。</p>
      `,
      category: '商业科技'
    },
    {
      id: 'news5',
      title: 'Meta发布Code Llama 2：支持多模态代码生成',
      type: '技术动态',
      source: 'Meta AI',
      date: '2024-01-11',
      views: '2.7k',
      readTime: '7分钟',
      image: 'https://s.coze.cn/image/3U9FsvYO6f8/',
      content: `
        <p>Meta正式发布Code Llama 2，这是一个支持多模态输入的代码生成模型，能够理解自然语言描述并生成相应的代码实现，同时还能处理图像和文档输入。</p>
        
        <h2>核心功能</h2>
        <ul>
          <li><strong>多模态代码生成</strong>：支持文本、图像、文档输入</li>
          <li><strong>跨语言支持</strong>：支持20多种编程语言</li>
          <li><strong>代码补全</strong>：智能代码补全和错误修复</li>
          <li><strong>文档生成</strong>：自动生成API文档和注释</li>
        </ul>

        <h2>技术特点</h2>
        <p>Code Llama 2基于Llama 2架构扩展，专门针对代码生成任务进行了优化：</p>
        <ul>
          <li>参数量从7B到70B不等，满足不同场景需求</li>
          <li>在HumanEval等代码基准测试中达到90%以上的准确率</li>
          <li>支持实时交互和增量生成</li>
        </ul>

        <h2>开源许可</h2>
        <p>Code Llama 2采用商业友好的开源许可，允许企业和开发者免费使用，包括商业用途，但需要遵守相应的使用规范。</p>

        <h2>应用场景</h2>
        <p>该模型将在软件开发、教育、技术文档编写等领域发挥重要作用，特别是在辅助编程教学和提升开发效率方面具有巨大潜力。</p>
      `,
      category: '商业科技'
    }
  ];

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = '行业资讯 - 模学苑';
    return () => { document.title = originalTitle; };
  }, []);

  // 处理URL参数
  useEffect(() => {
    if (newsId) {
      const newsItem = newsData.find(item => item.id === newsId);
      if (newsItem) {
        const { id, category, ...detail } = newsItem;
        setCurrentNewsDetail(detail);
        setIsNewsDetailView(true);
      }
    }
  }, [newsId]);

  // 处理浏览器历史记录
  useEffect(() => {
    const handlePopState = (event: PopStateEvent) => {
      if (event.state && event.state.id) {
        const newsItem = newsData.find(item => item.id === event.state.id);
        if (newsItem) {
          const { id, category, ...detail } = newsItem;
          setCurrentNewsDetail(detail);
          setIsNewsDetailView(true);
        }
      } else {
        setIsNewsDetailView(false);
        setCurrentNewsDetail(null);
      }
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  // 获取资讯类型样式
  const getNewsTypeStyle = (type: string) => {
    switch(type) {
      case '技术动态':
        return 'bg-gradient-to-r from-primary/10 to-secondary/10 text-primary';
      case '研究成果':
        return 'bg-gradient-to-r from-success/10 to-tertiary/10 text-success';
      case '应用案例':
        return 'bg-gradient-to-r from-tertiary/10 to-info/10 text-tertiary';
      case '前沿论文':
        return 'bg-gradient-to-r from-warning/10 to-danger/10 text-warning';
      default:
        return 'bg-gradient-to-r from-primary/10 to-secondary/10 text-primary';
    }
  };

  // 搜索和筛选逻辑
  const filteredNews = newsData.filter(item => {
    const matchesSearch = newsSearchKeyword === '' || 
      item.title.toLowerCase().includes(newsSearchKeyword.toLowerCase()) ||
      item.content.toLowerCase().includes(newsSearchKeyword.toLowerCase());
    
    const matchesType = selectedNewsType === '' || {
      'technology': '技术动态',
      'research': '研究成果', 
      'application': '应用案例',
      'paper': '前沿论文'
    }[selectedNewsType] === item.type;

    return matchesSearch && matchesType;
  });

  // 排序逻辑
  const sortedNews = [...filteredNews].sort((a, b) => {
    if (selectedSortOrder === 'latest') {
      return new Date(b.date).getTime() - new Date(a.date).getTime();
    } else {
      const viewsA = parseFloat(a.views);
      const viewsB = parseFloat(b.views);
      return viewsB - viewsA;
    }
  });

  // 处理全局搜索
  const handleGlobalSearch = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      const keyword = (e.target as HTMLInputElement).value.trim();
      if (keyword) {
        navigate(`/search-results?q=${encodeURIComponent(keyword)}`);
      }
    }
  };

  // 处理资讯项点击
  const handleNewsItemClick = (newsId: string) => {
    const newsItem = newsData.find(item => item.id === newsId);
    if (newsItem) {
      const { id, category, ...detail } = newsItem;
      setCurrentNewsDetail(detail);
      setIsNewsDetailView(true);
      navigate(`/industry-news?id=${newsId}`, { state: { id: newsId } });
    }
  };

  // 处理返回列表
  const handleBackToList = () => {
    setIsNewsDetailView(false);
    setCurrentNewsDetail(null);
    navigate('/industry-news');
  };

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <header className="fixed top-0 left-0 right-0 bg-white/90 backdrop-blur-md border-b border-border-light z-50">
        <div className="flex items-center justify-between px-6 py-3">
          {/* Logo区域 */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-primary rounded-xl flex items-center justify-center">
              <i className="fas fa-graduation-cap text-white text-lg"></i>
            </div>
            <h1 className={`text-xl font-bold ${styles.gradientText}`}>模学苑</h1>
          </div>
          
          {/* 主导航 */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/home" className="text-text-secondary hover:text-primary py-1 transition-colors">首页</Link>
            <Link to="/course-list" className="text-text-secondary hover:text-primary py-1 transition-colors">课程</Link>
            <Link to="/community-overview" className="text-text-secondary hover:text-primary py-1 transition-colors">社区</Link>
            <Link to="/resource-center" className="text-primary font-medium border-b-2 border-primary py-1">资源中心</Link>
          </nav>
          
          {/* 搜索和用户区域 */}
          <div className="flex items-center space-x-4">
            {/* 全局搜索 */}
            <div className="relative hidden lg:block">
              <input 
                type="text" 
                placeholder="搜索课程、资源..." 
                className="w-80 pl-10 pr-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                onKeyPress={handleGlobalSearch}
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary"></i>
            </div>
            
            {/* 消息通知 */}
            <button className="relative p-2 text-text-secondary hover:text-primary transition-colors">
              <i className="fas fa-bell text-lg"></i>
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-danger rounded-full"></span>
            </button>
            
            {/* 用户头像 */}
            <div className="flex items-center space-x-2 cursor-pointer">
              <img 
                src="https://s.coze.cn/image/0Yp_IqsQGnM/" 
                alt="用户头像" 
                className="w-8 h-8 rounded-full border-2 border-primary/20"
              />
              <span className="hidden md:block text-text-primary font-medium">张同学</span>
              <i className="fas fa-chevron-down text-text-secondary text-sm"></i>
            </div>
          </div>
        </div>
      </header>

      <div className="flex pt-16">
        {/* 左侧菜单 */}
        <aside className={`fixed left-0 top-16 bottom-0 w-60 ${styles.sidebarGradient} text-white overflow-y-auto`}>
          <div className="p-4">
            <nav className="space-y-2">
              <Link to="/home" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-home text-lg"></i>
                <span>首页</span>
              </Link>
              <Link to="/course-list" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-book text-lg"></i>
                <span>课程中心</span>
              </Link>
              <Link to="/community-overview" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-users text-lg"></i>
                <span>社区互动</span>
              </Link>
              <Link to="/resource-center" className="flex items-center space-x-3 px-4 py-3 rounded-xl bg-white/20 backdrop-blur-sm">
                <i className="fas fa-database text-lg"></i>
                <span>资源中心</span>
              </Link>
              <Link to="/user-profile" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-user text-lg"></i>
                <span>个人中心</span>
              </Link>
            </nav>
            
            {/* 学习进度卡片 */}
            <div className="mt-8 p-4 bg-white/10 backdrop-blur-sm rounded-xl">
              <h3 className="font-semibold mb-3">今日学习</h3>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>进度</span>
                  <span>75%</span>
                </div>
                <div className="w-full bg-white/20 rounded-full h-2">
                  <div className="bg-white h-2 rounded-full" style={{width: '75%'}}></div>
                </div>
                <div className="flex justify-between text-sm">
                  <span>已学时长</span>
                  <span>2.5小时</span>
                </div>
              </div>
            </div>
          </div>
        </aside>

        {/* 主内容区域 */}
        <main className="flex-1 ml-60 min-h-screen">
          <div className="max-w-7xl mx-auto p-6">
            {/* 页面头部 */}
            <div className="mb-6">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-3xl font-bold text-white mb-2">
                    {isNewsDetailView ? '资讯详情' : '行业资讯'}
                  </h1>
                  <nav className="text-white/80">
                    <Link to="/home" className="hover:text-white transition-colors">首页</Link>
                    <span className="mx-2">/</span>
                    <Link to="/resource-center" className="hover:text-white transition-colors">资源中心</Link>
                    <span className="mx-2">/</span>
                    <span>{isNewsDetailView ? '资讯详情' : '行业资讯'}</span>
                  </nav>
                </div>
              </div>
            </div>

            {/* 资讯列表视图 */}
            {!isNewsDetailView && (
              <div className="mb-8">
                {/* 工具栏区域 */}
                <div className={`${styles.cardGradient} rounded-xl p-6 shadow-card mb-6`}>
                  <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
                    {/* 搜索和筛选 */}
                    <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-3 sm:space-y-0 sm:space-x-4">
                      {/* 搜索框 */}
                      <div className="relative">
                        <input 
                          type="text" 
                          placeholder="搜索资讯标题、内容..." 
                          className="w-full sm:w-80 pl-10 pr-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                          value={newsSearchKeyword}
                          onChange={(e) => setNewsSearchKeyword(e.target.value)}
                        />
                        <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary"></i>
                      </div>
                      
                      {/* 筛选条件 */}
                      <div className="flex items-center space-x-3">
                        <select 
                          className="px-4 py-2 border border-border-light rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                          value={selectedNewsType}
                          onChange={(e) => setSelectedNewsType(e.target.value)}
                        >
                          <option value="">全部类型</option>
                          <option value="research">研究成果</option>
                          <option value="technology">技术动态</option>
                          <option value="application">应用案例</option>
                          <option value="paper">前沿论文</option>
                        </select>
                        
                        <select 
                          className="px-4 py-2 border border-border-light rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                          value={selectedTimeFilter}
                          onChange={(e) => setSelectedTimeFilter(e.target.value)}
                        >
                          <option value="">全部时间</option>
                          <option value="today">今天</option>
                          <option value="week">一周内</option>
                          <option value="month">一月内</option>
                          <option value="quarter">三月内</option>
                        </select>
                      </div>
                    </div>
                    
                    {/* 排序方式 */}
                    <div className="flex items-center space-x-3">
                      <span className="text-text-secondary text-sm">排序：</span>
                      <select 
                        className="px-4 py-2 border border-border-light rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                        value={selectedSortOrder}
                        onChange={(e) => setSelectedSortOrder(e.target.value)}
                      >
                        <option value="latest">最新发布</option>
                        <option value="popular">最热阅读</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* 资讯列表 */}
                <div className="space-y-4">
                  {sortedNews.map((newsItem) => (
                    <div 
                      key={newsItem.id}
                      className={`${styles.cardGradient} rounded-xl p-6 shadow-card hover:shadow-card-hover transition-all cursor-pointer`}
                      onClick={() => handleNewsItemClick(newsItem.id)}
                    >
                      <div className="flex items-start space-x-4">
                        <img 
                          src={newsItem.image} 
                          alt={newsItem.title} 
                          className="w-28 h-20 object-cover rounded-lg flex-shrink-0"
                        />
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <span className={`px-2 py-1 rounded-lg text-xs font-medium ${getNewsTypeStyle(newsItem.type)}`}>
                              {newsItem.type}
                            </span>
                            <span className="text-text-secondary text-xs">{newsItem.source}</span>
                          </div>
                          <h3 className="font-semibold text-text-primary mb-2 hover:text-primary transition-colors">
                            {newsItem.title}
                          </h3>
                          <p className="text-text-secondary text-sm mb-3">
                            {newsItem.content.length > 150 ? `${newsItem.content.substring(0, 150)}...` : newsItem.content}
                          </p>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-4 text-sm text-text-secondary">
                              <span><i className="fas fa-calendar mr-1"></i>{newsItem.date}</span>
                              <span><i className="fas fa-eye mr-1"></i>{newsItem.views}阅读</span>
                              <span><i className="fas fa-clock mr-1"></i>{newsItem.readTime}阅读</span>
                            </div>
                            <button className="text-primary hover:text-secondary transition-colors text-sm">
                              阅读全文 <i className="fas fa-arrow-right ml-1"></i>
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* 分页区域 */}
                <div className="flex items-center justify-between mt-8">
                  <div className="text-text-secondary text-sm">
                    显示 1-5 条，共 23 条资讯
                  </div>
                  <div className="flex items-center space-x-2">
                    <button className="px-3 py-2 border border-border-light rounded-lg hover:bg-bg-secondary transition-colors disabled:opacity-50" disabled>
                      <i className="fas fa-chevron-left"></i>
                    </button>
                    <button className="px-3 py-2 bg-primary text-white rounded-lg">1</button>
                    <button className="px-3 py-2 border border-border-light rounded-lg hover:bg-bg-secondary transition-colors">2</button>
                    <button className="px-3 py-2 border border-border-light rounded-lg hover:bg-bg-secondary transition-colors">3</button>
                    <span className="px-2 text-text-secondary">...</span>
                    <button className="px-3 py-2 border border-border-light rounded-lg hover:bg-bg-secondary transition-colors">5</button>
                    <button className="px-3 py-2 border border-border-light rounded-lg hover:bg-bg-secondary transition-colors">
                      <i className="fas fa-chevron-right"></i>
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* 资讯详情视图 */}
            {isNewsDetailView && currentNewsDetail && (
              <div className="mb-8">
                <div className={`${styles.cardGradient} rounded-xl p-8 shadow-card`}>
                  {/* 资讯头部 */}
                  <div className="mb-6">
                    <div className="flex items-center space-x-2 mb-3">
                      <span className={`px-3 py-1 rounded-lg text-sm font-medium ${getNewsTypeStyle(currentNewsDetail.type)}`}>
                        {currentNewsDetail.type}
                      </span>
                      <span className="text-text-secondary text-sm">{currentNewsDetail.source}</span>
                    </div>
                    <h1 className="text-3xl font-bold text-text-primary mb-4">{currentNewsDetail.title}</h1>
                    <div className="flex items-center space-x-6 text-sm text-text-secondary">
                      <span><i className="fas fa-calendar mr-2"></i>{currentNewsDetail.date}</span>
                      <span><i className="fas fa-eye mr-2"></i>{currentNewsDetail.views} 阅读</span>
                      <span><i className="fas fa-clock mr-2"></i>{currentNewsDetail.readTime} 阅读</span>
                      <span><i className="fas fa-share mr-2"></i>分享</span>
                    </div>
                  </div>

                  {/* 资讯图片 */}
                  <div className="mb-6">
                    <img 
                      src={currentNewsDetail.image} 
                      alt={currentNewsDetail.title} 
                      className="w-full h-96 object-cover rounded-xl"
                    />
                  </div>

                  {/* 资讯内容 */}
                  <div className={`${styles.newsDetailContent} text-text-primary`}>
                    <div dangerouslySetInnerHTML={{ __html: currentNewsDetail.content }} />
                  </div>

                  {/* 返回按钮 */}
                  <div className="mt-8">
                    <button 
                      className="px-6 py-2 border border-border-light rounded-lg hover:bg-bg-secondary transition-colors"
                      onClick={handleBackToList}
                    >
                      <i className="fas fa-arrow-left mr-2"></i>
                      返回列表
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
};

export default IndustryNewsPage;

