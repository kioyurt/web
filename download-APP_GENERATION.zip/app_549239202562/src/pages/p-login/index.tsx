

import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import styles from './styles.module.css';

const LoginPage: React.FC = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'email' | 'social'>('email');
  const [showPassword, setShowPassword] = useState(false);
  const [accountValue, setAccountValue] = useState('');
  const [passwordValue, setPasswordValue] = useState('');
  const [rememberMeChecked, setRememberMeChecked] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const originalTitle = document.title;
    document.title = '登录 - 模学苑';
    return () => { document.title = originalTitle; };
  }, []);

  useEffect(() => {
    // 页面加载时检查是否有记住的账号
    if (typeof window !== 'undefined') {
      const rememberedAccount = localStorage.getItem('rememberedAccount');
      if (rememberedAccount) {
        setAccountValue(rememberedAccount);
        setRememberMeChecked(true);
      }
    }
  }, []);

  const handleTabSwitch = (tab: 'email' | 'social') => {
    setActiveTab(tab);
  };

  const handleTogglePassword = () => {
    setShowPassword(!showPassword);
  };

  const handleRememberMeChange = (checked: boolean) => {
    setRememberMeChecked(checked);
    if (typeof window !== 'undefined') {
      if (checked) {
        localStorage.setItem('rememberedAccount', accountValue);
      } else {
        localStorage.removeItem('rememberedAccount');
      }
    }
  };

  const handleAccountChange = (value: string) => {
    setAccountValue(value);
    if (rememberMeChecked && typeof window !== 'undefined') {
      localStorage.setItem('rememberedAccount', value);
    }
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const accountTrimmed = accountValue.trim();
    const passwordTrimmed = passwordValue.trim();
    
    if (!accountTrimmed || !passwordTrimmed) {
      alert('请填写完整的登录信息');
      return;
    }
    
    setIsLoading(true);
    
    // 模拟登录过程
    setTimeout(() => {
      navigate('/home');
    }, 1000);
  };

  const handleSocialLogin = (provider: 'github' | 'wechat' | 'google') => {
    console.log(`需要调用第三方接口实现${provider}登录`);
    // 模拟第三方登录成功
    setTimeout(() => {
      navigate('/home');
    }, 1000);
  };

  const handleForgotPassword = () => {
    console.log('需要实现忘记密码功能');
    alert('忘记密码功能正在开发中，请联系客服');
  };

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <header className="bg-white/90 backdrop-blur-md border-b border-border-light">
        <div className="flex items-center justify-center px-6 py-3">
          {/* Logo区域 */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-primary rounded-xl flex items-center justify-center">
              <i className="fas fa-graduation-cap text-white text-lg"></i>
            </div>
            <h1 className={`text-xl font-bold ${styles.gradientText}`}>模学苑</h1>
          </div>
        </div>
      </header>

      {/* 主内容区域 */}
      <main className="flex items-center justify-center min-h-screen pt-16">
        <div className="w-full max-w-md mx-4">
          {/* 登录卡片 */}
          <div className={`${styles.cardGradient} rounded-2xl p-8 shadow-gradient`}>
            {/* 登录标题 */}
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-text-primary mb-2">欢迎登录模学苑</h2>
              <p className="text-text-secondary">开启你的多模态大模型学习之旅</p>
            </div>

            {/* 登录方式切换 */}
            <div className="flex mb-6 bg-bg-secondary rounded-xl p-1">
              <button 
                onClick={() => handleTabSwitch('email')}
                className={`flex-1 py-2 px-4 text-sm font-medium rounded-lg transition-all ${
                  activeTab === 'email' ? styles.tabActive : styles.tabInactive
                }`}
              >
                邮箱/手机登录
              </button>
              <button 
                onClick={() => handleTabSwitch('social')}
                className={`flex-1 py-2 px-4 text-sm font-medium rounded-lg transition-all ${
                  activeTab === 'social' ? styles.tabActive : styles.tabInactive
                }`}
              >
                第三方登录
              </button>
            </div>

            {/* 邮箱/手机登录表单 */}
            {activeTab === 'email' && (
              <div>
                <form onSubmit={handleLoginSubmit} className="space-y-4">
                  {/* 账号输入 */}
                  <div>
                    <label htmlFor="account" className="block text-sm font-medium text-text-primary mb-2">
                      邮箱/手机号
                    </label>
                    <input 
                      type="text" 
                      id="account" 
                      name="account"
                      value={accountValue}
                      onChange={(e) => handleAccountChange(e.target.value)}
                      className={`w-full px-4 py-3 border border-border-light rounded-xl ${styles.formInputFocus}`}
                      placeholder="请输入邮箱或手机号" 
                      required 
                    />
                  </div>

                  {/* 密码输入 */}
                  <div>
                    <label htmlFor="password" className="block text-sm font-medium text-text-primary mb-2">
                      密码
                    </label>
                    <div className="relative">
                      <input 
                        type={showPassword ? 'text' : 'password'}
                        id="password" 
                        name="password"
                        value={passwordValue}
                        onChange={(e) => setPasswordValue(e.target.value)}
                        className={`w-full px-4 py-3 pr-12 border border-border-light rounded-xl ${styles.formInputFocus}`}
                        placeholder="请输入密码" 
                        required 
                      />
                      <button 
                        type="button" 
                        onClick={handleTogglePassword}
                        className="absolute right-3 top-1/2 transform -translate-y-1/2 text-text-secondary hover:text-text-primary"
                      >
                        <i className={`fas ${showPassword ? 'fa-eye-slash' : 'fa-eye'}`}></i>
                      </button>
                    </div>
                  </div>

                  {/* 记住密码和忘记密码 */}
                  <div className="flex items-center justify-between">
                    <label className="flex items-center">
                      <input 
                        type="checkbox" 
                        checked={rememberMeChecked}
                        onChange={(e) => handleRememberMeChange(e.target.checked)}
                        className="w-4 h-4 text-primary border-border-light rounded focus:ring-primary/20"
                      />
                      <span className="ml-2 text-sm text-text-secondary">记住密码</span>
                    </label>
                    <button 
                      type="button" 
                      onClick={handleForgotPassword}
                      className="text-sm text-primary hover:text-secondary transition-colors"
                    >
                      忘记密码？
                    </button>
                  </div>

                  {/* 登录按钮 */}
                  <button 
                    type="submit"
                    disabled={isLoading}
                    className="w-full bg-gradient-primary text-white py-3 rounded-xl font-semibold hover:shadow-card-hover transition-all disabled:opacity-50"
                  >
                    {isLoading ? '登录中...' : '登录'}
                  </button>
                </form>
              </div>
            )}

            {/* 第三方登录表单 */}
            {activeTab === 'social' && (
              <div className="space-y-4">
                {/* GitHub登录 */}
                <button 
                  onClick={() => handleSocialLogin('github')}
                  className={`w-full flex items-center justify-center space-x-3 py-3 border border-border-light rounded-xl hover:bg-bg-secondary transition-all ${styles.socialButton}`}
                >
                  <i className="fab fa-github text-2xl text-text-primary"></i>
                  <span className="text-text-primary font-medium">GitHub登录</span>
                </button>

                {/* 微信登录 */}
                <button 
                  onClick={() => handleSocialLogin('wechat')}
                  className={`w-full flex items-center justify-center space-x-3 py-3 border border-border-light rounded-xl hover:bg-bg-secondary transition-all ${styles.socialButton}`}
                >
                  <i className="fab fa-weixin text-2xl text-success"></i>
                  <span className="text-text-primary font-medium">微信登录</span>
                </button>

                {/* Google登录 */}
                <button 
                  onClick={() => handleSocialLogin('google')}
                  className={`w-full flex items-center justify-center space-x-3 py-3 border border-border-light rounded-xl hover:bg-bg-secondary transition-all ${styles.socialButton}`}
                >
                  <i className="fab fa-google text-2xl text-danger"></i>
                  <span className="text-text-primary font-medium">Google登录</span>
                </button>
              </div>
            )}

            {/* 注册链接 */}
            <div className="text-center mt-6 pt-6 border-t border-border-light">
              <p className="text-text-secondary">
                还没有账号？
                <Link 
                  to="/register" 
                  className="text-primary hover:text-secondary font-medium transition-colors ml-1"
                >
                  立即注册
                </Link>
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default LoginPage;

