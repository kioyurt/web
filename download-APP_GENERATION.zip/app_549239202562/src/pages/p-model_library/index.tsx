

import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import styles from './styles.module.css';
import { ModelData, ModelDatabase } from './types';

const ModelLibraryPage: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [isModelDetailModalVisible, setIsModelDetailModalVisible] = useState(false);
  const [selectedModelData, setSelectedModelData] = useState<ModelData | null>(null);
  const [modelSearchKeyword, setModelSearchKeyword] = useState('');
  const [selectedModelType, setSelectedModelType] = useState('');
  const [selectedTimeFilter, setSelectedTimeFilter] = useState('');
  const [selectedSortOrder, setSelectedSortOrder] = useState('latest');
  const [globalSearchKeyword, setGlobalSearchKeyword] = useState('');

  // 模拟模型数据
  const modelDatabase: ModelDatabase = {
    model1: {
      name: 'GPT-4V',
      type: '多模态',
      typeClass: 'bg-gradient-primary',
      releaseDate: '2024-01-15',
      developer: 'OpenAI',
      description: 'GPT-4V 是 OpenAI 推出的最新多模态大模型，具备强大的图像理解和生成能力。该模型能够同时处理文本和图像输入，提供更加丰富和准确的响应。GPT-4V 在视觉问答、图像描述生成、图像理解等任务中表现出色，为 AI 应用开发提供了更多可能性。',
      features: [
        '支持图像输入和理解',
        '多模态对话能力',
        '高精度视觉问答',
        '支持多种图像格式'
      ],
      officialLink: 'https://openai.com/gpt-4v',
      paperLink: 'https://arxiv.org/abs/2401.00001',
      githubLink: null
    },
    model2: {
      name: 'CLIP',
      type: '多模态',
      typeClass: 'bg-gradient-secondary',
      releaseDate: '2024-01-10',
      developer: 'OpenAI',
      description: 'CLIP (Contrastive Language-Image Pre-training) 是 OpenAI 开发的对比语言-图像预训练模型。该模型通过大规模的图像-文本对训练，实现了跨模态的理解能力，能够在没有显式监督的情况下学习视觉概念。CLIP 在零样本分类、图像检索等任务中表现优异。',
      features: [
        '跨模态理解能力',
        '零样本学习能力',
        '图像-文本对比学习',
        '多语言支持'
      ],
      officialLink: 'https://openai.com/clip',
      paperLink: 'https://arxiv.org/abs/2103.00020',
      githubLink: 'https://github.com/openai/CLIP'
    },
    model3: {
      name: 'DALL-E 3',
      type: '图像',
      typeClass: 'bg-gradient-tertiary',
      releaseDate: '2024-01-08',
      developer: 'OpenAI',
      description: 'DALL-E 3 是 OpenAI 开发的先进文本到图像生成模型，能够根据文本描述生成高质量、高分辨率的图像。该模型在图像质量、文本理解准确性和创作多样性方面都有显著提升，支持生成复杂场景和艺术风格的图像。',
      features: [
        '高分辨率图像生成',
        '精确的文本理解',
        '多种艺术风格支持',
        '复杂场景生成'
      ],
      officialLink: 'https://openai.com/dall-e-3',
      paperLink: 'https://arxiv.org/abs/2310.06895',
      githubLink: null
    },
    model4: {
      name: 'BERT',
      type: '文本',
      typeClass: 'bg-gradient-success',
      releaseDate: '2024-01-05',
      developer: 'Google',
      description: 'BERT (Bidirectional Encoder Representations from Transformers) 是 Google 开发的预训练语言模型。该模型采用双向Transformer架构，能够深入理解上下文信息，在各种自然语言处理任务中取得了突破性成果，如文本分类、命名实体识别、问答系统等。',
      features: [
        '双向上下文理解',
        '预训练+微调模式',
        '多任务学习能力',
        '高效的特征提取'
      ],
      officialLink: 'https://github.com/google-research/bert',
      paperLink: 'https://arxiv.org/abs/1810.04805',
      githubLink: 'https://github.com/google-research/bert'
    },
    model5: {
      name: 'LLaVA',
      type: '多模态',
      typeClass: 'bg-gradient-primary',
      releaseDate: '2024-01-03',
      developer: '开源社区',
      description: 'LLaVA (Large Language and Vision Assistant) 是一个开源的大型语言和视觉助手模型。它通过将预训练语言模型与视觉编码器结合，实现了强大的多模态对话能力。LLaVA 支持图像描述、视觉问答、图像理解等多种任务，并且完全开源可商用。',
      features: [
        '开源可商用',
        '多模态对话',
        '图像理解能力',
        '轻量化部署'
      ],
      officialLink: 'https://llava-vl.github.io',
      paperLink: 'https://arxiv.org/abs/2304.08485',
      githubLink: 'https://github.com/haotian-liu/LLaVA'
    },
    model6: {
      name: 'Whisper',
      type: '音频',
      typeClass: 'bg-gradient-secondary',
      releaseDate: '2023-12-28',
      developer: 'OpenAI',
      description: 'Whisper 是 OpenAI 开发的通用语音识别模型，支持多语言语音转录和翻译。该模型在多种语音识别任务中表现出色，包括语音到文本转录、语音翻译、语言识别等。Whisper 支持99种语言，并且能够处理不同质量的音频输入。',
      features: [
        '多语言支持',
        '语音翻译能力',
        '噪声鲁棒性',
        '高精度转录'
      ],
      officialLink: 'https://openai.com/whisper',
      paperLink: 'https://arxiv.org/abs/2212.04356',
      githubLink: 'https://github.com/openai/whisper'
    },
    model7: {
      name: 'Stable Diffusion',
      type: '图像',
      typeClass: 'bg-gradient-tertiary',
      releaseDate: '2023-12-25',
      developer: 'Stability AI',
      description: 'Stable Diffusion 是 Stability AI 开发的开源文本到图像扩散模型。该模型能够根据文本提示生成高质量的图像，支持多种艺术风格和创作需求。Stable Diffusion 以其开源特性和高质量输出在创作者社区中广受欢迎。',
      features: [
        '开源免费使用',
        '高质量图像生成',
        '多种艺术风格',
        '本地部署支持'
      ],
      officialLink: 'https://stability.ai/stable-diffusion',
      paperLink: 'https://arxiv.org/abs/2112.10752',
      githubLink: 'https://github.com/Stability-AI/stablediffusion'
    },
    model8: {
      name: 'GPT-3.5',
      type: '文本',
      typeClass: 'bg-gradient-success',
      releaseDate: '2023-12-20',
      developer: 'OpenAI',
      description: 'GPT-3.5 是 OpenAI 开发的大规模语言模型，在对话和文本生成方面表现出色。该模型能够理解复杂的指令，生成连贯、有逻辑的文本，支持多种应用场景，如聊天机器人、内容创作、代码生成等。GPT-3.5 是目前应用最广泛的语言模型之一。',
      features: [
        '强大的对话能力',
        '多任务处理',
        '代码生成支持',
        '快速响应时间'
      ],
      officialLink: 'https://openai.com/gpt-3-5',
      paperLink: 'https://arxiv.org/abs/2203.02155',
      githubLink: null
    }
  };

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = '模型库 - 模学苑';
    return () => { document.title = originalTitle; };
  }, []);

  // 检查URL参数，如果有模型ID则显示详情
  useEffect(() => {
    const modelId = searchParams.get('modelId');
    if (modelId && modelDatabase[modelId]) {
      handleShowModelDetail(modelId);
    }
  }, [searchParams]);

  // 全局搜索处理
  const handleGlobalSearchKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      const keyword = globalSearchKeyword.trim();
      if (keyword) {
        navigate(`/search-results?q=${encodeURIComponent(keyword)}`);
      }
    }
  };

  // 模型搜索处理
  const handleModelSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setModelSearchKeyword(e.target.value);
  };

  // 筛选器处理
  const handleModelTypeFilterChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedModelType(e.target.value);
  };

  const handleTimeFilterChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedTimeFilter(e.target.value);
  };

  const handleSortOrderChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedSortOrder(e.target.value);
  };

  // 模型卡片点击处理
  const handleModelCardClick = (modelId: string) => {
    handleShowModelDetail(modelId);
  };

  // 显示模型详情
  const handleShowModelDetail = (modelId: string) => {
    const model = modelDatabase[modelId];
    if (!model) return;

    setSelectedModelData(model);
    setIsModelDetailModalVisible(true);
    document.body.style.overflow = 'hidden';

    // 更新URL参数
    const url = new URL(window.location.href);
    url.searchParams.set('modelId', modelId);
    window.history.replaceState({}, '', url.toString());
  };

  // 隐藏模型详情
  const handleHideModelDetail = () => {
    setIsModelDetailModalVisible(false);
    setSelectedModelData(null);
    document.body.style.overflow = 'auto';

    // 移除URL中的模型ID参数
    const url = new URL(window.location.href);
    url.searchParams.delete('modelId');
    window.history.replaceState({}, '', url.toString());
  };

  // 模态框背景点击处理
  const handleModalOverlayClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget) {
      handleHideModelDetail();
    }
  };

  // 分页处理
  const handlePrevPageClick = () => {
    console.log('上一页');
  };

  const handleNextPageClick = () => {
    console.log('下一页');
  };

  // 筛选模型
  const getFilteredModels = () => {
    return Object.entries(modelDatabase).filter(([_, model]) => {
      const matchesSearch = modelSearchKeyword === '' || 
        model.name.toLowerCase().includes(modelSearchKeyword.toLowerCase()) ||
        model.description.toLowerCase().includes(modelSearchKeyword.toLowerCase());
      
      const matchesType = selectedModelType === '' || 
        (selectedModelType === 'image' && model.type === '图像') ||
        (selectedModelType === 'text' && model.type === '文本') ||
        (selectedModelType === 'audio' && model.type === '音频') ||
        (selectedModelType === 'multimodal' && model.type === '多模态');
      
      return matchesSearch && matchesType;
    });
  };

  const filteredModels = getFilteredModels();

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <header className="fixed top-0 left-0 right-0 bg-white/90 backdrop-blur-md border-b border-border-light z-50">
        <div className="flex items-center justify-between px-6 py-3">
          {/* Logo区域 */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-primary rounded-xl flex items-center justify-center">
              <i className="fas fa-graduation-cap text-white text-lg"></i>
            </div>
            <h1 className={`text-xl font-bold ${styles.gradientText}`}>模学苑</h1>
          </div>
          
          {/* 主导航 */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/home" className="text-text-secondary hover:text-primary py-1 transition-colors">首页</Link>
            <Link to="/course-list" className="text-text-secondary hover:text-primary py-1 transition-colors">课程</Link>
            <Link to="/community-overview" className="text-text-secondary hover:text-primary py-1 transition-colors">社区</Link>
            <Link to="/resource-center" className="text-primary font-medium border-b-2 border-primary py-1">资源中心</Link>
          </nav>
          
          {/* 搜索和用户区域 */}
          <div className="flex items-center space-x-4">
            {/* 全局搜索 */}
            <div className="relative hidden lg:block">
              <input 
                type="text" 
                placeholder="搜索课程、资源..." 
                value={globalSearchKeyword}
                onChange={(e) => setGlobalSearchKeyword(e.target.value)}
                onKeyPress={handleGlobalSearchKeyPress}
                className="w-80 pl-10 pr-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary"></i>
            </div>
            
            {/* 消息通知 */}
            <button className="relative p-2 text-text-secondary hover:text-primary transition-colors">
              <i className="fas fa-bell text-lg"></i>
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-danger rounded-full"></span>
            </button>
            
            {/* 用户头像 */}
            <div className="flex items-center space-x-2 cursor-pointer">
              <img 
                src="https://s.coze.cn/image/f9vC3u_3RAY/" 
                alt="用户头像" 
                className="w-8 h-8 rounded-full border-2 border-primary/20"
              />
              <span className="hidden md:block text-text-primary font-medium">张同学</span>
              <i className="fas fa-chevron-down text-text-secondary text-sm"></i>
            </div>
          </div>
        </div>
      </header>

      <div className="flex pt-16">
        {/* 左侧菜单 */}
        <aside className={`fixed left-0 top-16 bottom-0 w-60 ${styles.sidebarGradient} text-white overflow-y-auto`}>
          <div className="p-4">
            <nav className="space-y-2">
              <Link to="/home" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-home text-lg"></i>
                <span>首页</span>
              </Link>
              <Link to="/course-list" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-book text-lg"></i>
                <span>课程中心</span>
              </Link>
              <Link to="/community-overview" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-users text-lg"></i>
                <span>社区互动</span>
              </Link>
              <Link to="/resource-center" className="flex items-center space-x-3 px-4 py-3 rounded-xl bg-white/20 backdrop-blur-sm">
                <i className="fas fa-database text-lg"></i>
                <span className="font-medium">资源中心</span>
              </Link>
              <Link to="/user-profile" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-user text-lg"></i>
                <span>个人中心</span>
              </Link>
            </nav>
            
            {/* 学习进度卡片 */}
            <div className="mt-8 p-4 bg-white/10 backdrop-blur-sm rounded-xl">
              <h3 className="font-semibold mb-3">今日学习</h3>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>进度</span>
                  <span>75%</span>
                </div>
                <div className="w-full bg-white/20 rounded-full h-2">
                  <div className="bg-white h-2 rounded-full" style={{width: '75%'}}></div>
                </div>
                <div className="flex justify-between text-sm">
                  <span>已学时长</span>
                  <span>2.5小时</span>
                </div>
              </div>
            </div>
          </div>
        </aside>

        {/* 主内容区域 */}
        <main className="flex-1 ml-60 min-h-screen">
          <div className="max-w-7xl mx-auto p-6">
            {/* 页面头部 */}
            <div className="mb-6">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-3xl font-bold text-white mb-2">模型库</h1>
                  <nav className="text-white/80">
                    <Link to="/home" className="hover:text-white transition-colors">首页</Link>
                    <span className="mx-2">/</span>
                    <Link to="/resource-center" className="hover:text-white transition-colors">资源中心</Link>
                    <span className="mx-2">/</span>
                    <span>模型库</span>
                  </nav>
                </div>
              </div>
            </div>

            {/* 工具栏区域 */}
            <div className={`${styles.cardGradient} rounded-xl p-6 shadow-card mb-6`}>
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
                {/* 搜索框 */}
                <div className="flex-1 lg:max-w-md">
                  <div className="relative">
                    <input 
                      type="text" 
                      placeholder="搜索模型名称、关键词..." 
                      value={modelSearchKeyword}
                      onChange={handleModelSearchChange}
                      className="w-full pl-10 pr-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                    />
                    <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary"></i>
                  </div>
                </div>
                
                {/* 筛选和排序 */}
                <div className="flex flex-wrap items-center space-x-4">
                  {/* 模型类型筛选 */}
                  <div className="relative">
                    <select 
                      value={selectedModelType}
                      onChange={handleModelTypeFilterChange}
                      className="appearance-none bg-white border border-border-light rounded-xl px-4 py-2 pr-10 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                    >
                      <option value="">全部类型</option>
                      <option value="image">图像模型</option>
                      <option value="text">文本模型</option>
                      <option value="audio">音频模型</option>
                      <option value="multimodal">多模态模型</option>
                    </select>
                    <i className="fas fa-chevron-down absolute right-3 top-1/2 transform -translate-y-1/2 text-text-secondary pointer-events-none"></i>
                  </div>
                  
                  {/* 发布时间筛选 */}
                  <div className="relative">
                    <select 
                      value={selectedTimeFilter}
                      onChange={handleTimeFilterChange}
                      className="appearance-none bg-white border border-border-light rounded-xl px-4 py-2 pr-10 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                    >
                      <option value="">全部时间</option>
                      <option value="week">最近一周</option>
                      <option value="month">最近一月</option>
                      <option value="quarter">最近三月</option>
                    </select>
                    <i className="fas fa-chevron-down absolute right-3 top-1/2 transform -translate-y-1/2 text-text-secondary pointer-events-none"></i>
                  </div>
                  
                  {/* 排序方式 */}
                  <div className="relative">
                    <select 
                      value={selectedSortOrder}
                      onChange={handleSortOrderChange}
                      className="appearance-none bg-white border border-border-light rounded-xl px-4 py-2 pr-10 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                    >
                      <option value="latest">最新发布</option>
                      <option value="popular">最受欢迎</option>
                    </select>
                    <i className="fas fa-chevron-down absolute right-3 top-1/2 transform -translate-y-1/2 text-text-secondary pointer-events-none"></i>
                  </div>
                </div>
              </div>
            </div>

            {/* 模型列表区域 */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-8">
              {filteredModels.map(([modelId, model]) => (
                <div 
                  key={modelId}
                  className={`${styles.cardGradient} rounded-xl p-6 shadow-card hover:shadow-card-hover transition-all cursor-pointer`}
                  onClick={() => handleModelCardClick(modelId)}
                >
                  <div className="flex items-center justify-between mb-4">
                    <span className={`${model.typeClass} text-white px-3 py-1 rounded-lg text-sm font-medium`}>
                      {model.type}
                    </span>
                    <span className="text-text-secondary text-sm">{model.releaseDate}</span>
                  </div>
                  <h3 className="font-semibold text-text-primary mb-2">{model.name}</h3>
                  <p className="text-text-secondary text-sm mb-4">{model.description}</p>
                  <div className="space-y-2">
                    <a 
                      href={model.officialLink} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="flex items-center text-primary text-sm hover:text-secondary transition-colors"
                    >
                      <i className="fas fa-external-link-alt mr-1"></i>
                      {model.officialLink.includes('github') ? 'GitHub' : '官方网站'}
                    </a>
                    <a 
                      href={model.paperLink} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="flex items-center text-primary text-sm hover:text-secondary transition-colors"
                    >
                      <i className="fas fa-file-alt mr-1"></i>
                      论文链接
                    </a>
                  </div>
                </div>
              ))}
            </div>

            {/* 分页区域 */}
            <div className={`flex items-center justify-between ${styles.cardGradient} rounded-xl p-4 shadow-card`}>
              <div className="text-text-secondary text-sm">
                显示 1-{filteredModels.length} 条，共 45 条记录
              </div>
              <div className="flex items-center space-x-2">
                <button 
                  onClick={handlePrevPageClick}
                  className="px-3 py-2 text-sm border border-border-light rounded-lg hover:bg-bg-secondary transition-colors disabled:opacity-50" 
                  disabled
                >
                  <i className="fas fa-chevron-left mr-1"></i>
                  上一页
                </button>
                <button className="px-3 py-2 text-sm bg-primary text-white rounded-lg">1</button>
                <button className="px-3 py-2 text-sm border border-border-light rounded-lg hover:bg-bg-secondary transition-colors">2</button>
                <button className="px-3 py-2 text-sm border border-border-light rounded-lg hover:bg-bg-secondary transition-colors">3</button>
                <span className="px-2 text-text-secondary">...</span>
                <button className="px-3 py-2 text-sm border border-border-light rounded-lg hover:bg-bg-secondary transition-colors">6</button>
                <button 
                  onClick={handleNextPageClick}
                  className="px-3 py-2 text-sm border border-border-light rounded-lg hover:bg-bg-secondary transition-colors"
                >
                  下一页
                  <i className="fas fa-chevron-right ml-1"></i>
                </button>
              </div>
            </div>
          </div>
        </main>
      </div>

      {/* 模型详情模态框 */}
      {isModelDetailModalVisible && selectedModelData && (
        <div 
          className={`fixed inset-0 ${styles.modelDetailOverlay} z-50`}
          onClick={handleModalOverlayClick}
        >
          <div className="flex items-center justify-center min-h-screen p-4">
            <div className={`bg-white rounded-2xl shadow-gradient w-full max-w-4xl ${styles.modelDetailContent}`}>
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-bold text-text-primary">{selectedModelData.name} 详情</h2>
                  <button 
                    onClick={handleHideModelDetail}
                    className="p-2 text-text-secondary hover:text-text-primary transition-colors"
                  >
                    <i className="fas fa-times text-xl"></i>
                  </button>
                </div>
                
                <div className="space-y-6">
                  {/* 模型基本信息 */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h3 className="font-semibold text-text-primary mb-3">基本信息</h3>
                      <div className="space-y-3">
                        <div className="flex justify-between">
                          <span className="text-text-secondary">模型名称：</span>
                          <span className="font-medium">{selectedModelData.name}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-text-secondary">模型类型：</span>
                          <span className={`${selectedModelData.typeClass} text-white px-2 py-1 rounded text-sm`}>
                            {selectedModelData.type}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-text-secondary">发布日期：</span>
                          <span className="font-medium">{selectedModelData.releaseDate}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-text-secondary">开发者：</span>
                          <span className="font-medium">{selectedModelData.developer}</span>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="font-semibold text-text-primary mb-3">相关链接</h3>
                      <div className="space-y-3">
                        <a 
                          href={selectedModelData.officialLink} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="flex items-center text-primary hover:text-secondary transition-colors"
                        >
                          <i className="fas fa-external-link-alt mr-2"></i>
                          {selectedModelData.officialLink.includes('github') ? 'GitHub 仓库' : '官方网站'}
                        </a>
                        <a 
                          href={selectedModelData.paperLink} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="flex items-center text-primary hover:text-secondary transition-colors"
                        >
                          <i className="fas fa-file-alt mr-2"></i>
                          论文链接
                        </a>
                        {selectedModelData.githubLink && (
                          <a 
                            href={selectedModelData.githubLink} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="flex items-center text-primary hover:text-secondary transition-colors"
                          >
                            <i className="fas fa-github mr-2"></i>
                            GitHub 仓库
                          </a>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  {/* 模型描述 */}
                  <div>
                    <h3 className="font-semibold text-text-primary mb-3">模型描述</h3>
                    <div className="prose max-w-none text-text-secondary">
                      <p>{selectedModelData.description}</p>
                    </div>
                  </div>
                  
                  {/* 技术特点 */}
                  <div>
                    <h3 className="font-semibold text-text-primary mb-3">技术特点</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {selectedModelData.features.map((feature, index) => (
                        <div key={index} className="flex items-start space-x-3">
                          <i className="fas fa-check-circle text-success mt-1"></i>
                          <span className="text-text-secondary">{feature}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ModelLibraryPage;

