

export interface ModelData {
  name: string;
  type: string;
  typeClass: string;
  releaseDate: string;
  developer: string;
  description: string;
  features: string[];
  officialLink: string;
  paperLink: string;
  githubLink: string | null;
}

export interface ModelDatabase {
  [key: string]: ModelData;
}

