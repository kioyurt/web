

import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import styles from './styles.module.css';

interface Question {
  id: number;
  title: string;
  author: string;
  time: string;
  answers: number;
  status: 'resolved' | 'unresolved';
  views: number;
  course: string;
}

interface QuestionFormData {
  title: string;
  content: string;
  course: string;
  tags: string;
  images: FileList | null;
}

const QuestionAnswerPage: React.FC = () => {
  const navigate = useNavigate();
  
  // 模拟问答数据
  const mockQuestions: Question[] = [
    {
      id: 1,
      title: 'GPT-4V模型如何处理多模态输入？',
      author: 'AI学习者',
      time: '2024-01-15 14:30',
      answers: 5,
      status: 'resolved',
      views: 156,
      course: 'GPT-4V多模态入门'
    },
    {
      id: 2,
      title: 'CLIP模型训练时出现过拟合怎么办？',
      author: '数据科学家',
      time: '2024-01-15 12:15',
      answers: 3,
      status: 'unresolved',
      views: 89,
      course: 'CLIP模型训练'
    },
    {
      id: 3,
      title: 'DALL-E生成的图像质量如何提升？',
      author: '设计师小王',
      time: '2024-01-15 10:45',
      answers: 8,
      status: 'resolved',
      views: 234,
      course: 'DALL-E图像生成'
    },
    {
      id: 4,
      title: '多模态模型部署时的性能优化策略',
      author: '后端工程师',
      time: '2024-01-14 16:20',
      answers: 12,
      status: 'resolved',
      views: 456,
      course: '模型部署优化'
    },
    {
      id: 5,
      title: '如何选择适合的多模态模型？',
      author: '机器学习新手',
      time: '2024-01-14 14:10',
      answers: 6,
      status: 'unresolved',
      views: 178,
      course: ''
    },
    {
      id: 6,
      title: 'GPT-4V的视觉理解能力有哪些限制？',
      author: 'AI研究员',
      time: '2024-01-14 11:30',
      answers: 4,
      status: 'unresolved',
      views: 92,
      course: 'GPT-4V多模态入门'
    },
    {
      id: 7,
      title: 'CLIP模型的零样本分类效果如何？',
      author: '算法工程师',
      time: '2024-01-13 15:45',
      answers: 7,
      status: 'resolved',
      views: 267,
      course: 'CLIP模型训练'
    },
    {
      id: 8,
      title: 'DALL-E 3相比DALL-E 2有哪些改进？',
      author: '创意工作者',
      time: '2024-01-13 13:20',
      answers: 9,
      status: 'resolved',
      views: 345,
      course: 'DALL-E图像生成'
    },
    {
      id: 9,
      title: '多模态模型的推理时间优化方法',
      author: '系统架构师',
      time: '2024-01-13 09:15',
      answers: 11,
      status: 'unresolved',
      views: 512,
      course: '模型部署优化'
    },
    {
      id: 10,
      title: '如何评估多模态模型的性能？',
      author: '数据分析师',
      time: '2024-01-12 16:30',
      answers: 5,
      status: 'resolved',
      views: 189,
      course: ''
    }
  ];

  // 状态管理
  const [currentPage, setCurrentPage] = useState(1);
  const [filteredQuestions, setFilteredQuestions] = useState<Question[]>(mockQuestions);
  const [showAskModal, setShowAskModal] = useState(false);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [selectedQuestion, setSelectedQuestion] = useState<Question | null>(null);
  const [questionFormData, setQuestionFormData] = useState<QuestionFormData>({
    title: '',
    content: '',
    course: '',
    tags: '',
    images: null
  });

  // 搜索和筛选状态
  const [questionSearchTerm, setQuestionSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [courseFilter, setCourseFilter] = useState('');
  const [sortBy, setSortBy] = useState('latest');

  const pageSize = 10;

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = '问答区 - 模学苑';
    return () => { document.title = originalTitle; };
  }, []);

  // 筛选问题
  useEffect(() => {
    let filtered = mockQuestions.filter(question => {
      // 搜索过滤
      const matchesSearch = !questionSearchTerm || 
        question.title.toLowerCase().includes(questionSearchTerm.toLowerCase()) ||
        question.author.toLowerCase().includes(questionSearchTerm.toLowerCase());
      
      // 状态过滤
      const matchesStatus = !statusFilter || question.status === statusFilter;
      
      // 课程过滤
      const matchesCourse = !courseFilter || 
        !question.course || 
        question.course.toLowerCase().includes(courseFilter);
      
      return matchesSearch && matchesStatus && matchesCourse;
    });

    // 排序
    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'latest':
          return new Date(b.time).getTime() - new Date(a.time).getTime();
        case 'hot':
          return b.views - a.views;
        case 'most-answers':
          return b.answers - a.answers;
        default:
          return new Date(b.time).getTime() - new Date(a.time).getTime();
      }
    });

    setFilteredQuestions(filtered);
    setCurrentPage(1);
  }, [questionSearchTerm, statusFilter, courseFilter, sortBy]);

  // 全局搜索处理
  const handleGlobalSearch = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      const keyword = (e.target as HTMLInputElement).value.trim();
      if (keyword) {
        navigate(`/search-results?q=${encodeURIComponent(keyword)}`);
      }
    }
  };

  // 表单输入处理
  const handleFormInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setQuestionFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // 文件上传处理
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    setQuestionFormData(prev => ({
      ...prev,
      images: e.target.files || null
    }));
  };

  // 拖拽上传处理
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setQuestionFormData(prev => ({
      ...prev,
      images: e.dataTransfer.files || null
    }));
  };

  // 表单提交
  const handleQuestionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('提交问题:', questionFormData);
    setShowAskModal(false);
    // 重置表单
    setQuestionFormData({
      title: '',
      content: '',
      course: '',
      tags: '',
      images: null
    });
    // 显示成功提示
    alert('问题发布成功！');
  };

  // 问题详情
  const handleQuestionDetail = (question: Question) => {
    setSelectedQuestion(question);
    setShowDetailModal(true);
  };

  // 分页处理
  const totalPages = Math.ceil(filteredQuestions.length / pageSize);
  const startIndex = (currentPage - 1) * pageSize;
  const endIndex = startIndex + pageSize;
  const currentQuestions = filteredQuestions.slice(startIndex, endIndex);

  // 生成页码
  const generatePageNumbers = () => {
    const pages = [];
    for (let i = 1; i <= totalPages; i++) {
      if (i === 1 || i === totalPages || (i >= currentPage - 1 && i <= currentPage + 1)) {
        pages.push(
          <button
            key={i}
            onClick={() => setCurrentPage(i)}
            className={`px-3 py-1 border rounded-lg transition-colors ${
              i === currentPage 
                ? 'bg-primary text-white border-primary' 
                : 'border-border-light text-white/80 hover:text-white hover:border-primary'
            }`}
          >
            {i}
          </button>
        );
      } else if (i === currentPage - 2 || i === currentPage + 2) {
        pages.push(
          <span key={`ellipsis-${i}`} className="px-3 py-1 text-white/50">
            ...
          </span>
        );
      }
    }
    return pages;
  };

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <header className="fixed top-0 left-0 right-0 bg-white/90 backdrop-blur-md border-b border-border-light z-50">
        <div className="flex items-center justify-between px-6 py-3">
          {/* Logo区域 */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-primary rounded-xl flex items-center justify-center">
              <i className="fas fa-graduation-cap text-white text-lg"></i>
            </div>
            <h1 className={`text-xl font-bold ${styles.gradientText}`}>模学苑</h1>
          </div>
          
          {/* 主导航 */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/home" className="text-text-secondary hover:text-primary py-1 transition-colors">首页</Link>
            <Link to="/course-list" className="text-text-secondary hover:text-primary py-1 transition-colors">课程</Link>
            <Link to="/community-overview" className="text-primary font-medium border-b-2 border-primary py-1">社区</Link>
            <Link to="/resource-center" className="text-text-secondary hover:text-primary py-1 transition-colors">资源中心</Link>
          </nav>
          
          {/* 搜索和用户区域 */}
          <div className="flex items-center space-x-4">
            {/* 全局搜索 */}
            <div className="relative hidden lg:block">
              <input 
                type="text" 
                placeholder="搜索课程、资源..." 
                onKeyPress={handleGlobalSearch}
                className="w-80 pl-10 pr-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary"></i>
            </div>
            
            {/* 消息通知 */}
            <button className="relative p-2 text-text-secondary hover:text-primary transition-colors">
              <i className="fas fa-bell text-lg"></i>
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-danger rounded-full"></span>
            </button>
            
            {/* 用户头像 */}
            <div className="flex items-center space-x-2 cursor-pointer">
              <img 
                src="https://s.coze.cn/image/GI41EoBwSvk/" 
                alt="用户头像" 
                className="w-8 h-8 rounded-full border-2 border-primary/20"
              />
              <span className="hidden md:block text-text-primary font-medium">张同学</span>
              <i className="fas fa-chevron-down text-text-secondary text-sm"></i>
            </div>
          </div>
        </div>
      </header>

      <div className="flex pt-16">
        {/* 左侧菜单 */}
        <aside className={`fixed left-0 top-16 bottom-0 w-60 ${styles.sidebarGradient} text-white overflow-y-auto`}>
          <div className="p-4">
            <nav className="space-y-2">
              <Link to="/home" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-home text-lg"></i>
                <span>首页</span>
              </Link>
              <Link to="/course-list" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-book text-lg"></i>
                <span>课程中心</span>
              </Link>
              <Link to="/community-overview" className="flex items-center space-x-3 px-4 py-3 rounded-xl bg-white/20 backdrop-blur-sm">
                <i className="fas fa-users text-lg"></i>
                <span className="font-medium">社区互动</span>
              </Link>
              <Link to="/resource-center" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-database text-lg"></i>
                <span>资源中心</span>
              </Link>
              <Link to="/user-profile" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-user text-lg"></i>
                <span>个人中心</span>
              </Link>
            </nav>
            
            {/* 学习进度卡片 */}
            <div className="mt-8 p-4 bg-white/10 backdrop-blur-sm rounded-xl">
              <h3 className="font-semibold mb-3">今日学习</h3>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>进度</span>
                  <span>75%</span>
                </div>
                <div className="w-full bg-white/20 rounded-full h-2">
                  <div className="bg-white h-2 rounded-full" style={{width: '75%'}}></div>
                </div>
                <div className="flex justify-between text-sm">
                  <span>已学时长</span>
                  <span>2.5小时</span>
                </div>
              </div>
            </div>
          </div>
        </aside>

        {/* 主内容区域 */}
        <main className="flex-1 ml-60 min-h-screen">
          <div className="max-w-7xl mx-auto p-6">
            {/* 页面头部 */}
            <div className="mb-6">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-3xl font-bold text-white mb-2">问答区</h1>
                  <nav className="text-white/80">
                    <Link to="/home" className="hover:text-white transition-colors">首页</Link>
                    <span className="mx-2">/</span>
                    <Link to="/community-overview" className="hover:text-white transition-colors">社区</Link>
                    <span className="mx-2">/</span>
                    <span>问答区</span>
                  </nav>
                </div>
              </div>
            </div>

            {/* 工具栏区域 */}
            <div className={`${styles.cardGradient} rounded-xl p-6 shadow-card mb-6`}>
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
                {/* 搜索和筛选 */}
                <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 flex-1">
                  {/* 搜索框 */}
                  <div className="relative flex-1 min-w-64">
                    <input 
                      type="text" 
                      placeholder="搜索问题、提问者..." 
                      value={questionSearchTerm}
                      onChange={(e) => setQuestionSearchTerm(e.target.value)}
                      className="w-full pl-10 pr-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                    />
                    <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary"></i>
                  </div>
                  
                  {/* 状态筛选 */}
                  <select 
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                    className="px-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                  >
                    <option value="">全部状态</option>
                    <option value="resolved">已解决</option>
                    <option value="unresolved">未解决</option>
                  </select>
                  
                  {/* 课程筛选 */}
                  <select 
                    value={courseFilter}
                    onChange={(e) => setCourseFilter(e.target.value)}
                    className="px-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                  >
                    <option value="">全部课程</option>
                    <option value="gpt4v">GPT-4V多模态入门</option>
                    <option value="clip">CLIP模型训练</option>
                    <option value="dalle">DALL-E图像生成</option>
                    <option value="deployment">模型部署优化</option>
                  </select>
                  
                  {/* 排序 */}
                  <select 
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value)}
                    className="px-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                  >
                    <option value="latest">最新发布</option>
                    <option value="hot">最热门</option>
                    <option value="most-answers">回答最多</option>
                  </select>
                </div>
                
                {/* 我要提问按钮 */}
                <button 
                  onClick={() => setShowAskModal(true)}
                  className="bg-gradient-primary text-white px-6 py-2 rounded-xl font-semibold hover:shadow-gradient transition-all"
                >
                  <i className="fas fa-plus mr-2"></i>
                  我要提问
                </button>
              </div>
            </div>

            {/* 问答列表 */}
            <div className={`${styles.cardGradient} rounded-xl shadow-card mb-6 overflow-hidden`}>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-bg-secondary">
                    <tr>
                      <th className="px-6 py-4 text-left text-sm font-semibold text-text-primary">问题标题</th>
                      <th className="px-6 py-4 text-left text-sm font-semibold text-text-primary">提问者</th>
                      <th className="px-6 py-4 text-left text-sm font-semibold text-text-primary">发布时间</th>
                      <th className="px-6 py-4 text-left text-sm font-semibold text-text-primary">回答数</th>
                      <th className="px-6 py-4 text-left text-sm font-semibold text-text-primary">状态</th>
                      <th className="px-6 py-4 text-left text-sm font-semibold text-text-primary">浏览量</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border-light">
                    {currentQuestions.map((question) => (
                      <tr 
                        key={question.id}
                        className={`${styles.tableRow} transition-colors cursor-pointer`}
                        onClick={() => handleQuestionDetail(question)}
                      >
                        <td className="px-6 py-4">
                          <div className="text-sm font-medium text-text-primary hover:text-primary transition-colors">
                            {question.title}
                          </div>
                          {question.course && (
                            <div className="text-xs text-text-secondary mt-1">{question.course}</div>
                          )}
                        </td>
                        <td className="px-6 py-4 text-sm text-text-secondary">{question.author}</td>
                        <td className="px-6 py-4 text-sm text-text-secondary">{question.time}</td>
                        <td className="px-6 py-4 text-sm text-text-secondary">{question.answers}</td>
                        <td className="px-6 py-4">
                          <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                            question.status === 'resolved' ? styles.statusResolved : styles.statusUnresolved
                          }`}>
                            {question.status === 'resolved' ? '已解决' : '未解决'}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-sm text-text-secondary">{question.views}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* 分页区域 */}
            <div className="flex items-center justify-between">
              <div className="text-white/80 text-sm">
                显示 <span>{filteredQuestions.length === 0 ? 0 : startIndex + 1}-{Math.min(endIndex, filteredQuestions.length)}</span> 条，共 <span>{filteredQuestions.length}</span> 条记录
              </div>
              <div className="flex items-center space-x-2">
                <button 
                  onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                  disabled={currentPage <= 1}
                  className="px-3 py-1 border border-border-light rounded-lg text-white/80 hover:text-white hover:border-primary transition-colors disabled:opacity-50"
                >
                  <i className="fas fa-chevron-left"></i>
                </button>
                <div className="flex space-x-1">
                  {generatePageNumbers()}
                </div>
                <button 
                  onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                  disabled={currentPage >= totalPages}
                  className="px-3 py-1 border border-border-light rounded-lg text-white/80 hover:text-white hover:border-primary transition-colors disabled:opacity-50"
                >
                  <i className="fas fa-chevron-right"></i>
                </button>
              </div>
            </div>
          </div>
        </main>
      </div>

      {/* 提问模态弹窗 */}
      {showAskModal && (
        <div className="fixed inset-0 z-50">
          <div className={styles.modalOverlay} onClick={() => setShowAskModal(false)}></div>
          <div className="relative flex items-center justify-center min-h-screen p-4">
            <div className="bg-white rounded-2xl shadow-gradient w-full max-w-2xl max-h-[90vh] overflow-y-auto">
              <div className="p-6 border-b border-border-light">
                <h2 className="text-xl font-bold text-text-primary">我要提问</h2>
                <button 
                  onClick={() => setShowAskModal(false)}
                  className="absolute top-6 right-6 text-text-secondary hover:text-text-primary transition-colors"
                >
                  <i className="fas fa-times text-xl"></i>
                </button>
              </div>
              <form onSubmit={handleQuestionSubmit} className="p-6 space-y-4">
                <div>
                  <label htmlFor="title" className="block text-sm font-medium text-text-primary mb-2">问题标题 *</label>
                  <input 
                    type="text" 
                    id="title" 
                    name="title"
                    value={questionFormData.title}
                    onChange={handleFormInputChange}
                    className="w-full px-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary" 
                    placeholder="请简要描述您的问题..." 
                    required 
                  />
                </div>
                <div>
                  <label htmlFor="content" className="block text-sm font-medium text-text-primary mb-2">问题描述 *</label>
                  <textarea 
                    id="content" 
                    name="content" 
                    rows={6}
                    value={questionFormData.content}
                    onChange={handleFormInputChange}
                    className="w-full px-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary" 
                    placeholder="请详细描述您遇到的问题，包括错误信息、环境配置等..." 
                    required
                  ></textarea>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="course" className="block text-sm font-medium text-text-primary mb-2">相关课程</label>
                    <select 
                      id="course" 
                      name="course"
                      value={questionFormData.course}
                      onChange={handleFormInputChange}
                      className="w-full px-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                    >
                      <option value="">请选择相关课程（可选）</option>
                      <option value="gpt4v">GPT-4V多模态入门</option>
                      <option value="clip">CLIP模型训练</option>
                      <option value="dalle">DALL-E图像生成</option>
                      <option value="deployment">模型部署优化</option>
                    </select>
                  </div>
                  <div>
                    <label htmlFor="tags" className="block text-sm font-medium text-text-primary mb-2">标签</label>
                    <input 
                      type="text" 
                      id="tags" 
                      name="tags"
                      value={questionFormData.tags}
                      onChange={handleFormInputChange}
                      className="w-full px-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary" 
                      placeholder="用逗号分隔多个标签，如：GPT-4V, 多模态"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-text-primary mb-2">上传图片（可选）</label>
                  <div 
                    className="border-2 border-dashed border-border-light rounded-xl p-6 text-center cursor-pointer"
                    onDragOver={handleDragOver}
                    onDrop={handleDrop}
                    onClick={() => document.getElementById('images')?.click()}
                  >
                    <i className="fas fa-cloud-upload-alt text-3xl text-text-secondary mb-2"></i>
                    <p className="text-text-secondary">点击或拖拽图片到此处上传</p>
                    <p className="text-xs text-text-secondary mt-1">支持 JPG、PNG 格式，最大 5MB</p>
                    <input 
                      type="file" 
                      id="images" 
                      name="images" 
                      multiple 
                      accept="image/*" 
                      onChange={handleFileUpload}
                      className="hidden" 
                    />
                  </div>
                </div>
                <div className="flex justify-end space-x-4 pt-4 border-t border-border-light">
                  <button 
                    type="button" 
                    onClick={() => setShowAskModal(false)}
                    className="px-6 py-2 border border-border-light rounded-xl text-text-secondary hover:text-text-primary hover:border-primary transition-colors"
                  >
                    取消
                  </button>
                  <button 
                    type="submit" 
                    className="px-6 py-2 bg-gradient-primary text-white rounded-xl font-semibold hover:shadow-gradient transition-all"
                  >
                    发布问题
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* 问题详情模态弹窗 */}
      {showDetailModal && selectedQuestion && (
        <div className="fixed inset-0 z-50">
          <div className={styles.modalOverlay} onClick={() => setShowDetailModal(false)}></div>
          <div className="relative flex items-center justify-center min-h-screen p-4">
            <div className="bg-white rounded-2xl shadow-gradient w-full max-w-4xl max-h-[90vh] overflow-y-auto">
              <div className="p-6 border-b border-border-light">
                <h2 className="text-xl font-bold text-text-primary">问题详情</h2>
                <button 
                  onClick={() => setShowDetailModal(false)}
                  className="absolute top-6 right-6 text-text-secondary hover:text-text-primary transition-colors"
                >
                  <i className="fas fa-times text-xl"></i>
                </button>
              </div>
              <div className="p-6 space-y-6">
                <div className="border-b border-border-light pb-4">
                  <h3 className="text-lg font-semibold text-text-primary mb-2">{selectedQuestion.title}</h3>
                  <div className="flex items-center space-x-4 text-sm text-text-secondary">
                    <span><i className="fas fa-user mr-1"></i>{selectedQuestion.author}</span>
                    <span><i className="fas fa-clock mr-1"></i>{selectedQuestion.time}</span>
                    <span><i className="fas fa-eye mr-1"></i>{selectedQuestion.views} 浏览</span>
                    <span><i className="fas fa-comment mr-1"></i>{selectedQuestion.answers} 回答</span>
                    {selectedQuestion.course && (
                      <span><i className="fas fa-book mr-1"></i>{selectedQuestion.course}</span>
                    )}
                  </div>
                </div>
                
                <div className="border-b border-border-light pb-4">
                  <h4 className="font-medium text-text-primary mb-2">问题描述</h4>
                  <div className="prose max-w-none text-text-secondary">
                    <p>这是问题的详细描述内容。用户在使用{selectedQuestion.course || '多模态模型'}时遇到了一些困难，希望得到社区的帮助和解答。</p>
                    <p>具体问题包括：</p>
                    <ul className="list-disc list-inside space-y-1">
                      <li>如何正确配置模型参数</li>
                      <li>训练过程中出现的错误</li>
                      <li>性能优化的建议</li>
                    </ul>
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-4">
                    <h4 className="font-medium text-text-primary">回答 ({selectedQuestion.answers})</h4>
                    <button className="text-primary hover:text-primary/80 text-sm font-medium">
                      <i className="fas fa-plus mr-1"></i>
                      回答问题
                    </button>
                  </div>
                  
                  <div className="space-y-4">
                    <div className="border border-border-light rounded-lg p-4">
                      <div className="flex items-start space-x-3">
                        <img src="https://s.coze.cn/image/X_mhPBqU0yw/" alt="回答者头像" className="w-8 h-8 rounded-full" />
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <span className="font-medium text-text-primary">AI专家</span>
                            <span className="text-xs text-text-secondary">2小时前</span>
                            {selectedQuestion.status === 'resolved' && (
                              <span className="px-2 py-1 text-xs bg-success text-white rounded-full">最佳回答</span>
                            )}
                          </div>
                          <p className="text-text-secondary text-sm">
                            根据您的描述，我建议您检查以下几个方面：首先，确认模型输入的格式是否正确；其次，调整学习率和批处理大小；最后，可以尝试使用数据增强技术来缓解过拟合问题。
                          </p>
                          <div className="flex items-center space-x-4 mt-3 text-xs text-text-secondary">
                            <button className="hover:text-primary transition-colors">
                              <i className="fas fa-thumbs-up mr-1"></i>赞同 (12)
                            </button>
                            <button className="hover:text-primary transition-colors">
                              <i className="fas fa-reply mr-1"></i>回复
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="border border-border-light rounded-lg p-4">
                      <div className="flex items-start space-x-3">
                        <img src="https://s.coze.cn/image/IWkTqstgKD8/" alt="回答者头像" className="w-8 h-8 rounded-full" />
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <span className="font-medium text-text-primary">机器学习工程师</span>
                            <span className="text-xs text-text-secondary">4小时前</span>
                          </div>
                          <p className="text-text-secondary text-sm">
                            我之前也遇到过类似的问题，解决方法是...
                          </p>
                          <div className="flex items-center space-x-4 mt-3 text-xs text-text-secondary">
                            <button className="hover:text-primary transition-colors">
                              <i className="fas fa-thumbs-up mr-1"></i>赞同 (8)
                            </button>
                            <button className="hover:text-primary transition-colors">
                              <i className="fas fa-reply mr-1"></i>回复
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default QuestionAnswerPage;

