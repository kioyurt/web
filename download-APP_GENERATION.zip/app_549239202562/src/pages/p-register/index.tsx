

import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import styles from './styles.module.css';

interface FormData {
  email: string;
  password: string;
  confirmPassword: string;
  emailCode: string;
  agreement: boolean;
}

interface PhoneFormData {
  phone: string;
  password: string;
  confirmPassword: string;
  phoneCode: string;
  agreement: boolean;
}

interface FormErrors {
  email?: string;
  password?: string;
  confirmPassword?: string;
  emailCode?: string;
}

interface PhoneFormErrors {
  phone?: string;
  password?: string;
  confirmPassword?: string;
  phoneCode?: string;
}

const RegisterPage: React.FC = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'email' | 'phone'>('email');
  const [isEmailPasswordVisible, setIsEmailPasswordVisible] = useState(false);
  const [isEmailConfirmPasswordVisible, setIsEmailConfirmPasswordVisible] = useState(false);
  const [isPhonePasswordVisible, setIsPhonePasswordVisible] = useState(false);
  const [isPhoneConfirmPasswordVisible, setIsPhoneConfirmPasswordVisible] = useState(false);
  const [emailCodeCountdown, setEmailCodeCountdown] = useState(0);
  const [phoneCodeCountdown, setPhoneCodeCountdown] = useState(0);
  const [isEmailSubmitting, setIsEmailSubmitting] = useState(false);
  const [isPhoneSubmitting, setIsPhoneSubmitting] = useState(false);

  const [emailFormData, setEmailFormData] = useState<FormData>({
    email: '',
    password: '',
    confirmPassword: '',
    emailCode: '',
    agreement: false
  });

  const [phoneFormData, setPhoneFormData] = useState<PhoneFormData>({
    phone: '',
    password: '',
    confirmPassword: '',
    phoneCode: '',
    agreement: false
  });

  const [emailFormErrors, setEmailFormErrors] = useState<FormErrors>({});
  const [phoneFormErrors, setPhoneFormErrors] = useState<PhoneFormErrors>({});

  useEffect(() => {
    const originalTitle = document.title;
    document.title = '注册 - 模学苑';
    return () => { document.title = originalTitle; };
  }, []);

  useEffect(() => {
    let timer: number | null = null;
    if (emailCodeCountdown > 0) {
      timer = window.setTimeout(() => {
        setEmailCodeCountdown(emailCodeCountdown - 1);
      }, 1000);
    }
    return () => {
      if (timer) clearTimeout(timer);
    };
  }, [emailCodeCountdown]);

  useEffect(() => {
    let timer: number | null = null;
    if (phoneCodeCountdown > 0) {
      timer = window.setTimeout(() => {
        setPhoneCodeCountdown(phoneCodeCountdown - 1);
      }, 1000);
    }
    return () => {
      if (timer) clearTimeout(timer);
    };
  }, [phoneCodeCountdown]);

  const validateEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const validatePhone = (phone: string): boolean => {
    const phoneRegex = /^1[3-9]\d{9}$/;
    return phoneRegex.test(phone);
  };

  const validatePassword = (password: string): boolean => {
    return password.length >= 8;
  };

  const handleEmailInputChange = (field: keyof FormData, value: string | boolean) => {
    setEmailFormData(prev => ({ ...prev, [field]: value }));
    if (typeof value === 'string' && emailFormErrors[field as keyof FormErrors]) {
      setEmailFormErrors(prev => ({ ...prev, [field]: undefined }));
    }
  };

  const handlePhoneInputChange = (field: keyof PhoneFormData, value: string | boolean) => {
    setPhoneFormData(prev => ({ ...prev, [field]: value }));
    if (typeof value === 'string' && phoneFormErrors[field as keyof PhoneFormErrors]) {
      setPhoneFormErrors(prev => ({ ...prev, [field]: undefined }));
    }
  };

  const handleGetEmailCode = () => {
    if (emailCodeCountdown > 0) return;
    
    if (!validateEmail(emailFormData.email)) {
      setEmailFormErrors(prev => ({ ...prev, email: '请先输入有效的邮箱地址' }));
      return;
    }

    console.log('发送邮箱验证码');
    setEmailCodeCountdown(60);
  };

  const handleGetPhoneCode = () => {
    if (phoneCodeCountdown > 0) return;
    
    if (!validatePhone(phoneFormData.phone)) {
      setPhoneFormErrors(prev => ({ ...prev, phone: '请先输入有效的手机号码' }));
      return;
    }

    console.log('发送手机验证码');
    setPhoneCodeCountdown(60);
  };

  const handleEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const errors: FormErrors = {};
    
    if (!emailFormData.email) {
      errors.email = '请输入邮箱地址';
    } else if (!validateEmail(emailFormData.email)) {
      errors.email = '请输入有效的邮箱地址';
    }
    
    if (!emailFormData.password) {
      errors.password = '请输入密码';
    } else if (!validatePassword(emailFormData.password)) {
      errors.password = '密码至少需要8位字符';
    }
    
    if (!emailFormData.confirmPassword) {
      errors.confirmPassword = '请确认密码';
    } else if (emailFormData.password !== emailFormData.confirmPassword) {
      errors.confirmPassword = '两次输入的密码不一致';
    }
    
    if (!emailFormData.emailCode) {
      errors.emailCode = '请输入验证码';
    }
    
    setEmailFormErrors(errors);
    
    if (Object.keys(errors).length > 0) return;
    
    if (!emailFormData.agreement) {
      alert('请先同意用户协议和隐私政策');
      return;
    }
    
    setIsEmailSubmitting(true);
    
    setTimeout(() => {
      alert('注册成功！即将跳转到首页');
      navigate('/home');
    }, 2000);
  };

  const handlePhoneSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const errors: PhoneFormErrors = {};
    
    if (!phoneFormData.phone) {
      errors.phone = '请输入手机号码';
    } else if (!validatePhone(phoneFormData.phone)) {
      errors.phone = '请输入有效的手机号码';
    }
    
    if (!phoneFormData.password) {
      errors.password = '请输入密码';
    } else if (!validatePassword(phoneFormData.password)) {
      errors.password = '密码至少需要8位字符';
    }
    
    if (!phoneFormData.confirmPassword) {
      errors.confirmPassword = '请确认密码';
    } else if (phoneFormData.password !== phoneFormData.confirmPassword) {
      errors.confirmPassword = '两次输入的密码不一致';
    }
    
    if (!phoneFormData.phoneCode) {
      errors.phoneCode = '请输入验证码';
    }
    
    setPhoneFormErrors(errors);
    
    if (Object.keys(errors).length > 0) return;
    
    if (!phoneFormData.agreement) {
      alert('请先同意用户协议和隐私政策');
      return;
    }
    
    setIsPhoneSubmitting(true);
    
    setTimeout(() => {
      alert('注册成功！即将跳转到首页');
      navigate('/home');
    }, 2000);
  };

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <header className="fixed top-0 left-0 right-0 bg-white/90 backdrop-blur-md border-b border-border-light z-50">
        <div className="flex items-center justify-center px-6 py-3">
          {/* Logo区域 */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-primary rounded-xl flex items-center justify-center">
              <i className="fas fa-graduation-cap text-white text-lg"></i>
            </div>
            <h1 className={`text-xl font-bold ${styles.gradientText}`}>模学苑</h1>
          </div>
        </div>
      </header>

      {/* 主内容区域 */}
      <main className="pt-16 min-h-screen flex items-center justify-center p-6">
        <div className="w-full max-w-md">
          {/* 注册卡片 */}
          <div className="bg-white/95 backdrop-blur-md rounded-2xl shadow-gradient p-8">
            {/* 注册标题 */}
            <div className="text-center mb-8">
              <h2 className={`text-2xl font-bold ${styles.gradientText} mb-2`}>注册模学苑账号</h2>
              <p className="text-text-secondary">加入我们，一起探索多模态大模型的奇妙世界</p>
            </div>

            {/* 注册方式切换 */}
            <div className="flex mb-6 rounded-xl bg-white/20 p-1">
              <button 
                onClick={() => setActiveTab('email')}
                className={`flex-1 py-3 px-4 rounded-lg text-center font-medium transition-all ${
                  activeTab === 'email' ? styles.tabActive : styles.tabInactive
                }`}
              >
                <i className="fas fa-envelope mr-2"></i>邮箱注册
              </button>
              <button 
                onClick={() => setActiveTab('phone')}
                className={`flex-1 py-3 px-4 rounded-lg text-center font-medium transition-all ${
                  activeTab === 'phone' ? styles.tabActive : styles.tabInactive
                }`}
              >
                <i className="fas fa-mobile-alt mr-2"></i>手机注册
              </button>
            </div>

            {/* 邮箱注册表单 */}
            {activeTab === 'email' && (
              <form onSubmit={handleEmailSubmit} className="space-y-4">
                <div className="space-y-2">
                  <label htmlFor="email" className="block text-sm font-medium text-text-primary">邮箱地址 *</label>
                  <input 
                    type="email" 
                    id="email" 
                    value={emailFormData.email}
                    onChange={(e) => handleEmailInputChange('email', e.target.value)}
                    className={`w-full px-4 py-3 border rounded-xl ${styles.formInputFocus} ${
                      emailFormErrors.email ? 'border-danger' : 'border-border-light'
                    }`}
                    placeholder="请输入您的邮箱地址" 
                    required 
                  />
                  {emailFormErrors.email && (
                    <div className={styles.errorMessage}>{emailFormErrors.email}</div>
                  )}
                </div>

                <div className="space-y-2">
                  <label htmlFor="password" className="block text-sm font-medium text-text-primary">密码 *</label>
                  <div className="relative">
                    <input 
                      type={isEmailPasswordVisible ? 'text' : 'password'} 
                      id="password" 
                      value={emailFormData.password}
                      onChange={(e) => handleEmailInputChange('password', e.target.value)}
                      className={`w-full px-4 py-3 pr-12 border rounded-xl ${styles.formInputFocus} ${
                        emailFormErrors.password ? 'border-danger' : 'border-border-light'
                      }`}
                      placeholder="请输入密码（至少8位）" 
                      required 
                    />
                    <button 
                      type="button" 
                      onClick={() => setIsEmailPasswordVisible(!isEmailPasswordVisible)}
                      className="absolute right-4 top-1/2 transform -translate-y-1/2 text-text-secondary hover:text-primary"
                    >
                      <i className={`fas ${isEmailPasswordVisible ? 'fa-eye-slash' : 'fa-eye'}`}></i>
                    </button>
                  </div>
                  {emailFormErrors.password && (
                    <div className={styles.errorMessage}>{emailFormErrors.password}</div>
                  )}
                </div>

                <div className="space-y-2">
                  <label htmlFor="confirm-password" className="block text-sm font-medium text-text-primary">确认密码 *</label>
                  <div className="relative">
                    <input 
                      type={isEmailConfirmPasswordVisible ? 'text' : 'password'} 
                      id="confirm-password" 
                      value={emailFormData.confirmPassword}
                      onChange={(e) => handleEmailInputChange('confirmPassword', e.target.value)}
                      className={`w-full px-4 py-3 pr-12 border rounded-xl ${styles.formInputFocus} ${
                        emailFormErrors.confirmPassword ? 'border-danger' : 'border-border-light'
                      }`}
                      placeholder="请再次输入密码" 
                      required 
                    />
                    <button 
                      type="button" 
                      onClick={() => setIsEmailConfirmPasswordVisible(!isEmailConfirmPasswordVisible)}
                      className="absolute right-4 top-1/2 transform -translate-y-1/2 text-text-secondary hover:text-primary"
                    >
                      <i className={`fas ${isEmailConfirmPasswordVisible ? 'fa-eye-slash' : 'fa-eye'}`}></i>
                    </button>
                  </div>
                  {emailFormErrors.confirmPassword && (
                    <div className={styles.errorMessage}>{emailFormErrors.confirmPassword}</div>
                  )}
                </div>

                <div className="space-y-2">
                  <label htmlFor="email-code" className="block text-sm font-medium text-text-primary">验证码 *</label>
                  <div className="flex space-x-3">
                    <input 
                      type="text" 
                      id="email-code" 
                      value={emailFormData.emailCode}
                      onChange={(e) => handleEmailInputChange('emailCode', e.target.value)}
                      className={`flex-1 px-4 py-3 border rounded-xl ${styles.formInputFocus} ${
                        emailFormErrors.emailCode ? 'border-danger' : 'border-border-light'
                      }`}
                      placeholder="请输入验证码" 
                      required 
                    />
                    <button 
                      type="button" 
                      onClick={handleGetEmailCode}
                      disabled={emailCodeCountdown > 0}
                      className={`px-6 py-3 rounded-xl font-medium transition-opacity ${
                        emailCodeCountdown > 0 
                          ? styles.btnDisabled 
                          : 'bg-gradient-primary text-white hover:opacity-90'
                      }`}
                    >
                      {emailCodeCountdown > 0 ? `${emailCodeCountdown}秒后重发` : '获取验证码'}
                    </button>
                  </div>
                  {emailFormErrors.emailCode && (
                    <div className={styles.errorMessage}>{emailFormErrors.emailCode}</div>
                  )}
                </div>

                <div className="flex items-start space-x-3">
                  <input 
                    type="checkbox" 
                    id="email-agreement" 
                    checked={emailFormData.agreement}
                    onChange={(e) => handleEmailInputChange('agreement', e.target.checked)}
                    className="mt-1 w-4 h-4 text-primary border-border-light rounded focus:ring-primary/20" 
                    required 
                  />
                  <label htmlFor="email-agreement" className="text-sm text-text-secondary">
                    我已阅读并同意
                    <a href="#" className="text-primary hover:underline">《用户协议》</a>
                    和
                    <a href="#" className="text-primary hover:underline">《隐私政策》</a>
                  </label>
                </div>

                <button 
                  type="submit" 
                  disabled={isEmailSubmitting}
                  className="w-full py-3 bg-gradient-primary text-white rounded-xl font-semibold hover:opacity-90 transition-opacity"
                >
                  {isEmailSubmitting ? (
                    <>
                      <i className="fas fa-spinner fa-spin mr-2"></i>注册中...
                    </>
                  ) : (
                    <>
                      <i className="fas fa-user-plus mr-2"></i>注册账号
                    </>
                  )}
                </button>
              </form>
            )}

            {/* 手机注册表单 */}
            {activeTab === 'phone' && (
              <form onSubmit={handlePhoneSubmit} className="space-y-4">
                <div className="space-y-2">
                  <label htmlFor="phone" className="block text-sm font-medium text-text-primary">手机号码 *</label>
                  <input 
                    type="tel" 
                    id="phone" 
                    value={phoneFormData.phone}
                    onChange={(e) => handlePhoneInputChange('phone', e.target.value)}
                    className={`w-full px-4 py-3 border rounded-xl ${styles.formInputFocus} ${
                      phoneFormErrors.phone ? 'border-danger' : 'border-border-light'
                    }`}
                    placeholder="请输入您的手机号码" 
                    required 
                  />
                  {phoneFormErrors.phone && (
                    <div className={styles.errorMessage}>{phoneFormErrors.phone}</div>
                  )}
                </div>

                <div className="space-y-2">
                  <label htmlFor="phone-password" className="block text-sm font-medium text-text-primary">密码 *</label>
                  <div className="relative">
                    <input 
                      type={isPhonePasswordVisible ? 'text' : 'password'} 
                      id="phone-password" 
                      value={phoneFormData.password}
                      onChange={(e) => handlePhoneInputChange('password', e.target.value)}
                      className={`w-full px-4 py-3 pr-12 border rounded-xl ${styles.formInputFocus} ${
                        phoneFormErrors.password ? 'border-danger' : 'border-border-light'
                      }`}
                      placeholder="请输入密码（至少8位）" 
                      required 
                    />
                    <button 
                      type="button" 
                      onClick={() => setIsPhonePasswordVisible(!isPhonePasswordVisible)}
                      className="absolute right-4 top-1/2 transform -translate-y-1/2 text-text-secondary hover:text-primary"
                    >
                      <i className={`fas ${isPhonePasswordVisible ? 'fa-eye-slash' : 'fa-eye'}`}></i>
                    </button>
                  </div>
                  {phoneFormErrors.password && (
                    <div className={styles.errorMessage}>{phoneFormErrors.password}</div>
                  )}
                </div>

                <div className="space-y-2">
                  <label htmlFor="phone-confirm-password" className="block text-sm font-medium text-text-primary">确认密码 *</label>
                  <div className="relative">
                    <input 
                      type={isPhoneConfirmPasswordVisible ? 'text' : 'password'} 
                      id="phone-confirm-password" 
                      value={phoneFormData.confirmPassword}
                      onChange={(e) => handlePhoneInputChange('confirmPassword', e.target.value)}
                      className={`w-full px-4 py-3 pr-12 border rounded-xl ${styles.formInputFocus} ${
                        phoneFormErrors.confirmPassword ? 'border-danger' : 'border-border-light'
                      }`}
                      placeholder="请再次输入密码" 
                      required 
                    />
                    <button 
                      type="button" 
                      onClick={() => setIsPhoneConfirmPasswordVisible(!isPhoneConfirmPasswordVisible)}
                      className="absolute right-4 top-1/2 transform -translate-y-1/2 text-text-secondary hover:text-primary"
                    >
                      <i className={`fas ${isPhoneConfirmPasswordVisible ? 'fa-eye-slash' : 'fa-eye'}`}></i>
                    </button>
                  </div>
                  {phoneFormErrors.confirmPassword && (
                    <div className={styles.errorMessage}>{phoneFormErrors.confirmPassword}</div>
                  )}
                </div>

                <div className="space-y-2">
                  <label htmlFor="phone-code" className="block text-sm font-medium text-text-primary">验证码 *</label>
                  <div className="flex space-x-3">
                    <input 
                      type="text" 
                      id="phone-code" 
                      value={phoneFormData.phoneCode}
                      onChange={(e) => handlePhoneInputChange('phoneCode', e.target.value)}
                      className={`flex-1 px-4 py-3 border rounded-xl ${styles.formInputFocus} ${
                        phoneFormErrors.phoneCode ? 'border-danger' : 'border-border-light'
                      }`}
                      placeholder="请输入验证码" 
                      required 
                    />
                    <button 
                      type="button" 
                      onClick={handleGetPhoneCode}
                      disabled={phoneCodeCountdown > 0}
                      className={`px-6 py-3 rounded-xl font-medium transition-opacity ${
                        phoneCodeCountdown > 0 
                          ? styles.btnDisabled 
                          : 'bg-gradient-primary text-white hover:opacity-90'
                      }`}
                    >
                      {phoneCodeCountdown > 0 ? `${phoneCodeCountdown}秒后重发` : '获取验证码'}
                    </button>
                  </div>
                  {phoneFormErrors.phoneCode && (
                    <div className={styles.errorMessage}>{phoneFormErrors.phoneCode}</div>
                  )}
                </div>

                <div className="flex items-start space-x-3">
                  <input 
                    type="checkbox" 
                    id="phone-agreement" 
                    checked={phoneFormData.agreement}
                    onChange={(e) => handlePhoneInputChange('agreement', e.target.checked)}
                    className="mt-1 w-4 h-4 text-primary border-border-light rounded focus:ring-primary/20" 
                    required 
                  />
                  <label htmlFor="phone-agreement" className="text-sm text-text-secondary">
                    我已阅读并同意
                    <a href="#" className="text-primary hover:underline">《用户协议》</a>
                    和
                    <a href="#" className="text-primary hover:underline">《隐私政策》</a>
                  </label>
                </div>

                <button 
                  type="submit" 
                  disabled={isPhoneSubmitting}
                  className="w-full py-3 bg-gradient-primary text-white rounded-xl font-semibold hover:opacity-90 transition-opacity"
                >
                  {isPhoneSubmitting ? (
                    <>
                      <i className="fas fa-spinner fa-spin mr-2"></i>注册中...
                    </>
                  ) : (
                    <>
                      <i className="fas fa-user-plus mr-2"></i>注册账号
                    </>
                  )}
                </button>
              </form>
            )}

            {/* 登录链接 */}
            <div className="mt-6 text-center">
              <p className="text-text-secondary">
                已有账号？
                <Link to="/login" className="text-primary hover:underline font-medium">立即登录</Link>
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default RegisterPage;

