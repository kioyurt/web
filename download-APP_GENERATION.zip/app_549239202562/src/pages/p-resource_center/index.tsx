

import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import styles from './styles.module.css';

const ResourceCenterPage: React.FC = () => {
  const navigate = useNavigate();
  const [globalSearchValue, setGlobalSearchValue] = useState('');

  useEffect(() => {
    const originalTitle = document.title;
    document.title = '资源中心 - 模学苑';
    return () => { document.title = originalTitle; };
  }, []);

  const handleGlobalSearchKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      const keyword = globalSearchValue.trim();
      if (keyword) {
        navigate(`/search-results?q=${encodeURIComponent(keyword)}`);
      }
    }
  };

  const handleModelLibraryCardClick = () => {
    navigate('/model-library');
  };

  const handleToolCollectionCardClick = () => {
    navigate('/tool-collection');
  };

  const handleIndustryNewsCardClick = () => {
    navigate('/industry-news');
  };

  const handleResourceDownloadCardClick = () => {
    navigate('/resource-download');
  };

  const handleLatestModel1Click = () => {
    navigate('/model-library?id=gpt4v-advanced');
  };

  const handleLatestModel2Click = () => {
    navigate('/model-library?id=claude3-opus');
  };

  const handleLatestModel3Click = () => {
    navigate('/model-library?id=gemini-ultra-vision');
  };

  const handleLatestTool1Click = () => {
    navigate('/tool-collection?id=huggingface-spaces');
  };

  const handleLatestTool2Click = () => {
    navigate('/tool-collection?id=label-studio');
  };

  const handleLatestTool3Click = () => {
    navigate('/tool-collection?id=wandb');
  };

  const handleLatestNews1Click = () => {
    navigate('/industry-news?id=medical-ai-breakthrough');
  };

  const handleLatestNews2Click = () => {
    navigate('/industry-news?id=gpt5-whitepaper');
  };

  const handleLatestNews3Click = () => {
    navigate('/industry-news?id=google-icml-paper');
  };

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <header className="fixed top-0 left-0 right-0 bg-white/90 backdrop-blur-md border-b border-border-light z-50">
        <div className="flex items-center justify-between px-6 py-3">
          {/* Logo区域 */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-primary rounded-xl flex items-center justify-center">
              <i className="fas fa-graduation-cap text-white text-lg"></i>
            </div>
            <h1 className={`text-xl font-bold ${styles.gradientText}`}>模学苑</h1>
          </div>
          
          {/* 主导航 */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/home" className="text-text-secondary hover:text-primary py-1 transition-colors">首页</Link>
            <Link to="/course-list" className="text-text-secondary hover:text-primary py-1 transition-colors">课程</Link>
            <Link to="/community-overview" className="text-text-secondary hover:text-primary py-1 transition-colors">社区</Link>
            <Link to="/resource-center" className="text-primary font-medium border-b-2 border-primary py-1">资源中心</Link>
          </nav>
          
          {/* 搜索和用户区域 */}
          <div className="flex items-center space-x-4">
            {/* 全局搜索 */}
            <div className="relative hidden lg:block">
              <input 
                type="text" 
                placeholder="搜索课程、资源..." 
                value={globalSearchValue}
                onChange={(e) => setGlobalSearchValue(e.target.value)}
                onKeyPress={handleGlobalSearchKeyPress}
                className="w-80 pl-10 pr-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary"></i>
            </div>
            
            {/* 消息通知 */}
            <button className="relative p-2 text-text-secondary hover:text-primary transition-colors">
              <i className="fas fa-bell text-lg"></i>
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-danger rounded-full"></span>
            </button>
            
            {/* 用户头像 */}
            <div className="flex items-center space-x-2 cursor-pointer">
              <img 
                src="https://s.coze.cn/image/NRJ7inPioNw/" 
                alt="用户头像" 
                className="w-8 h-8 rounded-full border-2 border-primary/20"
              />
              <span className="hidden md:block text-text-primary font-medium">张同学</span>
              <i className="fas fa-chevron-down text-text-secondary text-sm"></i>
            </div>
          </div>
        </div>
      </header>

      <div className="flex pt-16">
        {/* 左侧菜单 */}
        <aside className={`fixed left-0 top-16 bottom-0 w-60 ${styles.sidebarGradient} text-white overflow-y-auto`}>
          <div className="p-4">
            <nav className="space-y-2">
              <Link to="/home" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-home text-lg"></i>
                <span>首页</span>
              </Link>
              <Link to="/course-list" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-book text-lg"></i>
                <span>课程中心</span>
              </Link>
              <Link to="/community-overview" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-users text-lg"></i>
                <span>社区互动</span>
              </Link>
              <Link to="/resource-center" className="flex items-center space-x-3 px-4 py-3 rounded-xl bg-white/20 backdrop-blur-sm">
                <i className="fas fa-database text-lg"></i>
                <span className="font-medium">资源中心</span>
              </Link>
              <Link to="/user-profile" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-user text-lg"></i>
                <span>个人中心</span>
              </Link>
            </nav>
            
            {/* 学习进度卡片 */}
            <div className="mt-8 p-4 bg-white/10 backdrop-blur-sm rounded-xl">
              <h3 className="font-semibold mb-3">今日学习</h3>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>进度</span>
                  <span>75%</span>
                </div>
                <div className="w-full bg-white/20 rounded-full h-2">
                  <div className="bg-white h-2 rounded-full" style={{width: '75%'}}></div>
                </div>
                <div className="flex justify-between text-sm">
                  <span>已学时长</span>
                  <span>2.5小时</span>
                </div>
              </div>
            </div>
          </div>
        </aside>

        {/* 主内容区域 */}
        <main className="flex-1 ml-60 min-h-screen">
          <div className="max-w-7xl mx-auto p-6">
            {/* 页面头部 */}
            <div className="mb-6">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-3xl font-bold text-white mb-2">资源中心</h1>
                  <nav className="text-white/80">
                    <span>首页</span>
                    <i className="fas fa-chevron-right mx-2"></i>
                    <span>资源中心</span>
                  </nav>
                </div>
              </div>
            </div>

            {/* 资源功能入口区 */}
            <section className="mb-8">
              <h2 className="text-2xl font-bold text-white mb-6">资源模块</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {/* 模型库入口卡片 */}
                <div 
                  onClick={handleModelLibraryCardClick}
                  className={`${styles.cardGradient} rounded-2xl p-6 shadow-card hover:shadow-card-hover transition-all cursor-pointer group`}
                >
                  <div className="text-center">
                    <div className="w-16 h-16 bg-gradient-primary rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                      <i className="fas fa-brain text-white text-2xl"></i>
                    </div>
                    <h3 className="font-semibold text-text-primary mb-2">模型库</h3>
                    <p className="text-text-secondary text-sm mb-4">探索最新的多模态大模型，了解其原理、架构和应用场景</p>
                    <div className="flex items-center justify-center text-primary text-sm font-medium">
                      <span>浏览模型</span>
                      <i className="fas fa-arrow-right ml-2 group-hover:translate-x-1 transition-transform"></i>
                    </div>
                  </div>
                </div>

                {/* 工具集入口卡片 */}
                <div 
                  onClick={handleToolCollectionCardClick}
                  className={`${styles.cardGradient} rounded-2xl p-6 shadow-card hover:shadow-card-hover transition-all cursor-pointer group`}
                >
                  <div className="text-center">
                    <div className="w-16 h-16 bg-gradient-secondary rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                      <i className="fas fa-tools text-white text-2xl"></i>
                    </div>
                    <h3 className="font-semibold text-text-primary mb-2">工具集</h3>
                    <p className="text-text-secondary text-sm mb-4">获取开发工具、API文档和SDK，提升开发效率</p>
                    <div className="flex items-center justify-center text-secondary text-sm font-medium">
                      <span>查看工具</span>
                      <i className="fas fa-arrow-right ml-2 group-hover:translate-x-1 transition-transform"></i>
                    </div>
                  </div>
                </div>

                {/* 行业资讯入口卡片 */}
                <div 
                  onClick={handleIndustryNewsCardClick}
                  className={`${styles.cardGradient} rounded-2xl p-6 shadow-card hover:shadow-card-hover transition-all cursor-pointer group`}
                >
                  <div className="text-center">
                    <div className="w-16 h-16 bg-gradient-tertiary rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                      <i className="fas fa-newspaper text-white text-2xl"></i>
                    </div>
                    <h3 className="font-semibold text-text-primary mb-2">行业资讯</h3>
                    <p className="text-text-secondary text-sm mb-4">了解最新的研究成果、技术动态和应用案例</p>
                    <div className="flex items-center justify-center text-tertiary text-sm font-medium">
                      <span>阅读资讯</span>
                      <i className="fas fa-arrow-right ml-2 group-hover:translate-x-1 transition-transform"></i>
                    </div>
                  </div>
                </div>

                {/* 资源下载入口卡片 */}
                <div 
                  onClick={handleResourceDownloadCardClick}
                  className={`${styles.cardGradient} rounded-2xl p-6 shadow-card hover:shadow-card-hover transition-all cursor-pointer group`}
                >
                  <div className="text-center">
                    <div className="w-16 h-16 bg-gradient-success rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                      <i className="fas fa-download text-white text-2xl"></i>
                    </div>
                    <h3 className="font-semibold text-text-primary mb-2">资源下载</h3>
                    <p className="text-text-secondary text-sm mb-4">下载课程课件、代码示例和数据集等学习资料</p>
                    <div className="flex items-center justify-center text-success text-sm font-medium">
                      <span>开始下载</span>
                      <i className="fas fa-arrow-right ml-2 group-hover:translate-x-1 transition-transform"></i>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* 最新资源速览区 */}
            <section className="mb-8">
              <h2 className="text-2xl font-bold text-white mb-6">最新资源</h2>
              
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* 最新模型 */}
                <div className={`${styles.cardGradient} rounded-xl p-6 shadow-card`}>
                  <h3 className="font-semibold text-text-primary mb-4 flex items-center">
                    <i className="fas fa-brain text-primary mr-2"></i>
                    最新模型
                  </h3>
                  <div className="space-y-4">
                    <div 
                      onClick={handleLatestModel1Click}
                      className="border-b border-border-light pb-3 last:border-b-0 last:pb-0 cursor-pointer hover:bg-bg-secondary rounded-lg p-2 transition-colors"
                    >
                      <h4 className="text-sm font-medium text-text-primary mb-1">GPT-4V Advanced</h4>
                      <p className="text-xs text-text-secondary mb-2">增强版多模态理解能力，支持更复杂的视觉推理</p>
                      <span className="text-xs text-primary">2024-01-15</span>
                    </div>
                    <div 
                      onClick={handleLatestModel2Click}
                      className="border-b border-border-light pb-3 last:border-b-0 last:pb-0 cursor-pointer hover:bg-bg-secondary rounded-lg p-2 transition-colors"
                    >
                      <h4 className="text-sm font-medium text-text-primary mb-1">Claude 3 Opus</h4>
                      <p className="text-xs text-text-secondary mb-2">Anthropic最新旗舰模型，在多项基准测试中表现优异</p>
                      <span className="text-xs text-primary">2024-01-12</span>
                    </div>
                    <div 
                      onClick={handleLatestModel3Click}
                      className="border-b border-border-light pb-3 last:border-b-0 last:pb-0 cursor-pointer hover:bg-bg-secondary rounded-lg p-2 transition-colors"
                    >
                      <h4 className="text-sm font-medium text-text-primary mb-1">Gemini Ultra Vision</h4>
                      <p className="text-xs text-text-secondary mb-2">Google Gemini系列的视觉增强版本</p>
                      <span className="text-xs text-primary">2024-01-10</span>
                    </div>
                  </div>
                  <div className="mt-4 text-center">
                    <Link to="/model-library" className="text-primary text-sm font-medium hover:underline">查看更多模型</Link>
                  </div>
                </div>

                {/* 最新工具 */}
                <div className={`${styles.cardGradient} rounded-xl p-6 shadow-card`}>
                  <h3 className="font-semibold text-text-primary mb-4 flex items-center">
                    <i className="fas fa-tools text-secondary mr-2"></i>
                    最新工具
                  </h3>
                  <div className="space-y-4">
                    <div 
                      onClick={handleLatestTool1Click}
                      className="border-b border-border-light pb-3 last:border-b-0 last:pb-0 cursor-pointer hover:bg-bg-secondary rounded-lg p-2 transition-colors"
                    >
                      <h4 className="text-sm font-medium text-text-primary mb-1">Hugging Face Spaces</h4>
                      <p className="text-xs text-text-secondary mb-2">在线部署和分享机器学习模型的平台</p>
                      <span className="text-xs text-secondary">2024-01-14</span>
                    </div>
                    <div 
                      onClick={handleLatestTool2Click}
                      className="border-b border-border-light pb-3 last:border-b-0 last:pb-0 cursor-pointer hover:bg-bg-secondary rounded-lg p-2 transition-colors"
                    >
                      <h4 className="text-sm font-medium text-text-primary mb-1">Label Studio</h4>
                      <p className="text-xs text-text-secondary mb-2">开源的多模态数据标注工具</p>
                      <span className="text-xs text-secondary">2024-01-11</span>
                    </div>
                    <div 
                      onClick={handleLatestTool3Click}
                      className="border-b border-border-light pb-3 last:border-b-0 last:pb-0 cursor-pointer hover:bg-bg-secondary rounded-lg p-2 transition-colors"
                    >
                      <h4 className="text-sm font-medium text-text-primary mb-1">Weights & Biases</h4>
                      <p className="text-xs text-text-secondary mb-2">机器学习实验跟踪和可视化平台</p>
                      <span className="text-xs text-secondary">2024-01-09</span>
                    </div>
                  </div>
                  <div className="mt-4 text-center">
                    <Link to="/tool-collection" className="text-secondary text-sm font-medium hover:underline">查看更多工具</Link>
                  </div>
                </div>

                {/* 最新资讯 */}
                <div className={`${styles.cardGradient} rounded-xl p-6 shadow-card`}>
                  <h3 className="font-semibold text-text-primary mb-4 flex items-center">
                    <i className="fas fa-newspaper text-tertiary mr-2"></i>
                    最新资讯
                  </h3>
                  <div className="space-y-4">
                    <div 
                      onClick={handleLatestNews1Click}
                      className="border-b border-border-light pb-3 last:border-b-0 last:pb-0 cursor-pointer hover:bg-bg-secondary rounded-lg p-2 transition-colors"
                    >
                      <h4 className="text-sm font-medium text-text-primary mb-1">多模态AI在医疗诊断中的突破</h4>
                      <p className="text-xs text-text-secondary mb-2">新研究表明AI诊断准确率提升25%，为患者带来更好治疗效果</p>
                      <span className="text-xs text-tertiary">2024-01-15</span>
                    </div>
                    <div 
                      onClick={handleLatestNews2Click}
                      className="border-b border-border-light pb-3 last:border-b-0 last:pb-0 cursor-pointer hover:bg-bg-secondary rounded-lg p-2 transition-colors"
                    >
                      <h4 className="text-sm font-medium text-text-primary mb-1">OpenAI发布GPT-5技术白皮书</h4>
                      <p className="text-xs text-text-secondary mb-2">详细介绍了下一代多模态模型的技术架构和应用前景</p>
                      <span className="text-xs text-tertiary">2024-01-13</span>
                    </div>
                    <div 
                      onClick={handleLatestNews3Click}
                      className="border-b border-border-light pb-3 last:border-b-0 last:pb-0 cursor-pointer hover:bg-bg-secondary rounded-lg p-2 transition-colors"
                    >
                      <h4 className="text-sm font-medium text-text-primary mb-1">谷歌AI团队获得ICML最佳论文奖</h4>
                      <p className="text-xs text-text-secondary mb-2">其提出的新型Transformer架构在多模态理解任务中表现卓越</p>
                      <span className="text-xs text-tertiary">2024-01-11</span>
                    </div>
                  </div>
                  <div className="mt-4 text-center">
                    <Link to="/industry-news" className="text-tertiary text-sm font-medium hover:underline">查看更多资讯</Link>
                  </div>
                </div>
              </div>
            </section>

            {/* 资源统计概览 */}
            <section className="mb-8">
              <h2 className="text-2xl font-bold text-white mb-6">资源概览</h2>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                <div className={`${styles.cardGradient} rounded-xl p-6 shadow-card text-center`}>
                  <div className="w-12 h-12 bg-gradient-primary rounded-xl flex items-center justify-center mx-auto mb-3">
                    <i className="fas fa-brain text-white text-xl"></i>
                  </div>
                  <div className="text-2xl font-bold text-text-primary mb-1">156</div>
                  <div className="text-sm text-text-secondary">可用模型</div>
                </div>
                
                <div className={`${styles.cardGradient} rounded-xl p-6 shadow-card text-center`}>
                  <div className="w-12 h-12 bg-gradient-secondary rounded-xl flex items-center justify-center mx-auto mb-3">
                    <i className="fas fa-tools text-white text-xl"></i>
                  </div>
                  <div className="text-2xl font-bold text-text-primary mb-1">89</div>
                  <div className="text-sm text-text-secondary">开发工具</div>
                </div>
                
                <div className={`${styles.cardGradient} rounded-xl p-6 shadow-card text-center`}>
                  <div className="w-12 h-12 bg-gradient-tertiary rounded-xl flex items-center justify-center mx-auto mb-3">
                    <i className="fas fa-newspaper text-white text-xl"></i>
                  </div>
                  <div className="text-2xl font-bold text-text-primary mb-1">234</div>
                  <div className="text-sm text-text-secondary">行业资讯</div>
                </div>
                
                <div className={`${styles.cardGradient} rounded-xl p-6 shadow-card text-center`}>
                  <div className="w-12 h-12 bg-gradient-success rounded-xl flex items-center justify-center mx-auto mb-3">
                    <i className="fas fa-download text-white text-xl"></i>
                  </div>
                  <div className="text-2xl font-bold text-text-primary mb-1">1.2K</div>
                  <div className="text-sm text-text-secondary">下载资源</div>
                </div>
              </div>
            </section>
          </div>
        </main>
      </div>
    </div>
  );
};

export default ResourceCenterPage;

