

import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import styles from './styles.module.css';

interface Resource {
  id: number;
  name: string;
  type: string;
  course: string;
  courseId: string;
  size: string;
  sizeBytes: number;
  date: string;
  downloads: number;
}

interface SortConfig {
  field: keyof Resource;
  direction: 'asc' | 'desc';
}

const ResourceDownloadPage: React.FC = () => {
  const navigate = useNavigate();
  
  // 模拟资源数据
  const mockResources: Resource[] = [
    {
      id: 1,
      name: 'GPT-4V入门课件完整版',
      type: '课件',
      course: 'GPT-4V多模态入门实战',
      courseId: 'course1',
      size: '25.6 MB',
      sizeBytes: 25600000,
      date: '2024-01-15',
      downloads: 1256
    },
    {
      id: 2,
      name: 'CLIP模型训练代码',
      type: '代码',
      course: 'CLIP模型训练与应用',
      courseId: 'course2',
      size: '2.3 MB',
      sizeBytes: 2300000,
      date: '2024-01-14',
      downloads: 892
    },
    {
      id: 3,
      name: 'ImageNet数据集(精简版)',
      type: '数据集',
      course: 'CLIP模型训练与应用',
      courseId: 'course2',
      size: '1.2 GB',
      sizeBytes: 1200000000,
      date: '2024-01-13',
      downloads: 445
    },
    {
      id: 4,
      name: 'DALL-E图像生成示例代码',
      type: '代码',
      course: 'DALL-E图像生成技术',
      courseId: 'course3',
      size: '1.8 MB',
      sizeBytes: 1800000,
      date: '2024-01-12',
      downloads: 678
    },
    {
      id: 5,
      name: '多模态模型部署指南',
      type: '课件',
      course: '多模态模型部署优化',
      courseId: 'course4',
      size: '15.2 MB',
      sizeBytes: 15200000,
      date: '2024-01-11',
      downloads: 324
    },
    {
      id: 6,
      name: 'GPT-4V API使用文档',
      type: '课件',
      course: 'GPT-4V多模态入门实战',
      courseId: 'course1',
      size: '8.7 MB',
      sizeBytes: 8700000,
      date: '2024-01-10',
      downloads: 956
    },
    {
      id: 7,
      name: '模型评估数据集',
      type: '数据集',
      course: '多模态模型部署优化',
      courseId: 'course4',
      size: '456 MB',
      sizeBytes: 456000000,
      date: '2024-01-09',
      downloads: 234
    },
    {
      id: 8,
      name: '多模态Transformer实现代码',
      type: '代码',
      course: 'CLIP模型训练与应用',
      courseId: 'course2',
      size: '3.4 MB',
      sizeBytes: 3400000,
      date: '2024-01-08',
      downloads: 567
    },
    {
      id: 9,
      name: 'DALL-E模型训练教程',
      type: '课件',
      course: 'DALL-E图像生成技术',
      courseId: 'course3',
      size: '18.9 MB',
      sizeBytes: 18900000,
      date: '2024-01-07',
      downloads: 789
    },
    {
      id: 10,
      name: '预训练模型权重文件',
      type: '数据集',
      course: 'CLIP模型训练与应用',
      courseId: 'course2',
      size: '3.2 GB',
      sizeBytes: 3200000000,
      date: '2024-01-06',
      downloads: 123
    }
  ];

  // 状态管理
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize] = useState(10);
  const [filteredResources, setFilteredResources] = useState<Resource[]>([...mockResources]);
  const [currentSort, setCurrentSort] = useState<SortConfig>({ field: 'date', direction: 'desc' });
  const [resourceSearch, setResourceSearch] = useState('');
  const [resourceTypeFilter, setResourceTypeFilter] = useState('');
  const [courseFilter, setCourseFilter] = useState('');
  const [sortSelect, setSortSelect] = useState('latest');
  const [globalSearch, setGlobalSearch] = useState('');
  const [downloadingResources, setDownloadingResources] = useState<Set<number>>(new Set());

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = '资源下载 - 模学苑';
    return () => { document.title = originalTitle; };
  }, []);

  // 筛选资源
  const filterResources = () => {
    let filtered = mockResources.filter(resource => {
      const matchesSearch = !resourceSearch || resource.name.toLowerCase().includes(resourceSearch.toLowerCase());
      const matchesType = !resourceTypeFilter || resource.type === resourceTypeFilter;
      const matchesCourse = !courseFilter || resource.courseId === courseFilter;
      
      return matchesSearch && matchesType && matchesCourse;
    });

    setFilteredResources(filtered);
    setCurrentPage(1);
  };

  // 监听筛选条件变化
  useEffect(() => {
    filterResources();
  }, [resourceSearch, resourceTypeFilter, courseFilter]);

  // 排序资源
  const sortResources = (resources: Resource[]): Resource[] => {
    return resources.sort((a, b) => {
      let aValue = a[currentSort.field];
      let bValue = b[currentSort.field];

      if (typeof aValue === 'string') {
        aValue = aValue.toLowerCase();
        bValue = bValue.toLowerCase();
      }

      if (currentSort.direction === 'asc') {
        return aValue > bValue ? 1 : -1;
      } else {
        return aValue < bValue ? 1 : -1;
      }
    });
  };

  // 处理排序选择
  const handleSortSelectChange = (value: string) => {
    setSortSelect(value);
    switch(value) {
      case 'latest':
        setCurrentSort({ field: 'date', direction: 'desc' });
        break;
      case 'popular':
        setCurrentSort({ field: 'downloads', direction: 'desc' });
        break;
      case 'name-asc':
        setCurrentSort({ field: 'name', direction: 'asc' });
        break;
      case 'name-desc':
        setCurrentSort({ field: 'name', direction: 'desc' });
        break;
      case 'size-asc':
        setCurrentSort({ field: 'sizeBytes', direction: 'asc' });
        break;
      case 'size-desc':
        setCurrentSort({ field: 'sizeBytes', direction: 'desc' });
        break;
    }
  };

  // 处理表格排序
  const handleTableSort = (field: keyof Resource) => {
    const newDirection = currentSort.field === field && currentSort.direction === 'asc' ? 'desc' : 'asc';
    setCurrentSort({ field, direction: newDirection });
  };

  // 获取排序指示器
  const getSortIndicator = (field: keyof Resource) => {
    if (currentSort.field !== field) {
      return 'fas fa-sort sort-indicator';
    }
    return `fas fa-sort-${currentSort.direction} sort-indicator`;
  };

  // 获取资源图标
  const getResourceIcon = (type: string) => {
    switch(type) {
      case '课件': return 'pdf';
      case '代码': return 'code';
      case '数据集': return 'database';
      default: return 'file';
    }
  };

  // 获取资源类型颜色
  const getResourceTypeColor = (type: string) => {
    switch(type) {
      case '课件': return 'bg-blue-100 text-blue-800';
      case '代码': return 'bg-green-100 text-green-800';
      case '数据集': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  // 下载资源
  const downloadResource = async (resourceId: number) => {
    const resource = mockResources.find(r => r.id === resourceId);
    if (resource) {
      console.log(`开始下载资源: ${resource.name}`);
      setDownloadingResources(prev => new Set([...prev, resourceId]));

      // 模拟下载过程
      await new Promise(resolve => setTimeout(resolve, 1500));

      setDownloadingResources(prev => {
        const newSet = new Set(prev);
        newSet.delete(resourceId);
        return newSet;
      });
    }
  };

  // 处理全局搜索
  const handleGlobalSearchKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      const keyword = globalSearch.trim();
      if (keyword) {
        navigate(`/search-results?q=${encodeURIComponent(keyword)}`);
      }
    }
  };

  // 分页计算
  const totalPages = Math.ceil(filteredResources.length / pageSize);
  const startIndex = (currentPage - 1) * pageSize;
  const endIndex = startIndex + pageSize;
  const sortedResources = sortResources([...filteredResources]);
  const currentPageResources = sortedResources.slice(startIndex, endIndex);
  const showingStart = filteredResources.length > 0 ? startIndex + 1 : 0;
  const showingEnd = Math.min(currentPage * pageSize, filteredResources.length);

  // 生成页码按钮
  const generatePageNumbers = () => {
    const maxVisiblePages = 5;
    let startPage = Math.max(1, currentPage - Math.floor(maxVisiblePages / 2));
    let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);
    
    if (endPage - startPage + 1 < maxVisiblePages) {
      startPage = Math.max(1, endPage - maxVisiblePages + 1);
    }

    const pages = [];
    for (let i = startPage; i <= endPage; i++) {
      pages.push(
        <button
          key={i}
          onClick={() => setCurrentPage(i)}
          className={`px-3 py-1 border border-border-light rounded-lg transition-colors ${
            i === currentPage 
              ? 'bg-primary text-white border-primary' 
              : 'text-white/80 hover:text-white hover:border-primary'
          }`}
        >
          {i}
        </button>
      );
    }
    return pages;
  };

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <header className="fixed top-0 left-0 right-0 bg-white/90 backdrop-blur-md border-b border-border-light z-50">
        <div className="flex items-center justify-between px-6 py-3">
          {/* Logo区域 */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-primary rounded-xl flex items-center justify-center">
              <i className="fas fa-graduation-cap text-white text-lg"></i>
            </div>
            <h1 className={`text-xl font-bold ${styles.gradientText}`}>模学苑</h1>
          </div>
          
          {/* 主导航 */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/home" className="text-text-secondary hover:text-primary py-1 transition-colors">首页</Link>
            <Link to="/course-list" className="text-text-secondary hover:text-primary py-1 transition-colors">课程</Link>
            <Link to="/community-overview" className="text-text-secondary hover:text-primary py-1 transition-colors">社区</Link>
            <Link to="/resource-center" className="text-primary font-medium border-b-2 border-primary py-1">资源中心</Link>
          </nav>
          
          {/* 搜索和用户区域 */}
          <div className="flex items-center space-x-4">
            {/* 全局搜索 */}
            <div className="relative hidden lg:block">
              <input
                type="text"
                placeholder="搜索课程、资源..."
                value={globalSearch}
                onChange={(e) => setGlobalSearch(e.target.value)}
                onKeyPress={handleGlobalSearchKeyPress}
                className="w-80 pl-10 pr-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary"></i>
            </div>
            
            {/* 消息通知 */}
            <button className="relative p-2 text-text-secondary hover:text-primary transition-colors">
              <i className="fas fa-bell text-lg"></i>
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-danger rounded-full"></span>
            </button>
            
            {/* 用户头像 */}
            <div className="flex items-center space-x-2 cursor-pointer">
              <img
                src="https://s.coze.cn/image/1TE3fP9v2LY/"
                alt="用户头像"
                className="w-8 h-8 rounded-full border-2 border-primary/20"
              />
              <span className="hidden md:block text-text-primary font-medium">张同学</span>
              <i className="fas fa-chevron-down text-text-secondary text-sm"></i>
            </div>
          </div>
        </div>
      </header>

      <div className="flex pt-16">
        {/* 左侧菜单 */}
        <aside className={`fixed left-0 top-16 bottom-0 w-60 ${styles.sidebarGradient} text-white overflow-y-auto`}>
          <div className="p-4">
            <nav className="space-y-2">
              <Link to="/home" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-home text-lg"></i>
                <span>首页</span>
              </Link>
              <Link to="/course-list" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-book text-lg"></i>
                <span>课程中心</span>
              </Link>
              <Link to="/community-overview" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-users text-lg"></i>
                <span>社区互动</span>
              </Link>
              <Link to="/resource-center" className="flex items-center space-x-3 px-4 py-3 rounded-xl bg-white/20 backdrop-blur-sm">
                <i className="fas fa-database text-lg"></i>
                <span>资源中心</span>
              </Link>
              <Link to="/user-profile" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-user text-lg"></i>
                <span>个人中心</span>
              </Link>
            </nav>
            
            {/* 学习进度卡片 */}
            <div className="mt-8 p-4 bg-white/10 backdrop-blur-sm rounded-xl">
              <h3 className="font-semibold mb-3">今日学习</h3>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>进度</span>
                  <span>75%</span>
                </div>
                <div className="w-full bg-white/20 rounded-full h-2">
                  <div className="bg-white h-2 rounded-full" style={{width: '75%'}}></div>
                </div>
                <div className="flex justify-between text-sm">
                  <span>已学时长</span>
                  <span>2.5小时</span>
                </div>
              </div>
            </div>
          </div>
        </aside>

        {/* 主内容区域 */}
        <main className="flex-1 ml-60 min-h-screen">
          <div className="max-w-7xl mx-auto p-6">
            {/* 页面头部 */}
            <div className="mb-6">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-3xl font-bold text-white mb-2">资源下载</h1>
                  <nav className="text-white/80">
                    <Link to="/home" className="hover:text-white transition-colors">首页</Link>
                    <span className="mx-2">{'>'}</span>
                    <Link to="/resource-center" className="hover:text-white transition-colors">资源中心</Link>
                    <span className="mx-2">{'>'}</span>
                    <span>资源下载</span>
                  </nav>
                </div>
              </div>
            </div>

            {/* 工具栏区域 */}
            <div className={`${styles.cardGradient} rounded-xl p-6 shadow-card mb-6`}>
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
                {/* 搜索和筛选 */}
                <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
                  {/* 搜索框 */}
                  <div className="relative">
                    <input
                      type="text"
                      placeholder="搜索资源名称..."
                      value={resourceSearch}
                      onChange={(e) => setResourceSearch(e.target.value)}
                      className="w-full sm:w-80 pl-10 pr-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                    />
                    <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary"></i>
                  </div>

                  {/* 资源类型筛选 */}
                  <select
                    value={resourceTypeFilter}
                    onChange={(e) => setResourceTypeFilter(e.target.value)}
                    className="px-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                  >
                    <option value="">全部类型</option>
                    <option value="课件">课件</option>
                    <option value="代码">代码</option>
                    <option value="数据集">数据集</option>
                  </select>

                  {/* 所属课程筛选 */}
                  <select
                    value={courseFilter}
                    onChange={(e) => setCourseFilter(e.target.value)}
                    className="px-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                  >
                    <option value="">全部课程</option>
                    <option value="course1">GPT-4V多模态入门实战</option>
                    <option value="course2">CLIP模型训练与应用</option>
                    <option value="course3">DALL-E图像生成技术</option>
                    <option value="course4">多模态模型部署优化</option>
                  </select>

                  {/* 排序方式 */}
                  <select
                    value={sortSelect}
                    onChange={(e) => handleSortSelectChange(e.target.value)}
                    className="px-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                  >
                    <option value="latest">最新</option>
                    <option value="popular">最热</option>
                    <option value="name-asc">名称A-Z</option>
                    <option value="name-desc">名称Z-A</option>
                    <option value="size-asc">文件大小从小到大</option>
                    <option value="size-desc">文件大小从大到小</option>
                  </select>
                </div>
              </div>
            </div>

            {/* 数据展示区域 */}
            <div className={`${styles.cardGradient} rounded-xl shadow-card mb-6`}>
              <div className="overflow-x-auto">
                <table className={`w-full ${styles.tableSortable}`}>
                  <thead className="bg-bg-secondary">
                    <tr>
                      <th
                        className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider cursor-pointer user-select-none hover:bg-primary/10"
                        onClick={() => handleTableSort('name')}
                      >
                        资源名称 <i className={getSortIndicator('name')}></i>
                      </th>
                      <th
                        className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider cursor-pointer user-select-none hover:bg-primary/10"
                        onClick={() => handleTableSort('type')}
                      >
                        类型 <i className={getSortIndicator('type')}></i>
                      </th>
                      <th
                        className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider cursor-pointer user-select-none hover:bg-primary/10"
                        onClick={() => handleTableSort('course')}
                      >
                        所属课程 <i className={getSortIndicator('course')}></i>
                      </th>
                      <th
                        className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider cursor-pointer user-select-none hover:bg-primary/10"
                        onClick={() => handleTableSort('sizeBytes')}
                      >
                        文件大小 <i className={getSortIndicator('sizeBytes')}></i>
                      </th>
                      <th
                        className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider cursor-pointer user-select-none hover:bg-primary/10"
                        onClick={() => handleTableSort('date')}
                      >
                        发布日期 <i className={getSortIndicator('date')}></i>
                      </th>
                      <th
                        className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider cursor-pointer user-select-none hover:bg-primary/10"
                        onClick={() => handleTableSort('downloads')}
                      >
                        下载次数 <i className={getSortIndicator('downloads')}></i>
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                        操作
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-border-light">
                    {currentPageResources.map(resource => (
                      <tr key={resource.id} className="hover:bg-bg-secondary transition-colors">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <i className={`fas fa-file-${getResourceIcon(resource.type)} text-primary mr-3`}></i>
                            <div>
                              <div className="text-sm font-medium text-text-primary">{resource.name}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getResourceTypeColor(resource.type)}`}>
                            {resource.type}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <Link to={`/course-detail?id=${resource.courseId}`} className="text-primary hover:text-secondary transition-colors">
                            {resource.course}
                          </Link>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary">
                          {resource.size}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary">
                          {resource.date}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary">
                          {resource.downloads}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          <button
                            onClick={() => downloadResource(resource.id)}
                            disabled={downloadingResources.has(resource.id)}
                            className="text-primary hover:text-secondary transition-colors disabled:opacity-50"
                          >
                            {downloadingResources.has(resource.id) ? (
                              <>
                                <i className="fas fa-spinner fa-spin mr-1"></i>
                                下载中...
                              </>
                            ) : (
                              <>
                                <i className="fas fa-download mr-1"></i>
                                下载
                              </>
                            )}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* 分页区域 */}
            <div className="flex items-center justify-between">
              <div className="text-white/80 text-sm">
                显示 <span>{showingStart}</span> 到 <span>{showingEnd}</span> 条，共 <span>{filteredResources.length}</span> 条记录
              </div>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                  disabled={currentPage === 1}
                  className="px-3 py-1 border border-border-light rounded-lg text-white/80 hover:text-white hover:border-primary transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <i className="fas fa-chevron-left"></i>
                </button>
                <div className="flex space-x-1">
                  {generatePageNumbers()}
                </div>
                <button
                  onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                  disabled={currentPage === totalPages || totalPages === 0}
                  className="px-3 py-1 border border-border-light rounded-lg text-white/80 hover:text-white hover:border-primary transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <i className="fas fa-chevron-right"></i>
                </button>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default ResourceDownloadPage;

