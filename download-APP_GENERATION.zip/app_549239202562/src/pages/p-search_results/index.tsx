

import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import styles from './styles.module.css';

interface SearchResult {
  id: string;
  type: 'course' | 'discussion' | 'question' | 'model' | 'news' | 'tool' | 'download';
  title: string;
  description: string;
  author?: string;
  rating?: number;
  students?: string;
  replies?: number;
  views?: string;
  status?: string;
  date?: string;
  size?: string;
  difficulty?: string;
  coverImage?: string;
}

const SearchResultsPage: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [activeTab, setActiveTab] = useState<'all' | 'courses' | 'community' | 'resources'>('all');
  const [globalSearchValue, setGlobalSearchValue] = useState('');

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = '搜索结果 - 模学苑';
    return () => { document.title = originalTitle; };
  }, []);

  // 获取URL参数并更新搜索框
  useEffect(() => {
    const keyword = searchParams.get('q') || searchParams.get('keyword') || '';
    setGlobalSearchValue(keyword);
  }, [searchParams]);

  // 模拟搜索结果数据
  const searchResults: SearchResult[] = [
    {
      id: 'course1',
      type: 'course',
      title: 'GPT-4V多模态入门实战',
      description: '从零开始学习GPT-4V的多模态能力，掌握图像理解和生成技术',
      author: '李教授',
      rating: 4.8,
      students: '1.2万人学习'
    },
    {
      id: 'post1',
      type: 'discussion',
      title: '如何优化GPT模型的推理速度？',
      description: '分享一些GPT模型推理优化的实用技巧和经验',
      author: 'AI开发者',
      replies: 23,
      views: '1.2k浏览'
    },
    {
      id: 'model1',
      type: 'model',
      title: 'GPT-4V多模态模型',
      description: 'OpenAI最新发布的多模态大模型，支持图像和文本的理解与生成',
      date: '2024-01-10'
    },
    {
      id: 'question1',
      type: 'question',
      title: 'GPT模型训练时如何选择合适的学习率？',
      description: '请教一下大家在训练GPT类模型时的学习率设置经验',
      author: '机器学习新手',
      replies: 8,
      status: '已解决'
    }
  ];

  const courseResults = [
    {
      id: 'course1',
      title: 'GPT-4V多模态入门实战',
      description: '从零开始学习GPT-4V的多模态能力',
      author: '李教授',
      difficulty: '入门',
      students: '1.2万',
      rating: 4.8,
      coverImage: 'https://s.coze.cn/image/hum45bAKdbY/'
    },
    {
      id: 'course2',
      title: 'GPT模型训练与调优',
      description: '深入理解GPT模型的训练原理',
      author: '王博士',
      difficulty: '中级',
      students: '8.5k',
      rating: 4.9,
      coverImage: 'https://s.coze.cn/image/K6eswKRz3SE/'
    },
    {
      id: 'course3',
      title: 'GPT模型部署与优化',
      description: '生产环境下的GPT模型部署最佳实践',
      author: '张工程师',
      difficulty: '高级',
      students: '6.3k',
      rating: 4.7,
      coverImage: 'https://s.coze.cn/image/tcLxPHsQ-rQ/'
    }
  ];

  const communityResults = [
    {
      id: 'post1',
      type: 'discussion',
      title: '如何优化GPT模型的推理速度？',
      description: '分享一些GPT模型推理优化的实用技巧和经验',
      author: 'AI开发者',
      replies: 23,
      status: '活跃'
    },
    {
      id: 'question1',
      type: 'question',
      title: 'GPT模型训练时如何选择合适的学习率？',
      description: '请教一下大家在训练GPT类模型时的学习率设置经验',
      author: '机器学习新手',
      replies: 8,
      status: '已解决'
    },
    {
      id: 'post2',
      type: 'discussion',
      title: 'GPT-4V在实际项目中的应用案例分享',
      description: '分享我们团队使用GPT-4V开发的智能客服系统',
      author: '产品经理',
      replies: 15,
      status: '活跃'
    }
  ];

  const resourceResults = [
    {
      id: 'model1',
      type: 'model',
      title: 'GPT-4V多模态模型',
      description: 'OpenAI最新发布的多模态大模型，支持图像和文本的理解与生成',
      date: '2024-01-10'
    },
    {
      id: 'news1',
      type: 'news',
      title: 'GPT-5即将发布，多模态能力再次突破',
      description: 'OpenAI宣布GPT-5将在明年初发布，将具备更强的多模态理解和生成能力',
      date: '2024-01-15'
    },
    {
      id: 'tool1',
      type: 'tool',
      title: 'GPT模型训练工具包',
      description: '包含数据预处理、模型训练、评估等全套工具',
      size: '15.2MB'
    },
    {
      id: 'download1',
      type: 'download',
      title: 'GPT模型训练数据集',
      description: '高质量的多模态训练数据集，适用于GPT类模型训练',
      size: '2.1GB'
    }
  ];

  const handleGlobalSearchKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      const keyword = (e.target as HTMLInputElement).value.trim();
      if (keyword) {
        navigate(`/search-results?q=${encodeURIComponent(keyword)}`);
      }
    }
  };

  const handleTabClick = (tab: 'all' | 'courses' | 'community' | 'resources') => {
    setActiveTab(tab);
  };

  const handleSearchResultClick = (result: SearchResult) => {
    switch (result.type) {
      case 'course':
        navigate(`/course-detail?id=${result.id}`);
        break;
      case 'discussion':
        navigate(`/discussion-forum?postId=${result.id}`);
        break;
      case 'question':
        navigate(`/question-answer?questionId=${result.id}`);
        break;
      case 'model':
        navigate(`/model-library?modelId=${result.id}`);
        break;
      case 'news':
        navigate(`/industry-news?id=${result.id}`);
        break;
      case 'tool':
        navigate(`/tool-collection?toolId=${result.id}`);
        break;
      case 'download':
        navigate(`/resource-download?resourceId=${result.id}`);
        break;
      default:
        console.log('未知类型:', result.type);
    }
  };

  const handleCourseClick = (courseId: string) => {
    navigate(`/course-detail?id=${courseId}`);
  };

  const handleCommunityItemClick = (type: string, id: string) => {
    switch (type) {
      case 'discussion':
        navigate(`/discussion-forum?postId=${id}`);
        break;
      case 'question':
        navigate(`/question-answer?questionId=${id}`);
        break;
      default:
        console.log('未知类型:', type);
    }
  };

  const handleResourceClick = (type: string, id: string) => {
    switch (type) {
      case 'model':
        navigate(`/model-library?modelId=${id}`);
        break;
      case 'news':
        navigate(`/industry-news?id=${id}`);
        break;
      case 'tool':
        navigate(`/tool-collection?toolId=${id}`);
        break;
      case 'download':
        navigate(`/resource-download?resourceId=${id}`);
        break;
      default:
        console.log('未知类型:', type);
    }
  };

  const getResultIcon = (type: string) => {
    switch (type) {
      case 'course':
        return 'fas fa-book';
      case 'discussion':
        return 'fas fa-comments';
      case 'question':
        return 'fas fa-question-circle';
      case 'model':
        return 'fas fa-brain';
      default:
        return 'fas fa-file';
    }
  };

  const getResultIconBg = (type: string) => {
    switch (type) {
      case 'course':
        return 'bg-gradient-primary';
      case 'discussion':
        return 'bg-gradient-secondary';
      case 'question':
        return 'bg-gradient-success';
      case 'model':
        return 'bg-gradient-tertiary';
      default:
        return 'bg-gradient-primary';
    }
  };

  const getResultBadge = (type: string) => {
    switch (type) {
      case 'course':
        return { text: '课程', class: 'bg-primary/10 text-primary' };
      case 'discussion':
        return { text: '讨论', class: 'bg-secondary/10 text-secondary' };
      case 'question':
        return { text: '问答', class: 'bg-success/10 text-success' };
      case 'model':
        return { text: '模型', class: 'bg-tertiary/10 text-tertiary' };
      case 'news':
        return { text: '资讯', class: 'bg-info/10 text-info' };
      case 'tool':
        return { text: '工具', class: 'bg-warning/10 text-warning' };
      case 'download':
        return { text: '下载', class: 'bg-success/10 text-success' };
      default:
        return { text: '其他', class: 'bg-primary/10 text-primary' };
    }
  };

  const getDifficultyBadge = (difficulty: string) => {
    switch (difficulty) {
      case '入门':
        return { class: 'bg-primary/10 text-primary' };
      case '中级':
        return { class: 'bg-secondary/10 text-secondary' };
      case '高级':
        return { class: 'bg-tertiary/10 text-tertiary' };
      default:
        return { class: 'bg-primary/10 text-primary' };
    }
  };

  const keyword = searchParams.get('q') || searchParams.get('keyword') || 'GPT';

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <header className="fixed top-0 left-0 right-0 bg-white/90 backdrop-blur-md border-b border-border-light z-50">
        <div className="flex items-center justify-between px-6 py-3">
          {/* Logo区域 */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-primary rounded-xl flex items-center justify-center">
              <i className="fas fa-graduation-cap text-white text-lg"></i>
            </div>
            <h1 className={`text-xl font-bold ${styles.gradientText}`}>模学苑</h1>
          </div>
          
          {/* 主导航 */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/home" className="text-text-secondary hover:text-primary py-1 transition-colors">首页</Link>
            <Link to="/course-list" className="text-text-secondary hover:text-primary py-1 transition-colors">课程</Link>
            <Link to="/community-overview" className="text-text-secondary hover:text-primary py-1 transition-colors">社区</Link>
            <Link to="/resource-center" className="text-text-secondary hover:text-primary py-1 transition-colors">资源中心</Link>
          </nav>
          
          {/* 搜索和用户区域 */}
          <div className="flex items-center space-x-4">
            {/* 全局搜索 */}
            <div className="relative hidden lg:block">
              <input 
                type="text" 
                placeholder="搜索课程、资源..." 
                value={globalSearchValue}
                onChange={(e) => setGlobalSearchValue(e.target.value)}
                onKeyPress={handleGlobalSearchKeyPress}
                className="w-80 pl-10 pr-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary"></i>
            </div>
            
            {/* 消息通知 */}
            <button className="relative p-2 text-text-secondary hover:text-primary transition-colors">
              <i className="fas fa-bell text-lg"></i>
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-danger rounded-full"></span>
            </button>
            
            {/* 用户头像 */}
            <div className="flex items-center space-x-2 cursor-pointer">
              <img 
                src="https://s.coze.cn/image/8Nl9PujfFtQ/" 
                alt="用户头像" 
                className="w-8 h-8 rounded-full border-2 border-primary/20"
              />
              <span className="hidden md:block text-text-primary font-medium">张同学</span>
              <i className="fas fa-chevron-down text-text-secondary text-sm"></i>
            </div>
          </div>
        </div>
      </header>

      <div className="flex pt-16">
        {/* 左侧菜单 */}
        <aside className={`fixed left-0 top-16 bottom-0 w-60 ${styles.sidebarGradient} text-white overflow-y-auto`}>
          <div className="p-4">
            <nav className="space-y-2">
              <Link to="/home" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-home text-lg"></i>
                <span>首页</span>
              </Link>
              <Link to="/course-list" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-book text-lg"></i>
                <span>课程中心</span>
              </Link>
              <Link to="/community-overview" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-users text-lg"></i>
                <span>社区互动</span>
              </Link>
              <Link to="/resource-center" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-database text-lg"></i>
                <span>资源中心</span>
              </Link>
              <Link to="/user-profile" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-user text-lg"></i>
                <span>个人中心</span>
              </Link>
            </nav>
            
            {/* 学习进度卡片 */}
            <div className="mt-8 p-4 bg-white/10 backdrop-blur-sm rounded-xl">
              <h3 className="font-semibold mb-3">今日学习</h3>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>进度</span>
                  <span>75%</span>
                </div>
                <div className="w-full bg-white/20 rounded-full h-2">
                  <div className="bg-white h-2 rounded-full" style={{width: '75%'}}></div>
                </div>
                <div className="flex justify-between text-sm">
                  <span>已学时长</span>
                  <span>2.5小时</span>
                </div>
              </div>
            </div>
          </div>
        </aside>

        {/* 主内容区域 */}
        <main className="flex-1 ml-60 min-h-screen">
          <div className="max-w-7xl mx-auto p-6">
            {/* 页面头部 */}
            <div className="mb-6">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-3xl font-bold text-white mb-2">
                    搜索结果：<span className="text-white/80">{keyword}</span>
                  </h1>
                  <nav className="text-white/80">
                    <Link to="/home" className="hover:text-white transition-colors">首页</Link>
                    <span className="mx-2">{'>'}</span>
                    <span>搜索结果</span>
                  </nav>
                </div>
                <div className="text-white/80">
                  <span>找到 156 个相关结果</span>
                </div>
              </div>
            </div>

            {/* 搜索结果分类Tab */}
            <div className="mb-6">
              <div className="flex space-x-4" role="tablist">
                <button 
                  onClick={() => handleTabClick('all')}
                  className={`px-6 py-3 text-sm font-medium rounded-xl focus:outline-none ${
                    activeTab === 'all' ? styles.tabActive : styles.tabInactive
                  }`}
                  role="tab"
                >
                  全部 <span className="ml-1 text-xs">(156)</span>
                </button>
                <button 
                  onClick={() => handleTabClick('courses')}
                  className={`px-6 py-3 text-sm font-medium rounded-xl focus:outline-none ${
                    activeTab === 'courses' ? styles.tabActive : styles.tabInactive
                  }`}
                  role="tab"
                >
                  课程 <span className="ml-1 text-xs">(23)</span>
                </button>
                <button 
                  onClick={() => handleTabClick('community')}
                  className={`px-6 py-3 text-sm font-medium rounded-xl focus:outline-none ${
                    activeTab === 'community' ? styles.tabActive : styles.tabInactive
                  }`}
                  role="tab"
                >
                  社区 <span className="ml-1 text-xs">(89)</span>
                </button>
                <button 
                  onClick={() => handleTabClick('resources')}
                  className={`px-6 py-3 text-sm font-medium rounded-xl focus:outline-none ${
                    activeTab === 'resources' ? styles.tabActive : styles.tabInactive
                  }`}
                  role="tab"
                >
                  资源 <span className="ml-1 text-xs">(44)</span>
                </button>
              </div>
            </div>

            {/* 搜索结果内容区域 */}
            <div>
              {/* 全部结果Tab */}
              {activeTab === 'all' && (
                <div className="space-y-4">
                  {searchResults.map((result) => (
                    <div 
                      key={result.id}
                      onClick={() => handleSearchResultClick(result)}
                      className={`${styles.cardGradient} rounded-xl p-6 shadow-card hover:shadow-card-hover transition-all cursor-pointer`}
                    >
                      <div className="flex items-start space-x-4">
                        <div className={`w-12 h-12 ${getResultIconBg(result.type)} rounded-lg flex items-center justify-center flex-shrink-0`}>
                          <i className={`${getResultIcon(result.type)} text-white`}></i>
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <span className={`${getResultBadge(result.type).class} px-2 py-1 rounded-lg text-xs font-medium`}>
                              {getResultBadge(result.type).text}
                            </span>
                            <span className="text-text-secondary text-sm">{result.title}</span>
                          </div>
                          <h3 className="font-semibold text-text-primary mb-2">{result.description}</h3>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-4 text-sm text-text-secondary">
                              {result.author && (
                                <span><i className="fas fa-user mr-1"></i>{result.author}</span>
                              )}
                              {result.rating && (
                                <span><i className="fas fa-star text-warning mr-1"></i>{result.rating}</span>
                              )}
                              {result.students && (
                                <span><i className="fas fa-users mr-1"></i>{result.students}</span>
                              )}
                              {result.replies && (
                                <span><i className="fas fa-comment mr-1"></i>{result.replies}回复</span>
                              )}
                              {result.views && (
                                <span><i className="fas fa-eye mr-1"></i>{result.views}</span>
                              )}
                              {result.date && (
                                <span><i className="fas fa-calendar mr-1"></i>{result.date}</span>
                              )}
                              {result.status && (
                                <span><i className="fas fa-check-circle text-success mr-1"></i>{result.status}</span>
                              )}
                            </div>
                            <button className="text-primary hover:text-secondary transition-colors text-sm">
                              查看详情 <i className="fas fa-arrow-right ml-1"></i>
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* 课程结果Tab */}
              {activeTab === 'courses' && (
                <div className={`${styles.cardGradient} rounded-xl shadow-card overflow-hidden`}>
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-bg-secondary">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">课程名称</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">讲师</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">难度</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">学习人数</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">评分</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">操作</th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-border-light">
                        {courseResults.map((course) => (
                          <tr 
                            key={course.id}
                            onClick={() => handleCourseClick(course.id)}
                            className="hover:bg-bg-primary transition-colors cursor-pointer"
                          >
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="flex items-center">
                                <img 
                                  className="h-10 w-10 rounded-lg object-cover" 
                                  src={course.coverImage} 
                                  alt="课程封面"
                                />
                                <div className="ml-4">
                                  <div className="text-sm font-medium text-text-primary">{course.title}</div>
                                  <div className="text-sm text-text-secondary">{course.description}</div>
                                </div>
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary">{course.author}</td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className={`px-2 py-1 text-xs font-medium ${getDifficultyBadge(course.difficulty).class} rounded-full`}>
                                {course.difficulty}
                              </span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary">{course.students}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary">{course.rating}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm">
                              <button className="text-primary hover:text-secondary transition-colors">查看详情</button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* 社区结果Tab */}
              {activeTab === 'community' && (
                <div className={`${styles.cardGradient} rounded-xl shadow-card overflow-hidden`}>
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-bg-secondary">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">标题</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">类型</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">作者</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">回复数</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">状态</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">操作</th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-border-light">
                        {communityResults.map((item) => (
                          <tr 
                            key={item.id}
                            onClick={() => handleCommunityItemClick(item.type, item.id)}
                            className="hover:bg-bg-primary transition-colors cursor-pointer"
                          >
                            <td className="px-6 py-4">
                              <div className="text-sm font-medium text-text-primary">{item.title}</div>
                              <div className="text-sm text-text-secondary">{item.description}</div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className={`px-2 py-1 text-xs font-medium ${
                                item.type === 'question' ? 'bg-success/10 text-success' : 'bg-secondary/10 text-secondary'
                              } rounded-full`}>
                                {item.type === 'question' ? '问答' : '讨论'}
                              </span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary">{item.author}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary">{item.replies}</td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              {item.status === '已解决' ? (
                                <span className="px-2 py-1 text-xs font-medium bg-success/10 text-success rounded-full">已解决</span>
                              ) : (
                                <span className="text-sm text-text-secondary">{item.status}</span>
                              )}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm">
                              <button className="text-primary hover:text-secondary transition-colors">查看详情</button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* 资源结果Tab */}
              {activeTab === 'resources' && (
                <div className={`${styles.cardGradient} rounded-xl shadow-card overflow-hidden`}>
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-bg-secondary">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">标题</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">类型</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">简介</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">相关信息</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">操作</th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-border-light">
                        {resourceResults.map((resource) => (
                          <tr 
                            key={resource.id}
                            onClick={() => handleResourceClick(resource.type, resource.id)}
                            className="hover:bg-bg-primary transition-colors cursor-pointer"
                          >
                            <td className="px-6 py-4">
                              <div className="text-sm font-medium text-text-primary">{resource.title}</div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className={`px-2 py-1 text-xs font-medium ${getResultBadge(resource.type).class} rounded-full`}>
                                {getResultBadge(resource.type).text}
                              </span>
                            </td>
                            <td className="px-6 py-4 text-sm text-text-secondary">{resource.description}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary">
                              {resource.date || resource.size}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm">
                              <button className="text-primary hover:text-secondary transition-colors">查看详情</button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>

            {/* 分页区域 */}
            <div className="mt-8 flex items-center justify-between">
              <div className="text-white/80 text-sm">
                显示第 1-10 条，共 156 条结果
              </div>
              <div className="flex items-center space-x-2">
                <button 
                  className="px-3 py-2 text-sm text-white/80 hover:text-white border border-white/20 rounded-lg hover:border-white/40 transition-colors disabled:opacity-50" 
                  disabled
                >
                  <i className="fas fa-chevron-left"></i>
                </button>
                <button className="px-3 py-2 text-sm bg-white text-primary rounded-lg font-medium">1</button>
                <button className="px-3 py-2 text-sm text-white/80 hover:text-white rounded-lg transition-colors">2</button>
                <button className="px-3 py-2 text-sm text-white/80 hover:text-white rounded-lg transition-colors">3</button>
                <span className="px-3 py-2 text-sm text-white/60">...</span>
                <button className="px-3 py-2 text-sm text-white/80 hover:text-white rounded-lg transition-colors">16</button>
                <button className="px-3 py-2 text-sm text-white/80 hover:text-white border border-white/20 rounded-lg hover:border-white/40 transition-colors">
                  <i className="fas fa-chevron-right"></i>
                </button>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default SearchResultsPage;

