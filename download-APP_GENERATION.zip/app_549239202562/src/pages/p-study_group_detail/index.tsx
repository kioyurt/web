

import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import styles from './styles.module.css';

interface GroupData {
  name: string;
  description: string;
  creator: string;
  memberCount: number;
  createDate: string;
  isMember: boolean;
  isAdmin: boolean;
  coverImage: string;
}

interface Announcement {
  id: string;
  title: string;
  content: string;
  author: string;
  authorAvatar: string;
  role: string;
  time: string;
}

interface Discussion {
  id: string;
  author: string;
  authorAvatar: string;
  title: string;
  content: string;
  time: string;
  likes: number;
  replies: number;
  isLiked: boolean;
}

interface Resource {
  id: string;
  title: string;
  description: string;
  type: 'pdf' | 'code' | 'dataset';
  size: string;
  time: string;
  icon: string;
}

interface Member {
  id: string;
  name: string;
  avatar: string;
  role: string;
  joinDate: string;
  title: string;
  isCurrentUser: boolean;
}

const StudyGroupDetailPage: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const groupId = searchParams.get('groupId') || 'group1';

  // 模态框状态
  const [showAnnouncementModal, setShowAnnouncementModal] = useState(false);
  const [showDiscussionModal, setShowDiscussionModal] = useState(false);
  const [showResourceModal, setShowResourceModal] = useState(false);

  // 表单状态
  const [announcementForm, setAnnouncementForm] = useState({ title: '', content: '' });
  const [discussionForm, setDiscussionForm] = useState({ title: '', content: '' });
  const [resourceForm, setResourceForm] = useState({ title: '', description: '', file: null as File | null });

  // 成员搜索状态
  const [memberSearchKeyword, setMemberSearchKeyword] = useState('');

  // 模拟小组数据
  const groupData: Record<string, GroupData> = {
    'group1': {
      name: 'GPT-4V开发者交流群',
      description: '专注于GPT-4V多模态模型的技术交流、经验分享和项目合作，欢迎所有对多模态AI感兴趣的开发者加入！',
      creator: 'AI专家李老师',
      memberCount: 156,
      createDate: '2024-01-01',
      isMember: true,
      isAdmin: false,
      coverImage: 'https://s.coze.cn/image/2fD-imeziLc/'
    },
    'group2': {
      name: '多模态模型训练实战',
      description: '深入探讨多模态模型的训练方法、技巧和最佳实践，适合有一定经验的AI开发者',
      creator: '机器学习专家王教授',
      memberCount: 89,
      createDate: '2024-01-05',
      isMember: false,
      isAdmin: false,
      coverImage: 'https://s.coze.cn/image/4JqfiQMzPYI/'
    }
  };

  const currentGroup = groupData[groupId] || groupData['group1'];

  // 模拟公告数据
  const announcements: Announcement[] = [
    {
      id: '1',
      title: '🎉 欢迎新成员加入！',
      content: '欢迎各位新加入的开发者！请大家先做个自我介绍，分享一下自己在GPT-4V方面的经验和兴趣点。',
      author: 'AI专家李老师',
      authorAvatar: 'https://s.coze.cn/image/tV7VwRdKxWI/',
      role: '管理员',
      time: '2小时前'
    },
    {
      id: '2',
      title: '📚 本周学习计划',
      content: '本周我们将重点讨论GPT-4V的视觉理解能力，欢迎大家分享相关的论文、代码和实践经验。',
      author: 'AI专家李老师',
      authorAvatar: 'https://s.coze.cn/image/qIJqw-_s9nE/',
      role: '管理员',
      time: '1天前'
    }
  ];

  // 模拟讨论数据
  const [discussions, setDiscussions] = useState<Discussion[]>([
    {
      id: '1',
      author: '数据科学家王同学',
      authorAvatar: 'https://s.coze.cn/image/14UP9jRVjyA/',
      title: 'GPT-4V在医学影像分析中的应用探讨',
      content: '最近在研究如何将GPT-4V应用于医学影像分析，发现它在X光片和CT影像的诊断准确率上有很大潜力。有没有同学有相关经验可以分享？',
      time: '2小时前',
      likes: 12,
      replies: 8,
      isLiked: false
    },
    {
      id: '2',
      author: '前端开发者张同学',
      authorAvatar: 'https://s.coze.cn/image/I1gxACxT2d8/',
      title: '分享一个GPT-4V API调用的前端组件',
      content: '刚完成了一个基于React的GPT-4V图像分析组件，支持拖拽上传图片并实时分析。已经开源到GitHub，欢迎大家试用和提建议！',
      time: '4小时前',
      likes: 18,
      replies: 15,
      isLiked: false
    },
    {
      id: '3',
      author: '机器学习工程师陈同学',
      authorAvatar: 'https://s.coze.cn/image/p0Bd35zgQhM/',
      title: 'GPT-4V模型部署优化经验分享',
      content: '在生产环境中部署GPT-4V时遇到了一些性能问题，经过优化后推理延迟降低了60%。主要优化方向包括模型量化、批处理优化和硬件加速。详细的优化方案已经整理成文档。',
      time: '1天前',
      likes: 25,
      replies: 22,
      isLiked: false
    }
  ]);

  // 模拟资源数据
  const resources: Resource[] = [
    {
      id: '1',
      title: 'GPT-4V技术白皮书.pdf',
      description: '详细介绍GPT-4V的技术原理和应用场景',
      type: 'pdf',
      size: '2.5MB',
      time: '1天前',
      icon: 'fas fa-file-pdf'
    },
    {
      id: '2',
      title: 'GPT-4V Python SDK',
      description: '官方Python SDK，包含完整的API调用示例',
      type: 'code',
      size: '代码',
      time: '2天前',
      icon: 'fab fa-github'
    },
    {
      id: '3',
      title: '多模态训练数据集',
      description: '包含10万+图文对的高质量训练数据',
      type: 'dataset',
      size: '15GB',
      time: '3天前',
      icon: 'fas fa-database'
    }
  ];

  // 模拟成员数据
  const members: Member[] = [
    {
      id: '1',
      name: 'AI专家李老师',
      avatar: 'https://s.coze.cn/image/NuqM7f9SfX4/',
      role: '管理员',
      joinDate: '2024-01-01',
      title: '机器学习专家',
      isCurrentUser: false
    },
    {
      id: '2',
      name: '数据科学家王同学',
      avatar: 'https://s.coze.cn/image/ZEOR3uFeVRM/',
      role: '成员',
      joinDate: '2024-01-02',
      title: '数据科学家',
      isCurrentUser: false
    },
    {
      id: '3',
      name: '前端开发者张同学',
      avatar: 'https://s.coze.cn/image/jUbkFMwmKjg/',
      role: '成员',
      joinDate: '2024-01-03',
      title: '前端工程师',
      isCurrentUser: false
    },
    {
      id: '4',
      name: '机器学习工程师陈同学',
      avatar: 'https://s.coze.cn/image/ZRokj5672HQ/',
      role: '成员',
      joinDate: '2024-01-05',
      title: '算法工程师',
      isCurrentUser: false
    },
    {
      id: '5',
      name: '张同学',
      avatar: 'https://s.coze.cn/image/DkuhsfjqKdE/',
      role: '成员',
      joinDate: '2024-01-15',
      title: 'AI学习者',
      isCurrentUser: true
    }
  ];

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = `${currentGroup.name} - 模学苑`;
    return () => { document.title = originalTitle; };
  }, [currentGroup.name]);

  // 全局搜索处理
  const handleGlobalSearch = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      const keyword = (e.target as HTMLInputElement).value.trim();
      if (keyword) {
        navigate(`/search-results?q=${encodeURIComponent(keyword)}`);
      }
    }
  };

  // 小组操作处理
  const handleGroupAction = () => {
    if (currentGroup.isMember) {
      if (confirm('确定要退出这个小组吗？')) {
        alert('已退出小组');
        window.location.reload();
      }
    } else {
      if (confirm('确定要申请加入这个小组吗？')) {
        alert('申请已提交，等待管理员审核');
      }
    }
  };

  // 模态框控制
  const showModal = (modalType: 'announcement' | 'discussion' | 'resource') => {
    switch (modalType) {
      case 'announcement':
        setShowAnnouncementModal(true);
        break;
      case 'discussion':
        setShowDiscussionModal(true);
        break;
      case 'resource':
        setShowResourceModal(true);
        break;
    }
    document.body.style.overflow = 'hidden';
  };

  const hideModal = (modalType: 'announcement' | 'discussion' | 'resource') => {
    switch (modalType) {
      case 'announcement':
        setShowAnnouncementModal(false);
        setAnnouncementForm({ title: '', content: '' });
        break;
      case 'discussion':
        setShowDiscussionModal(false);
        setDiscussionForm({ title: '', content: '' });
        break;
      case 'resource':
        setShowResourceModal(false);
        setResourceForm({ title: '', description: '', file: null });
        break;
    }
    document.body.style.overflow = 'auto';
  };

  // 发布公告
  const handleAnnouncementSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (announcementForm.title && announcementForm.content) {
      alert('公告发布成功！');
      hideModal('announcement');
    }
  };

  // 发布讨论
  const handleDiscussionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (discussionForm.title && discussionForm.content) {
      alert('讨论发布成功！');
      hideModal('discussion');
    }
  };

  // 上传资源
  const handleResourceSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (resourceForm.title && resourceForm.file) {
      alert('资源上传成功！');
      hideModal('resource');
    }
  };

  // 文件选择处理
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    setResourceForm(prev => ({ ...prev, file }));
  };

  // 文件上传区域点击
  const handleFileUploadClick = () => {
    const fileInput = document.getElementById('resource-file') as HTMLInputElement;
    if (fileInput) {
      fileInput.click();
    }
  };

  // 讨论点赞
  const handleLikeDiscussion = (discussionId: string) => {
    setDiscussions(prev => 
      prev.map(discussion => 
        discussion.id === discussionId 
          ? { 
              ...discussion, 
              isLiked: !discussion.isLiked,
              likes: discussion.isLiked ? discussion.likes - 1 : discussion.likes + 1
            }
          : discussion
      )
    );
  };

  // 过滤成员
  const filteredMembers = members.filter(member =>
    member.name.toLowerCase().includes(memberSearchKeyword.toLowerCase())
  );

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <header className="fixed top-0 left-0 right-0 bg-white/90 backdrop-blur-md border-b border-border-light z-50">
        <div className="flex items-center justify-between px-6 py-3">
          {/* Logo区域 */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-primary rounded-xl flex items-center justify-center">
              <i className="fas fa-graduation-cap text-white text-lg"></i>
            </div>
            <h1 className={`text-xl font-bold ${styles.gradientText}`}>模学苑</h1>
          </div>
          
          {/* 主导航 */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/home" className="text-text-secondary hover:text-primary py-1 transition-colors">首页</Link>
            <Link to="/course-list" className="text-text-secondary hover:text-primary py-1 transition-colors">课程</Link>
            <Link to="/community-overview" className="text-primary font-medium border-b-2 border-primary py-1">社区</Link>
            <Link to="/resource-center" className="text-text-secondary hover:text-primary py-1 transition-colors">资源中心</Link>
          </nav>
          
          {/* 搜索和用户区域 */}
          <div className="flex items-center space-x-4">
            {/* 全局搜索 */}
            <div className="relative hidden lg:block">
              <input 
                type="text" 
                placeholder="搜索课程、资源..." 
                className="w-80 pl-10 pr-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                onKeyPress={handleGlobalSearch}
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary"></i>
            </div>
            
            {/* 消息通知 */}
            <button className="relative p-2 text-text-secondary hover:text-primary transition-colors">
              <i className="fas fa-bell text-lg"></i>
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-danger rounded-full"></span>
            </button>
            
            {/* 用户头像 */}
            <div className="flex items-center space-x-2 cursor-pointer">
              <img 
                src="https://s.coze.cn/image/0oBJPW_I3S4/" 
                alt="用户头像" 
                className="w-8 h-8 rounded-full border-2 border-primary/20"
              />
              <span className="hidden md:block text-text-primary font-medium">张同学</span>
              <i className="fas fa-chevron-down text-text-secondary text-sm"></i>
            </div>
          </div>
        </div>
      </header>

      <div className="flex pt-16">
        {/* 左侧菜单 */}
        <aside className={`fixed left-0 top-16 bottom-0 w-60 ${styles.sidebarGradient} text-white overflow-y-auto`}>
          <div className="p-4">
            <nav className="space-y-2">
              <Link to="/home" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-home text-lg"></i>
                <span>首页</span>
              </Link>
              <Link to="/course-list" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-book text-lg"></i>
                <span>课程中心</span>
              </Link>
              <Link to="/community-overview" className="flex items-center space-x-3 px-4 py-3 rounded-xl bg-white/20 backdrop-blur-sm">
                <i className="fas fa-users text-lg"></i>
                <span>社区互动</span>
              </Link>
              <Link to="/resource-center" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-database text-lg"></i>
                <span>资源中心</span>
              </Link>
              <Link to="/user-profile" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-user text-lg"></i>
                <span>个人中心</span>
              </Link>
            </nav>
            
            {/* 学习进度卡片 */}
            <div className="mt-8 p-4 bg-white/10 backdrop-blur-sm rounded-xl">
              <h3 className="font-semibold mb-3">今日学习</h3>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>进度</span>
                  <span>75%</span>
                </div>
                <div className="w-full bg-white/20 rounded-full h-2">
                  <div className="bg-white h-2 rounded-full" style={{ width: '75%' }}></div>
                </div>
                <div className="flex justify-between text-sm">
                  <span>已学时长</span>
                  <span>2.5小时</span>
                </div>
              </div>
            </div>
          </div>
        </aside>

        {/* 主内容区域 */}
        <main className="flex-1 ml-60 min-h-screen">
          <div className="max-w-7xl mx-auto p-6">
            {/* 页面头部 */}
            <div className="mb-6">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-3xl font-bold text-white mb-2">{currentGroup.name}</h1>
                  <nav className="text-white/80">
                    <Link to="/home" className="hover:text-white transition-colors">首页</Link>
                    <span className="mx-2">{'>'}</span>
                    <Link to="/community-overview" className="hover:text-white transition-colors">社区</Link>
                    <span className="mx-2">{'>'}</span>
                    <Link to="/study-group-list" className="hover:text-white transition-colors">学习小组</Link>
                    <span className="mx-2">{'>'}</span>
                    <span>{currentGroup.name}</span>
                  </nav>
                </div>
              </div>
            </div>

            {/* 小组概览区 */}
            <section className="mb-8">
              <div className={`${styles.cardGradient} rounded-2xl p-8 shadow-card`}>
                <div className="flex flex-col lg:flex-row lg:items-start space-y-6 lg:space-y-0 lg:space-x-8">
                  {/* 小组封面和基本信息 */}
                  <div className="lg:flex-1">
                    <div className="relative mb-4">
                      <img 
                        src={currentGroup.coverImage} 
                        alt={currentGroup.name} 
                        className="w-full h-64 object-cover rounded-xl"
                      />
                      <div className="absolute top-4 right-4 bg-primary text-white px-3 py-1 rounded-lg text-sm font-medium">
                        活跃
                      </div>
                    </div>
                    <h2 className="text-2xl font-bold text-text-primary mb-2">{currentGroup.name}</h2>
                    <p className="text-text-secondary mb-4">{currentGroup.description}</p>
                    <div className="flex flex-wrap items-center gap-4 text-sm text-text-secondary">
                      <div className="flex items-center space-x-2">
                        <i className="fas fa-users text-primary"></i>
                        <span>{currentGroup.memberCount}名成员</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <i className="fas fa-user-cog text-secondary"></i>
                        <span>创建者：{currentGroup.creator}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <i className="fas fa-calendar text-tertiary"></i>
                        <span>创建于：{currentGroup.createDate}</span>
                      </div>
                    </div>
                  </div>
                  
                  {/* 操作按钮和统计信息 */}
                  <div className="lg:w-80">
                    <div className="space-y-4">
                      {/* 加入/退出小组按钮 */}
                      <button 
                        onClick={handleGroupAction}
                        className={`w-full py-3 rounded-xl font-semibold transition-all ${
                          currentGroup.isMember 
                            ? 'bg-danger text-white hover:shadow-gradient' 
                            : 'bg-gradient-primary text-white hover:shadow-gradient'
                        }`}
                      >
                        <i className={`${currentGroup.isMember ? 'fas fa-user-minus' : 'fas fa-user-plus'} mr-2`}></i>
                        {currentGroup.isMember ? '退出小组' : '申请加入小组'}
                      </button>
                      
                      {/* 小组统计 */}
                      <div className="grid grid-cols-2 gap-4">
                        <div className="text-center p-4 bg-bg-secondary rounded-xl">
                          <div className="text-2xl font-bold text-primary">42</div>
                          <div className="text-sm text-text-secondary">本周讨论</div>
                        </div>
                        <div className="text-center p-4 bg-bg-secondary rounded-xl">
                          <div className="text-2xl font-bold text-secondary">18</div>
                          <div className="text-sm text-text-secondary">共享资源</div>
                        </div>
                      </div>
                      
                      {/* 小组活跃度 */}
                      <div className="p-4 bg-gradient-to-r from-primary/10 to-secondary/10 rounded-xl">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm font-medium text-text-primary">活跃度</span>
                          <span className="text-sm text-primary font-semibold">95%</span>
                        </div>
                        <div className="w-full bg-white rounded-full h-2">
                          <div className="bg-gradient-primary h-2 rounded-full" style={{ width: '95%' }}></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* 小组公告区 */}
            <section className="mb-8">
              <div className={`${styles.cardGradient} rounded-2xl p-6 shadow-card`}>
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-bold text-text-primary flex items-center">
                    <i className="fas fa-bullhorn text-warning mr-2"></i>
                    小组公告
                  </h3>
                  {currentGroup.isAdmin && (
                    <button 
                      onClick={() => showModal('announcement')}
                      className="bg-primary text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-primary/90 transition-colors"
                    >
                      <i className="fas fa-plus mr-1"></i>
                      发布公告
                    </button>
                  )}
                </div>
                
                <div className="space-y-4">
                  {announcements.map((announcement, index) => (
                    <div 
                      key={announcement.id}
                      className={`p-4 rounded-xl border-l-4 ${
                        index === 0 
                          ? 'bg-gradient-to-r from-primary/10 to-secondary/10 border-primary' 
                          : 'bg-gradient-to-r from-success/10 to-tertiary/10 border-success'
                      }`}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <h4 className="font-semibold text-text-primary">{announcement.title}</h4>
                        <span className="text-sm text-text-secondary">{announcement.time}</span>
                      </div>
                      <p className="text-sm text-text-secondary mb-2">{announcement.content}</p>
                      <div className="flex items-center text-xs text-text-secondary">
                        <img 
                          src={announcement.authorAvatar} 
                          alt={announcement.author} 
                          className="w-5 h-5 rounded-full mr-2"
                        />
                        <span>{announcement.author}</span>
                        <span className="mx-2">·</span>
                        <span>{announcement.role}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </section>

            {/* 小组讨论区 */}
            <section className="mb-8">
              <div className={`${styles.cardGradient} rounded-2xl p-6 shadow-card`}>
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-bold text-text-primary flex items-center">
                    <i className="fas fa-comments text-info mr-2"></i>
                    小组讨论
                  </h3>
                  {currentGroup.isMember && (
                    <button 
                      onClick={() => showModal('discussion')}
                      className="bg-secondary text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-secondary/90 transition-colors"
                    >
                      <i className="fas fa-edit mr-1"></i>
                      发布讨论
                    </button>
                  )}
                </div>
                
                <div className="space-y-4">
                  {discussions.map((discussion) => (
                    <div key={discussion.id} className="border-b border-border-light pb-4 last:border-b-0 last:pb-0">
                      <div className="flex items-start space-x-3 mb-3">
                        <img 
                          src={discussion.authorAvatar} 
                          alt={discussion.author} 
                          className="w-10 h-10 rounded-full"
                        />
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-1">
                            <span className="font-medium text-text-primary">{discussion.author}</span>
                            <span className="text-xs text-text-secondary">{discussion.time}</span>
                          </div>
                          <h4 className="font-medium text-text-primary mb-2">{discussion.title}</h4>
                          <p className="text-sm text-text-secondary mb-3">{discussion.content}</p>
                          <div className="flex items-center space-x-4 text-sm text-text-secondary">
                            <button 
                              onClick={() => handleLikeDiscussion(discussion.id)}
                              className={`flex items-center space-x-1 transition-colors ${
                                discussion.isLiked ? 'text-primary' : 'hover:text-primary'
                              }`}
                            >
                              <i className="fas fa-thumbs-up"></i>
                              <span>{discussion.likes}</span>
                            </button>
                            <button className="flex items-center space-x-1 hover:text-primary transition-colors">
                              <i className="fas fa-comment"></i>
                              <span>{discussion.replies}回复</span>
                            </button>
                            <button className="flex items-center space-x-1 hover:text-primary transition-colors">
                              <i className="fas fa-share"></i>
                              <span>分享</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                
                <div className="mt-6 text-center">
                  <button className="text-primary hover:text-primary/80 font-medium">
                    查看更多讨论 <i className="fas fa-arrow-right ml-1"></i>
                  </button>
                </div>
              </div>
            </section>

            {/* 小组资源区 */}
            <section className="mb-8">
              <div className={`${styles.cardGradient} rounded-2xl p-6 shadow-card`}>
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-bold text-text-primary flex items-center">
                    <i className="fas fa-folder-open text-success mr-2"></i>
                    共享资源
                  </h3>
                  {currentGroup.isMember && (
                    <button 
                      onClick={() => showModal('resource')}
                      className="bg-success text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-success/90 transition-colors"
                    >
                      <i className="fas fa-upload mr-1"></i>
                      上传资源
                    </button>
                  )}
                </div>
                
                <div className="space-y-4">
                  {resources.map((resource) => (
                    <div key={resource.id} className="flex items-center space-x-4 p-4 bg-bg-secondary rounded-xl hover:bg-bg-primary transition-colors cursor-pointer">
                      <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                        resource.type === 'pdf' ? 'bg-gradient-primary' :
                        resource.type === 'code' ? 'bg-gradient-secondary' :
                        'bg-gradient-tertiary'
                      }`}>
                        <i className={`${resource.icon} text-white text-lg`}></i>
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium text-text-primary">{resource.title}</h4>
                        <p className="text-sm text-text-secondary">{resource.description}</p>
                      </div>
                      <div className="text-right">
                        <div className="text-sm text-text-secondary">{resource.size}</div>
                        <div className="text-xs text-text-secondary">{resource.time}</div>
                      </div>
                      <button className="text-primary hover:text-primary/80">
                        <i className={`${resource.type === 'code' ? 'fas fa-external-link-alt' : 'fas fa-download'} text-lg`}></i>
                      </button>
                    </div>
                  ))}
                </div>
                
                <div className="mt-6 text-center">
                  <button className="text-primary hover:text-primary/80 font-medium">
                    查看所有资源 <i className="fas fa-arrow-right ml-1"></i>
                  </button>
                </div>
              </div>
            </section>

            {/* 成员列表区 */}
            <section className="mb-8">
              <div className={`${styles.cardGradient} rounded-2xl p-6 shadow-card`}>
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-bold text-text-primary flex items-center">
                    <i className="fas fa-users text-primary mr-2"></i>
                    成员列表 ({currentGroup.memberCount})
                  </h3>
                  <div className="flex items-center space-x-2">
                    <input 
                      type="text" 
                      placeholder="搜索成员..." 
                      value={memberSearchKeyword}
                      onChange={(e) => setMemberSearchKeyword(e.target.value)}
                      className="px-3 py-1 border border-border-light rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary/20"
                    />
                    <button className="text-text-secondary hover:text-primary">
                      <i className="fas fa-search"></i>
                    </button>
                  </div>
                </div>
                
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-border-light">
                        <th className="text-left py-3 px-4 font-medium text-text-primary">成员</th>
                        <th className="text-left py-3 px-4 font-medium text-text-primary">角色</th>
                        <th className="text-left py-3 px-4 font-medium text-text-primary">加入日期</th>
                        <th className="text-left py-3 px-4 font-medium text-text-primary">操作</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredMembers.map((member) => (
                        <tr key={member.id} className="border-b border-border-light hover:bg-bg-secondary transition-colors">
                          <td className="py-3 px-4">
                            <div className="flex items-center space-x-3">
                              <img 
                                src={member.avatar} 
                                alt={member.name} 
                                className="w-10 h-10 rounded-full"
                              />
                              <div>
                                <div className="font-medium text-text-primary">{member.name}</div>
                                <div className="text-sm text-text-secondary">{member.title}</div>
                              </div>
                            </div>
                          </td>
                          <td className="py-3 px-4">
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                              member.role === '管理员' ? styles.memberRoleAdmin : styles.memberRoleMember
                            }`}>
                              {member.role}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-sm text-text-secondary">{member.joinDate}</td>
                          <td className="py-3 px-4">
                            {member.isCurrentUser ? (
                              <div className="flex items-center space-x-2">
                                <span className="text-sm text-text-secondary">你</span>
                              </div>
                            ) : member.role === '管理员' ? (
                              <div className="flex items-center space-x-2">
                                <button className="text-text-secondary hover:text-primary text-sm">
                                  <i className="fas fa-user-cog"></i>
                                </button>
                              </div>
                            ) : (
                              <div className="flex items-center space-x-2">
                                <button className="text-text-secondary hover:text-primary text-sm">
                                  <i className="fas fa-user-times"></i>
                                </button>
                                <button className="text-text-secondary hover:text-primary text-sm">
                                  <i className="fas fa-user-cog"></i>
                                </button>
                              </div>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                
                <div className="mt-6 text-center">
                  <button className="text-primary hover:text-primary/80 font-medium">
                    查看所有成员 <i className="fas fa-arrow-right ml-1"></i>
                  </button>
                </div>
              </div>
            </section>
          </div>
        </main>
      </div>

      {/* 发布公告模态框 */}
      {showAnnouncementModal && (
        <div className="fixed inset-0 z-50">
          <div className={`${styles.modalBackdrop} absolute inset-0`} onClick={() => hideModal('announcement')}></div>
          <div className="relative flex items-center justify-center min-h-screen p-4">
            <div className="bg-white rounded-2xl shadow-gradient max-w-2xl w-full max-h-[80vh] overflow-y-auto">
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-bold text-text-primary">发布公告</h3>
                  <button 
                    onClick={() => hideModal('announcement')}
                    className="text-text-secondary hover:text-text-primary"
                  >
                    <i className="fas fa-times text-xl"></i>
                  </button>
                </div>
                
                <form onSubmit={handleAnnouncementSubmit} className="space-y-4">
                  <div>
                    <label htmlFor="announcement-title" className="block text-sm font-medium text-text-primary mb-2">公告标题</label>
                    <input 
                      type="text" 
                      id="announcement-title" 
                      value={announcementForm.title}
                      onChange={(e) => setAnnouncementForm(prev => ({ ...prev, title: e.target.value }))}
                      className="w-full px-4 py-3 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                      placeholder="请输入公告标题" 
                      required 
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="announcement-content" className="block text-sm font-medium text-text-primary mb-2">公告内容</label>
                    <textarea 
                      id="announcement-content" 
                      rows={6}
                      value={announcementForm.content}
                      onChange={(e) => setAnnouncementForm(prev => ({ ...prev, content: e.target.value }))}
                      className="w-full px-4 py-3 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary resize-none"
                      placeholder="请输入公告内容" 
                      required
                    ></textarea>
                  </div>
                  
                  <div className="flex justify-end space-x-3 pt-4">
                    <button 
                      type="button" 
                      onClick={() => hideModal('announcement')}
                      className="px-6 py-2 border border-border-light text-text-secondary rounded-xl hover:bg-bg-secondary transition-colors"
                    >
                      取消
                    </button>
                    <button 
                      type="submit" 
                      className="px-6 py-2 bg-gradient-primary text-white rounded-xl font-medium hover:shadow-gradient transition-all"
                    >
                      发布公告
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 发布讨论模态框 */}
      {showDiscussionModal && (
        <div className="fixed inset-0 z-50">
          <div className={`${styles.modalBackdrop} absolute inset-0`} onClick={() => hideModal('discussion')}></div>
          <div className="relative flex items-center justify-center min-h-screen p-4">
            <div className="bg-white rounded-2xl shadow-gradient max-w-2xl w-full max-h-[80vh] overflow-y-auto">
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-bold text-text-primary">发布讨论</h3>
                  <button 
                    onClick={() => hideModal('discussion')}
                    className="text-text-secondary hover:text-text-primary"
                  >
                    <i className="fas fa-times text-xl"></i>
                  </button>
                </div>
                
                <form onSubmit={handleDiscussionSubmit} className="space-y-4">
                  <div>
                    <label htmlFor="discussion-title" className="block text-sm font-medium text-text-primary mb-2">讨论标题</label>
                    <input 
                      type="text" 
                      id="discussion-title" 
                      value={discussionForm.title}
                      onChange={(e) => setDiscussionForm(prev => ({ ...prev, title: e.target.value }))}
                      className="w-full px-4 py-3 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                      placeholder="请输入讨论标题" 
                      required 
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="discussion-content" className="block text-sm font-medium text-text-primary mb-2">讨论内容</label>
                    <textarea 
                      id="discussion-content" 
                      rows={8}
                      value={discussionForm.content}
                      onChange={(e) => setDiscussionForm(prev => ({ ...prev, content: e.target.value }))}
                      className="w-full px-4 py-3 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary resize-none"
                      placeholder="请输入讨论内容，可以包含代码、链接、图片等" 
                      required
                    ></textarea>
                  </div>
                  
                  <div className="flex justify-end space-x-3 pt-4">
                    <button 
                      type="button" 
                      onClick={() => hideModal('discussion')}
                      className="px-6 py-2 border border-border-light text-text-secondary rounded-xl hover:bg-bg-secondary transition-colors"
                    >
                      取消
                    </button>
                    <button 
                      type="submit" 
                      className="px-6 py-2 bg-gradient-secondary text-white rounded-xl font-medium hover:shadow-gradient transition-all"
                    >
                      发布讨论
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 上传资源模态框 */}
      {showResourceModal && (
        <div className="fixed inset-0 z-50">
          <div className={`${styles.modalBackdrop} absolute inset-0`} onClick={() => hideModal('resource')}></div>
          <div className="relative flex items-center justify-center min-h-screen p-4">
            <div className="bg-white rounded-2xl shadow-gradient max-w-2xl w-full max-h-[80vh] overflow-y-auto">
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-bold text-text-primary">上传资源</h3>
                  <button 
                    onClick={() => hideModal('resource')}
                    className="text-text-secondary hover:text-text-primary"
                  >
                    <i className="fas fa-times text-xl"></i>
                  </button>
                </div>
                
                <form onSubmit={handleResourceSubmit} className="space-y-4">
                  <div>
                    <label htmlFor="resource-title" className="block text-sm font-medium text-text-primary mb-2">资源标题</label>
                    <input 
                      type="text" 
                      id="resource-title" 
                      value={resourceForm.title}
                      onChange={(e) => setResourceForm(prev => ({ ...prev, title: e.target.value }))}
                      className="w-full px-4 py-3 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                      placeholder="请输入资源标题" 
                      required 
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="resource-description" className="block text-sm font-medium text-text-primary mb-2">资源描述</label>
                    <textarea 
                      id="resource-description" 
                      rows={3}
                      value={resourceForm.description}
                      onChange={(e) => setResourceForm(prev => ({ ...prev, description: e.target.value }))}
                      className="w-full px-4 py-3 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary resize-none"
                      placeholder="请输入资源描述"
                    ></textarea>
                  </div>
                  
                  <div>
                    <label htmlFor="resource-file" className="block text-sm font-medium text-text-primary mb-2">选择文件</label>
                    <div 
                      onClick={handleFileUploadClick}
                      className="border-2 border-dashed border-border-light rounded-xl p-8 text-center cursor-pointer"
                    >
                      <i className="fas fa-cloud-upload-alt text-4xl text-text-secondary mb-4"></i>
                      <p className="text-text-secondary mb-2">点击或拖拽文件到此处上传</p>
                      <p className="text-sm text-text-secondary">支持 PDF、ZIP、TXT、代码文件等，最大 50MB</p>
                      <input 
                        type="file" 
                        id="resource-file" 
                        onChange={handleFileSelect}
                        className="hidden" 
                        required 
                      />
                    </div>
                  </div>
                  
                  <div className="flex justify-end space-x-3 pt-4">
                    <button 
                      type="button" 
                      onClick={() => hideModal('resource')}
                      className="px-6 py-2 border border-border-light text-text-secondary rounded-xl hover:bg-bg-secondary transition-colors"
                    >
                      取消
                    </button>
                    <button 
                      type="submit" 
                      className="px-6 py-2 bg-gradient-success text-white rounded-xl font-medium hover:shadow-gradient transition-all"
                    >
                      上传资源
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default StudyGroupDetailPage;

