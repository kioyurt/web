

import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import styles from './styles.module.css';

interface StudyGroup {
  id: string;
  name: string;
  description: string;
  image: string;
  memberCount: number;
  createDate: string;
  creator: string;
  activity: 'very-active' | 'active' | 'less-active';
}

const StudyGroupListPage: React.FC = () => {
  const navigate = useNavigate();
  
  // 状态管理
  const [globalSearchKeyword, setGlobalSearchKeyword] = useState('');
  const [groupSearchKeyword, setGroupSearchKeyword] = useState('');
  const [memberFilter, setMemberFilter] = useState('');
  const [activityFilter, setActivityFilter] = useState('');
  const [sortBy, setSortBy] = useState('latest');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [joinStates, setJoinStates] = useState<Record<string, 'normal' | 'applying' | 'applied'>>({});

  // 表单状态
  const [createFormData, setCreateFormData] = useState({
    groupName: '',
    groupDescription: '',
    groupAvatar: null as File | null
  });

  // 模拟小组数据
  const [studyGroups] = useState<StudyGroup[]>([
    {
      id: 'group1',
      name: 'GPT-4V开发者交流群',
      description: '专注于GPT-4V多模态模型的技术交流和应用开发，分享最新的研究成果和实践经验。',
      image: 'https://s.coze.cn/image/M3tgDYmmu6Y/',
      memberCount: 156,
      createDate: '2024-01-10',
      creator: 'AI专家',
      activity: 'active'
    },
    {
      id: 'group2',
      name: '多模态模型训练实战',
      description: '从理论到实践，深入探讨多模态模型的训练方法、技巧和最佳实践。',
      image: 'https://s.coze.cn/image/G-QrM1-7t2A/',
      memberCount: 89,
      createDate: '2024-01-08',
      creator: '数据科学家',
      activity: 'very-active'
    },
    {
      id: 'group3',
      name: 'AI绘画技术分享',
      description: '专注于DALL-E、Midjourney等AI绘画工具的使用技巧和艺术创作分享。',
      image: 'https://s.coze.cn/image/QGoeoWAYETc/',
      memberCount: 203,
      createDate: '2024-01-05',
      creator: '艺术家小李',
      activity: 'less-active'
    },
    {
      id: 'group4',
      name: '多模态模型部署优化',
      description: '讨论生产环境下多模态模型的部署策略、性能优化和运维经验。',
      image: 'https://s.coze.cn/image/5RBr7JZCWLc/',
      memberCount: 67,
      createDate: '2024-01-03',
      creator: '运维工程师',
      activity: 'active'
    },
    {
      id: 'group5',
      name: 'CLIP模型应用研究',
      description: '深入研究CLIP模型的原理和应用，探索跨模态检索的新方法。',
      image: 'https://s.coze.cn/image/8EwiDhwjbY4/',
      memberCount: 124,
      createDate: '2024-01-01',
      creator: '研究员小王',
      activity: 'very-active'
    },
    {
      id: 'group6',
      name: '多模态AI初学者交流',
      description: '为初学者提供多模态AI技术的入门指导和学习资源分享。',
      image: 'https://s.coze.cn/image/0UhaEQHS77s/',
      memberCount: 256,
      createDate: '2023-12-28',
      creator: '学习委员',
      activity: 'less-active'
    },
    {
      id: 'group7',
      name: '多模态医疗应用讨论',
      description: '探讨多模态AI在医疗诊断、药物研发等领域的应用前景和技术挑战。',
      image: 'https://s.coze.cn/image/HdFr9xsB4ek/',
      memberCount: 78,
      createDate: '2023-12-25',
      creator: '医学博士',
      activity: 'active'
    },
    {
      id: 'group8',
      name: '多模态模型评估与评测',
      description: '研究多模态模型的评估指标、基准测试和性能分析方法。',
      image: 'https://s.coze.cn/image/WeNnz0tVuCQ/',
      memberCount: 45,
      createDate: '2023-12-20',
      creator: '评测专家',
      activity: 'less-active'
    }
  ]);

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = '学习小组 - 模学苑';
    return () => { document.title = originalTitle; };
  }, []);

  // 全局搜索处理
  const handleGlobalSearchKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      const keyword = globalSearchKeyword.trim();
      if (keyword) {
        navigate(`/search-results?q=${encodeURIComponent(keyword)}`);
      }
    }
  };

  // 小组搜索处理
  const filteredGroups = studyGroups.filter(group => {
    // 搜索关键词筛选
    if (groupSearchKeyword) {
      const keyword = groupSearchKeyword.toLowerCase();
      if (!group.name.toLowerCase().includes(keyword) && !group.description.toLowerCase().includes(keyword)) {
        return false;
      }
    }

    // 成员数筛选
    if (memberFilter) {
      switch(memberFilter) {
        case 'small':
          if (group.memberCount > 50) return false;
          break;
        case 'medium':
          if (group.memberCount <= 50 || group.memberCount > 200) return false;
          break;
        case 'large':
          if (group.memberCount <= 200) return false;
          break;
      }
    }

    // 活跃度筛选
    if (activityFilter && group.activity !== activityFilter) {
      return false;
    }

    return true;
  });

  // 排序处理
  const sortedGroups = [...filteredGroups].sort((a, b) => {
    switch(sortBy) {
      case 'latest':
        return new Date(b.createDate).getTime() - new Date(a.createDate).getTime();
      case 'members':
        return b.memberCount - a.memberCount;
      case 'popular':
        // 模拟热门度排序
        return Math.random() - 0.5;
      default:
        return 0;
    }
  });

  // 小组卡片点击处理
  const handleGroupCardClick = (groupId: string) => {
    navigate(`/study-group-detail?groupId=${groupId}`);
  };

  // 申请加入小组处理
  const handleJoinGroup = async (groupId: string) => {
    setJoinStates(prev => ({ ...prev, [groupId]: 'applying' }));
    
    // 模拟申请过程
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    setJoinStates(prev => ({ ...prev, [groupId]: 'applied' }));
  };

  // 模态框处理
  const handleOpenCreateModal = () => {
    setShowCreateModal(true);
  };

  const handleCloseCreateModal = () => {
    setShowCreateModal(false);
    setCreateFormData({
      groupName: '',
      groupDescription: '',
      groupAvatar: null
    });
  };

  // 表单提交处理
  const handleCreateFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!createFormData.groupName.trim()) {
      alert('请输入小组名称');
      return;
    }
    
    setIsSubmitting(true);
    
    // 模拟创建过程
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    alert('小组创建成功！');
    setIsSubmitting(false);
    handleCloseCreateModal();
  };

  // 表单输入处理
  const handleFormInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setCreateFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setCreateFormData(prev => ({ ...prev, groupAvatar: e.target.files?.[0] || null }));
  };

  // 获取活跃度标签样式
  const getActivityBadgeStyle = (activity: string) => {
    switch(activity) {
      case 'very-active':
        return 'bg-success';
      case 'active':
        return 'bg-primary';
      case 'less-active':
        return 'bg-warning';
      default:
        return 'bg-primary';
    }
  };

  // 获取活跃度文本
  const getActivityText = (activity: string) => {
    switch(activity) {
      case 'very-active':
        return '非常活跃';
      case 'active':
        return '活跃';
      case 'less-active':
        return '较少活跃';
      default:
        return '活跃';
    }
  };

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <header className="fixed top-0 left-0 right-0 bg-white/90 backdrop-blur-md border-b border-border-light z-50">
        <div className="flex items-center justify-between px-6 py-3">
          {/* Logo区域 */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-primary rounded-xl flex items-center justify-center">
              <i className="fas fa-graduation-cap text-white text-lg"></i>
            </div>
            <h1 className={`text-xl font-bold ${styles.gradientText}`}>模学苑</h1>
          </div>
          
          {/* 主导航 */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/home" className="text-text-secondary hover:text-primary py-1 transition-colors">首页</Link>
            <Link to="/course-list" className="text-text-secondary hover:text-primary py-1 transition-colors">课程</Link>
            <Link to="/community-overview" className="text-primary font-medium border-b-2 border-primary py-1">社区</Link>
            <Link to="/resource-center" className="text-text-secondary hover:text-primary py-1 transition-colors">资源中心</Link>
          </nav>
          
          {/* 搜索和用户区域 */}
          <div className="flex items-center space-x-4">
            {/* 全局搜索 */}
            <div className="relative hidden lg:block">
              <input 
                type="text" 
                placeholder="搜索课程、资源..." 
                value={globalSearchKeyword}
                onChange={(e) => setGlobalSearchKeyword(e.target.value)}
                onKeyPress={handleGlobalSearchKeyPress}
                className="w-80 pl-10 pr-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary"></i>
            </div>
            
            {/* 消息通知 */}
            <button className="relative p-2 text-text-secondary hover:text-primary transition-colors">
              <i className="fas fa-bell text-lg"></i>
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-danger rounded-full"></span>
            </button>
            
            {/* 用户头像 */}
            <div className="flex items-center space-x-2 cursor-pointer">
              <img 
                src="https://s.coze.cn/image/a17PpUrTSvw/" 
                alt="用户头像" 
                className="w-8 h-8 rounded-full border-2 border-primary/20"
              />
              <span className="hidden md:block text-text-primary font-medium">张同学</span>
              <i className="fas fa-chevron-down text-text-secondary text-sm"></i>
            </div>
          </div>
        </div>
      </header>

      <div className="flex pt-16">
        {/* 左侧菜单 */}
        <aside className={`fixed left-0 top-16 bottom-0 w-60 ${styles.sidebarGradient} text-white overflow-y-auto`}>
          <div className="p-4">
            <nav className="space-y-2">
              <Link to="/home" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-home text-lg"></i>
                <span>首页</span>
              </Link>
              <Link to="/course-list" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-book text-lg"></i>
                <span>课程中心</span>
              </Link>
              <Link to="/community-overview" className="flex items-center space-x-3 px-4 py-3 rounded-xl bg-white/20 backdrop-blur-sm">
                <i className="fas fa-users text-lg"></i>
                <span className="font-medium">社区互动</span>
              </Link>
              <Link to="/resource-center" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-database text-lg"></i>
                <span>资源中心</span>
              </Link>
              <Link to="/user-profile" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-user text-lg"></i>
                <span>个人中心</span>
              </Link>
            </nav>
            
            {/* 学习进度卡片 */}
            <div className="mt-8 p-4 bg-white/10 backdrop-blur-sm rounded-xl">
              <h3 className="font-semibold mb-3">今日学习</h3>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>进度</span>
                  <span>75%</span>
                </div>
                <div className="w-full bg-white/20 rounded-full h-2">
                  <div className="bg-white h-2 rounded-full" style={{width: '75%'}}></div>
                </div>
                <div className="flex justify-between text-sm">
                  <span>已学时长</span>
                  <span>2.5小时</span>
                </div>
              </div>
            </div>
          </div>
        </aside>

        {/* 主内容区域 */}
        <main className="flex-1 ml-60 min-h-screen">
          <div className="max-w-7xl mx-auto p-6">
            {/* 页面头部 */}
            <div className="mb-6">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-3xl font-bold text-white mb-2">学习小组</h1>
                  <nav className="text-white/80">
                    <Link to="/home" className="hover:text-white transition-colors">首页</Link>
                    <span className="mx-2">{'>'}</span>
                    <Link to="/community-overview" className="hover:text-white transition-colors">社区</Link>
                    <span className="mx-2">{'>'}</span>
                    <span>学习小组</span>
                  </nav>
                </div>
                <button 
                  onClick={handleOpenCreateModal}
                  className="bg-white text-primary px-6 py-3 rounded-xl font-semibold hover:bg-gray-50 transition-colors flex items-center space-x-2"
                >
                  <i className="fas fa-plus"></i>
                  <span>创建小组</span>
                </button>
              </div>
            </div>

            {/* 工具栏区域 */}
            <div className={`${styles.cardGradient} rounded-xl p-6 shadow-card mb-6`}>
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
                {/* 搜索框 */}
                <div className="flex-1 lg:max-w-md">
                  <div className="relative">
                    <input 
                      type="text" 
                      placeholder="搜索小组名称、简介..." 
                      value={groupSearchKeyword}
                      onChange={(e) => setGroupSearchKeyword(e.target.value)}
                      className="w-full pl-10 pr-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                    />
                    <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary"></i>
                  </div>
                </div>
                
                {/* 筛选和排序 */}
                <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4">
                  {/* 成员数筛选 */}
                  <select 
                    value={memberFilter}
                    onChange={(e) => setMemberFilter(e.target.value)}
                    className="px-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                  >
                    <option value="">全部成员数</option>
                    <option value="small">1-50人</option>
                    <option value="medium">51-200人</option>
                    <option value="large">200人以上</option>
                  </select>
                  
                  {/* 活跃度筛选 */}
                  <select 
                    value={activityFilter}
                    onChange={(e) => setActivityFilter(e.target.value)}
                    className="px-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                  >
                    <option value="">全部活跃度</option>
                    <option value="very-active">非常活跃</option>
                    <option value="active">活跃</option>
                    <option value="less-active">较少活跃</option>
                  </select>
                  
                  {/* 排序方式 */}
                  <select 
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value)}
                    className="px-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                  >
                    <option value="latest">最新创建</option>
                    <option value="popular">最热门</option>
                    <option value="members">成员最多</option>
                  </select>
                </div>
              </div>
            </div>

            {/* 学习小组列表 */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-8">
              {sortedGroups.map((group) => (
                <div 
                  key={group.id}
                  className={`${styles.cardGradient} rounded-xl p-6 shadow-card hover:shadow-card-hover transition-all cursor-pointer`}
                  onClick={() => handleGroupCardClick(group.id)}
                >
                  <div className="relative mb-4">
                    <img 
                      src={group.image} 
                      alt={group.name} 
                      className="w-full h-32 object-cover rounded-lg"
                    />
                    <div className={`absolute top-3 right-3 ${getActivityBadgeStyle(group.activity)} text-white px-2 py-1 rounded-lg text-sm`}>
                      {getActivityText(group.activity)}
                    </div>
                  </div>
                  <h3 className="font-semibold text-text-primary mb-2">{group.name}</h3>
                  <p className="text-text-secondary text-sm mb-3">{group.description}</p>
                  <div className="flex items-center justify-between text-sm text-text-secondary mb-3">
                    <span><i className="fas fa-users mr-1"></i>{group.memberCount}名成员</span>
                    <span><i className="fas fa-calendar mr-1"></i>{group.createDate}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-text-secondary">创建者：{group.creator}</span>
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        handleJoinGroup(group.id);
                      }}
                      disabled={joinStates[group.id] !== 'normal'}
                      className={`px-4 py-1 rounded-lg text-sm transition-colors ${
                        joinStates[group.id] === 'applied' 
                          ? 'bg-success text-white' 
                          : 'bg-primary text-white hover:bg-primary/90'
                      }`}
                    >
                      {joinStates[group.id] === 'applying' ? '申请中...' : 
                       joinStates[group.id] === 'applied' ? '已申请' : '申请加入'}
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* 分页区域 */}
            <div className="flex items-center justify-between">
              <div className="text-white/80 text-sm">
                显示 1-{sortedGroups.length} 条，共 24 条记录
              </div>
              <div className="flex items-center space-x-2">
                <button className="px-3 py-2 text-white/80 hover:text-white border border-white/20 rounded-lg hover:border-white/40 transition-colors">
                  <i className="fas fa-chevron-left"></i>
                </button>
                <button className="px-3 py-2 bg-white text-primary rounded-lg">1</button>
                <button className="px-3 py-2 text-white/80 hover:text-white border border-white/20 rounded-lg hover:border-white/40 transition-colors">2</button>
                <button className="px-3 py-2 text-white/80 hover:text-white border border-white/20 rounded-lg hover:border-white/40 transition-colors">3</button>
                <span className="px-2 text-white/50">...</span>
                <button className="px-3 py-2 text-white/80 hover:text-white border border-white/20 rounded-lg hover:border-white/40 transition-colors">
                  <i className="fas fa-chevron-right"></i>
                </button>
              </div>
            </div>
          </div>
        </main>
      </div>

      {/* 创建小组模态弹窗 */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50">
          <div className="flex items-center justify-center min-h-screen p-4">
            <div className="bg-white rounded-2xl shadow-gradient w-full max-w-md">
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-text-primary">创建学习小组</h2>
                  <button 
                    onClick={handleCloseCreateModal}
                    className="text-text-secondary hover:text-text-primary transition-colors"
                  >
                    <i className="fas fa-times text-lg"></i>
                  </button>
                </div>
                
                <form onSubmit={handleCreateFormSubmit} className="space-y-4">
                  <div>
                    <label htmlFor="group-name" className="block text-sm font-medium text-text-primary mb-2">小组名称 *</label>
                    <input 
                      type="text" 
                      id="group-name" 
                      name="groupName"
                      value={createFormData.groupName}
                      onChange={handleFormInputChange}
                      className="w-full px-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary" 
                      placeholder="请输入小组名称" 
                      required 
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="group-description" className="block text-sm font-medium text-text-primary mb-2">小组简介</label>
                    <textarea 
                      id="group-description" 
                      name="groupDescription"
                      value={createFormData.groupDescription}
                      onChange={handleFormInputChange}
                      rows={3}
                      className="w-full px-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary" 
                      placeholder="请输入小组简介"
                    ></textarea>
                  </div>
                  
                  <div>
                    <label htmlFor="group-avatar" className="block text-sm font-medium text-text-primary mb-2">小组头像</label>
                    <input 
                      type="file" 
                      id="group-avatar" 
                      name="groupAvatar"
                      onChange={handleFileChange}
                      accept="image/*"
                      className="w-full px-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                    />
                  </div>
                  
                  <div className="flex space-x-3 pt-4">
                    <button 
                      type="button" 
                      onClick={handleCloseCreateModal}
                      className="flex-1 px-4 py-2 border border-border-light text-text-secondary rounded-xl hover:bg-bg-secondary transition-colors"
                    >
                      取消
                    </button>
                    <button 
                      type="submit" 
                      disabled={isSubmitting}
                      className="flex-1 px-4 py-2 bg-gradient-primary text-white rounded-xl hover:shadow-gradient transition-all disabled:opacity-50"
                    >
                      {isSubmitting ? '创建中...' : '创建小组'}
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default StudyGroupListPage;

