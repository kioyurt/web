

import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import styles from './styles.module.css';
import { ToolData, ToolCardData } from './types';

const ToolCollectionPage: React.FC = () => {
  const navigate = useNavigate();
  
  // 状态管理
  const [globalSearchValue, setGlobalSearchValue] = useState('');
  const [toolSearchValue, setToolSearchValue] = useState('');
  const [selectedToolType, setSelectedToolType] = useState('');
  const [selectedTimeFilter, setSelectedTimeFilter] = useState('');
  const [sortBy, setSortBy] = useState('latest');
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [selectedTool, setSelectedTool] = useState<ToolData | null>(null);

  // 工具数据
  const toolsData: ToolCardData[] = [
    {
      id: 'tool1',
      title: '多模态模型开发工具包',
      type: '开发工具',
      date: '2024-01-15',
      downloads: '1.2k',
      description: '一站式多模态模型开发工具，包含数据处理、模型训练、推理优化等功能',
      icon: 'fas fa-code',
      iconBg: 'bg-gradient-primary'
    },
    {
      id: 'tool2',
      title: 'GPT-4V API文档',
      type: 'API文档',
      date: '2024-01-14',
      downloads: '3.5k',
      description: '详细的GPT-4V API使用指南，包含接口说明、参数配置、示例代码',
      icon: 'fas fa-book',
      iconBg: 'bg-gradient-secondary'
    },
    {
      id: 'tool3',
      title: 'CLIP模型SDK',
      type: 'SDK',
      date: '2024-01-13',
      downloads: '856',
      description: 'CLIP模型的官方SDK，支持多种编程语言，提供完整的模型调用接口',
      icon: 'fas fa-mobile-alt',
      iconBg: 'bg-gradient-tertiary'
    },
    {
      id: 'tool4',
      title: 'DALL-E图像生成工具',
      type: '开发工具',
      date: '2024-01-12',
      downloads: '2.1k',
      description: '基于DALL-E的图像生成工具，支持文本到图像的快速生成和编辑',
      icon: 'fas fa-palette',
      iconBg: 'bg-gradient-success'
    },
    {
      id: 'tool5',
      title: '多模态API参考手册',
      type: 'API文档',
      date: '2024-01-11',
      downloads: '1.8k',
      description: '全面的多模态模型API参考手册，包含各类模型的接口规范和使用示例',
      icon: 'fas fa-file-alt',
      iconBg: 'bg-gradient-primary'
    },
    {
      id: 'tool6',
      title: '模型部署优化SDK',
      type: 'SDK',
      date: '2024-01-10',
      downloads: '643',
      description: '专业的模型部署优化SDK，提供模型量化、推理加速等功能',
      icon: 'fas fa-laptop-code',
      iconBg: 'bg-gradient-secondary'
    },
    {
      id: 'tool7',
      title: '模型性能分析工具',
      type: '开发工具',
      date: '2024-01-09',
      downloads: '432',
      description: '多模态模型性能分析和监控工具，帮助开发者优化模型性能',
      icon: 'fas fa-chart-line',
      iconBg: 'bg-gradient-tertiary'
    },
    {
      id: 'tool8',
      title: '多模态SDK集成指南',
      type: 'API文档',
      date: '2024-01-08',
      downloads: '967',
      description: '详细的SDK集成指南，包含各种开发环境下的集成步骤和注意事项',
      icon: 'fas fa-book-open',
      iconBg: 'bg-gradient-success'
    }
  ];

  const toolDetails: Record<string, ToolData> = {
    'tool1': {
      id: 'tool1',
      title: '多模态模型开发工具包',
      type: '开发工具',
      date: '2024-01-15',
      downloads: '1.2k',
      description: '一站式多模态模型开发工具，包含数据处理、模型训练、推理优化等功能。支持多种模态数据的预处理，提供丰富的模型训练接口，以及高效的推理加速功能。',
      icon: 'fas fa-code',
      iconBg: 'bg-gradient-primary',
      features: ['数据预处理', '模型训练', '推理优化', '多模态支持'],
      downloadLink: '#',
      docsLink: '#',
      githubLink: '#'
    },
    'tool2': {
      id: 'tool2',
      title: 'GPT-4V API文档',
      type: 'API文档',
      date: '2024-01-14',
      downloads: '3.5k',
      description: '详细的GPT-4V API使用指南，包含接口说明、参数配置、示例代码。全面覆盖GPT-4V的所有功能，帮助开发者快速集成多模态能力。',
      icon: 'fas fa-book',
      iconBg: 'bg-gradient-secondary',
      features: ['接口说明', '参数配置', '示例代码', '错误处理'],
      downloadLink: '#',
      docsLink: '#',
      githubLink: '#'
    },
    'tool3': {
      id: 'tool3',
      title: 'CLIP模型SDK',
      type: 'SDK',
      date: '2024-01-13',
      downloads: '856',
      description: 'CLIP模型的官方SDK，支持多种编程语言，提供完整的模型调用接口。包含预训练模型加载、特征提取、相似度计算等功能。',
      icon: 'fas fa-mobile-alt',
      iconBg: 'bg-gradient-tertiary',
      features: ['多语言支持', '模型加载', '特征提取', '相似度计算'],
      downloadLink: '#',
      docsLink: '#',
      githubLink: '#'
    }
  };

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = '工具集 - 模学苑';
    return () => { document.title = originalTitle; };
  }, []);

  // 全局搜索处理
  const handleGlobalSearchKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      const keyword = globalSearchValue.trim();
      if (keyword) {
        navigate(`/search-results?q=${encodeURIComponent(keyword)}`);
      }
    }
  };

  // 筛选和搜索逻辑
  const filteredTools = toolsData.filter(tool => {
    // 搜索筛选
    const matchesSearch = toolSearchValue === '' || 
      tool.title.toLowerCase().includes(toolSearchValue.toLowerCase()) ||
      tool.description.toLowerCase().includes(toolSearchValue.toLowerCase());
    
    // 类型筛选
    const matchesType = selectedToolType === '' || 
      (selectedToolType === 'development' && tool.type === '开发工具') ||
      (selectedToolType === 'api' && tool.type === 'API文档') ||
      (selectedToolType === 'sdk' && tool.type === 'SDK');
    
    // 时间筛选（简化处理）
    const matchesTime = selectedTimeFilter === '';
    
    return matchesSearch && matchesType && matchesTime;
  });

  // 排序逻辑
  const sortedTools = [...filteredTools].sort((a, b) => {
    if (sortBy === 'latest') {
      return new Date(b.date).getTime() - new Date(a.date).getTime();
    } else if (sortBy === 'popular') {
      const downloadsA = parseInt(a.downloads.replace('k', '000').replace('.', ''));
      const downloadsB = parseInt(b.downloads.replace('k', '000').replace('.', ''));
      return downloadsB - downloadsA;
    }
    return 0;
  });

  // 工具卡片点击处理
  const handleToolCardClick = (toolId: string) => {
    const tool = toolDetails[toolId] || toolDetails['tool1'];
    setSelectedTool(tool);
    setIsModalVisible(true);
  };

  // 关闭模态框
  const handleCloseModal = () => {
    setIsModalVisible(false);
    setSelectedTool(null);
  };

  // 模态框背景点击处理
  const handleModalOverlayClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget) {
      handleCloseModal();
    }
  };

  // 分页处理
  const handlePrevPage = () => {
    console.log('上一页');
  };

  const handleNextPage = () => {
    console.log('下一页');
  };

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <header className="fixed top-0 left-0 right-0 bg-white/90 backdrop-blur-md border-b border-border-light z-50">
        <div className="flex items-center justify-between px-6 py-3">
          {/* Logo区域 */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-primary rounded-xl flex items-center justify-center">
              <i className="fas fa-graduation-cap text-white text-lg"></i>
            </div>
            <h1 className={`text-xl font-bold ${styles.gradientText}`}>模学苑</h1>
          </div>
          
          {/* 主导航 */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/home" className="text-text-secondary hover:text-primary py-1 transition-colors">首页</Link>
            <Link to="/course-list" className="text-text-secondary hover:text-primary py-1 transition-colors">课程</Link>
            <Link to="/community-overview" className="text-text-secondary hover:text-primary py-1 transition-colors">社区</Link>
            <Link to="/resource-center" className="text-primary font-medium border-b-2 border-primary py-1">资源中心</Link>
          </nav>
          
          {/* 搜索和用户区域 */}
          <div className="flex items-center space-x-4">
            {/* 全局搜索 */}
            <div className="relative hidden lg:block">
              <input 
                type="text" 
                placeholder="搜索课程、资源..." 
                value={globalSearchValue}
                onChange={(e) => setGlobalSearchValue(e.target.value)}
                onKeyPress={handleGlobalSearchKeyPress}
                className="w-80 pl-10 pr-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary"></i>
            </div>
            
            {/* 消息通知 */}
            <button className="relative p-2 text-text-secondary hover:text-primary transition-colors">
              <i className="fas fa-bell text-lg"></i>
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-danger rounded-full"></span>
            </button>
            
            {/* 用户头像 */}
            <div className="flex items-center space-x-2 cursor-pointer">
              <img 
                src="https://s.coze.cn/image/VaJ8a8S1xBQ/" 
                alt="用户头像" 
                className="w-8 h-8 rounded-full border-2 border-primary/20"
              />
              <span className="hidden md:block text-text-primary font-medium">张同学</span>
              <i className="fas fa-chevron-down text-text-secondary text-sm"></i>
            </div>
          </div>
        </div>
      </header>

      <div className="flex pt-16">
        {/* 左侧菜单 */}
        <aside className={`fixed left-0 top-16 bottom-0 w-60 ${styles.sidebarGradient} text-white overflow-y-auto`}>
          <div className="p-4">
            <nav className="space-y-2">
              <Link to="/home" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-home text-lg"></i>
                <span>首页</span>
              </Link>
              <Link to="/course-list" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-book text-lg"></i>
                <span>课程中心</span>
              </Link>
              <Link to="/community-overview" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-users text-lg"></i>
                <span>社区互动</span>
              </Link>
              <Link to="/resource-center" className="flex items-center space-x-3 px-4 py-3 rounded-xl bg-white/20 backdrop-blur-sm">
                <i className="fas fa-database text-lg"></i>
                <span className="font-medium">资源中心</span>
              </Link>
              <Link to="/user-profile" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-user text-lg"></i>
                <span>个人中心</span>
              </Link>
            </nav>
            
            {/* 资源中心子菜单 */}
            <div className="mt-4 space-y-1">
              <Link to="/model-library" className="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-white/10 transition-colors text-sm">
                <i className="fas fa-brain text-sm"></i>
                <span>模型库</span>
              </Link>
              <Link to="/tool-collection" className="flex items-center space-x-3 px-4 py-2 rounded-lg bg-white/20 backdrop-blur-sm text-sm">
                <i className="fas fa-tools text-sm"></i>
                <span className="font-medium">工具集</span>
              </Link>
              <Link to="/industry-news" className="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-white/10 transition-colors text-sm">
                <i className="fas fa-newspaper text-sm"></i>
                <span>行业资讯</span>
              </Link>
              <Link to="/resource-download" className="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-white/10 transition-colors text-sm">
                <i className="fas fa-download text-sm"></i>
                <span>资源下载</span>
              </Link>
            </div>
          </div>
        </aside>

        {/* 主内容区域 */}
        <main className="flex-1 ml-60 min-h-screen">
          <div className="max-w-7xl mx-auto p-6">
            {/* 页面头部 */}
            <div className="mb-6">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-3xl font-bold text-white mb-2">工具集</h1>
                  <nav className="text-white/80">
                    <Link to="/home" className="hover:text-white transition-colors">首页</Link>
                    <span className="mx-2">{'>'}</span>
                    <Link to="/resource-center" className="hover:text-white transition-colors">资源中心</Link>
                    <span className="mx-2">{'>'}</span>
                    <span>工具集</span>
                  </nav>
                </div>
              </div>
            </div>

            {/* 工具栏区域 */}
            <div className={`${styles.cardGradient} rounded-xl p-6 shadow-card mb-6`}>
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
                {/* 搜索和筛选 */}
                <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 flex-1">
                  {/* 搜索框 */}
                  <div className="relative flex-1 sm:max-w-md">
                    <input 
                      type="text" 
                      placeholder="搜索工具名称、关键词..." 
                      value={toolSearchValue}
                      onChange={(e) => setToolSearchValue(e.target.value)}
                      className="w-full pl-10 pr-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                    />
                    <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary"></i>
                  </div>
                  
                  {/* 工具类型筛选 */}
                  <select 
                    value={selectedToolType}
                    onChange={(e) => setSelectedToolType(e.target.value)}
                    className="px-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                  >
                    <option value="">全部类型</option>
                    <option value="development">开发工具</option>
                    <option value="api">API文档</option>
                    <option value="sdk">SDK</option>
                  </select>
                  
                  {/* 发布时间筛选 */}
                  <select 
                    value={selectedTimeFilter}
                    onChange={(e) => setSelectedTimeFilter(e.target.value)}
                    className="px-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                  >
                    <option value="">全部时间</option>
                    <option value="today">今天</option>
                    <option value="week">本周</option>
                    <option value="month">本月</option>
                    <option value="quarter">本季度</option>
                  </select>
                </div>
                
                {/* 排序 */}
                <div className="flex items-center space-x-4">
                  <select 
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value)}
                    className="px-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                  >
                    <option value="latest">最新</option>
                    <option value="popular">最热</option>
                  </select>
                </div>
              </div>
            </div>

            {/* 工具列表 */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-8">
              {sortedTools.map((tool) => (
                <div 
                  key={tool.id}
                  className={`${styles.cardGradient} rounded-xl p-6 shadow-card hover:shadow-card-hover transition-all cursor-pointer`}
                  onClick={() => handleToolCardClick(tool.id)}
                >
                  <div className="flex items-center mb-4">
                    <div className={`w-12 h-12 ${tool.iconBg} rounded-xl flex items-center justify-center mr-4`}>
                      <i className={`${tool.icon} text-white text-lg`}></i>
                    </div>
                    <div>
                      <h3 className="font-semibold text-text-primary">{tool.title}</h3>
                      <span className={`inline-block px-2 py-1 ${
                        tool.type === '开发工具' ? 'bg-primary/10 text-primary' :
                        tool.type === 'API文档' ? 'bg-secondary/10 text-secondary' :
                        'bg-tertiary/10 text-tertiary'
                      } text-xs rounded-lg mt-1`}>
                        {tool.type}
                      </span>
                    </div>
                  </div>
                  <p className="text-text-secondary text-sm mb-4">{tool.description}</p>
                  <div className="flex items-center justify-between text-sm text-text-secondary">
                    <span><i className="fas fa-calendar mr-1"></i>{tool.date}</span>
                    <span>
                      <i className={`fas ${tool.type === 'API文档' ? 'fa-eye' : 'fa-download'} mr-1`}></i>
                      {tool.downloads}
                    </span>
                  </div>
                </div>
              ))}
            </div>

            {/* 分页区域 */}
            <div className={`flex items-center justify-between ${styles.cardGradient} rounded-xl p-4 shadow-card`}>
              <div className="text-white/80 text-sm">
                显示 1-8 条，共 45 条记录
              </div>
              <div className="flex items-center space-x-2">
                <button 
                  onClick={handlePrevPage}
                  className="px-3 py-2 text-sm border border-border-light rounded-lg hover:bg-bg-secondary transition-colors"
                >
                  <i className="fas fa-chevron-left"></i>
                </button>
                <button className="px-3 py-2 text-sm bg-primary text-white rounded-lg">1</button>
                <button className="px-3 py-2 text-sm border border-border-light rounded-lg hover:bg-bg-secondary transition-colors">2</button>
                <button className="px-3 py-2 text-sm border border-border-light rounded-lg hover:bg-bg-secondary transition-colors">3</button>
                <span className="px-2 text-text-secondary">...</span>
                <button className="px-3 py-2 text-sm border border-border-light rounded-lg hover:bg-bg-secondary transition-colors">6</button>
                <button 
                  onClick={handleNextPage}
                  className="px-3 py-2 text-sm border border-border-light rounded-lg hover:bg-bg-secondary transition-colors"
                >
                  <i className="fas fa-chevron-right"></i>
                </button>
              </div>
            </div>
          </div>
        </main>
      </div>

      {/* 工具详情模态框 */}
      {isModalVisible && selectedTool && (
        <div className="fixed inset-0 z-50">
          <div className={`${styles.toolDetailOverlay} absolute inset-0`} onClick={handleModalOverlayClick}></div>
          <div className="relative flex items-center justify-center min-h-screen p-4">
            <div className={`${styles.toolDetailContent} bg-white rounded-2xl shadow-gradient max-w-4xl w-full`}>
              <div className="p-6">
                {/* 模态框头部 */}
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-bold text-text-primary">工具详情</h2>
                  <button 
                    onClick={handleCloseModal}
                    className="p-2 text-text-secondary hover:text-text-primary transition-colors"
                  >
                    <i className="fas fa-times text-xl"></i>
                  </button>
                </div>
                
                {/* 工具详情内容 */}
                <div className="space-y-6">
                  {/* 工具基本信息 */}
                  <div className="flex items-start space-x-6">
                    <div className={`w-16 h-16 ${selectedTool.iconBg} rounded-xl flex items-center justify-center flex-shrink-0`}>
                      <i className={`${selectedTool.icon} text-white text-2xl`}></i>
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-semibold text-text-primary mb-2">{selectedTool.title}</h3>
                      <div className="flex items-center space-x-4 mb-2">
                        <span className={`px-3 py-1 ${
                          selectedTool.type === '开发工具' ? 'bg-primary/10 text-primary' :
                          selectedTool.type === 'API文档' ? 'bg-secondary/10 text-secondary' :
                          'bg-tertiary/10 text-tertiary'
                        } text-sm rounded-lg`}>
                          {selectedTool.type}
                        </span>
                        <span className="text-text-secondary text-sm">
                          <i className="fas fa-calendar mr-1"></i>
                          {selectedTool.date}
                        </span>
                        <span className="text-text-secondary text-sm">
                          <i className={`fas ${selectedTool.type === 'API文档' ? 'fa-eye' : 'fa-download'} mr-1`}></i>
                          {selectedTool.downloads}
                        </span>
                      </div>
                      <p className="text-text-secondary">{selectedTool.description}</p>
                    </div>
                  </div>
                  
                  {/* 工具功能特性 */}
                  <div>
                    <h4 className="text-lg font-semibold text-text-primary mb-3">功能特性</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {selectedTool.features.map((feature, index) => (
                        <div key={index} className="flex items-center space-x-2 p-3 bg-bg-secondary rounded-lg">
                          <i className="fas fa-check-circle text-success"></i>
                          <span className="text-text-primary">{feature}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  {/* 下载和文档链接 */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <h4 className="text-lg font-semibold text-text-primary mb-3">下载链接</h4>
                      <div className="space-y-2">
                        <a 
                          href={selectedTool.downloadLink} 
                          className="flex items-center space-x-3 p-3 bg-gradient-primary text-white rounded-lg hover:shadow-card transition-all"
                        >
                          <i className="fas fa-download"></i>
                          <span>下载工具</span>
                          <span className="ml-auto text-sm opacity-90">v1.0.0</span>
                        </a>
                      </div>
                    </div>
                    <div>
                      <h4 className="text-lg font-semibold text-text-primary mb-3">文档资源</h4>
                      <div className="space-y-2">
                        <a 
                          href={selectedTool.docsLink} 
                          className="flex items-center space-x-3 p-3 bg-gradient-secondary text-white rounded-lg hover:shadow-card transition-all"
                        >
                          <i className="fas fa-book"></i>
                          <span>查看文档</span>
                        </a>
                        <a 
                          href={selectedTool.githubLink} 
                          className="flex items-center space-x-3 p-3 bg-gray-800 text-white rounded-lg hover:shadow-card transition-all"
                        >
                          <i className="fab fa-github"></i>
                          <span>GitHub</span>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ToolCollectionPage;

