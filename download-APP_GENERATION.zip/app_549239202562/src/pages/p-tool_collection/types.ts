

export interface ToolData {
  id: string;
  title: string;
  type: string;
  date: string;
  downloads: string;
  description: string;
  icon: string;
  iconBg: string;
  features: string[];
  downloadLink: string;
  docsLink: string;
  githubLink: string;
}

export interface ToolCardData {
  id: string;
  title: string;
  type: string;
  date: string;
  downloads: string;
  description: string;
  icon: string;
  iconBg: string;
}

