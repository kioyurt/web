

import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import styles from './styles.module.css';

interface CourseData {
  id: string;
  name: string;
  instructor: string;
  difficulty: '入门' | '中级' | '高级' | '实战';
  progress: number;
  lastStudy: string;
  isCompleted: boolean;
}

interface FavoriteCourseData {
  id: string;
  name: string;
  instructor: string;
  difficulty: '入门' | '中级' | '高级' | '实战';
  favoriteTime: string;
}

interface CertificateData {
  id: string;
  name: string;
  date: string;
}

const UserProfilePage: React.FC = () => {
  const navigate = useNavigate();
  const [activeMainTab, setActiveMainTab] = useState<'learning-records' | 'certificates' | 'account-security'>('learning-records');
  const [activeSubTab, setActiveSubTab] = useState<'learned-courses' | 'favorite-courses' | 'learning-report'>('learned-courses');
  const [globalSearchValue, setGlobalSearchValue] = useState('');

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = '个人中心 - 模学苑';
    return () => { document.title = originalTitle; };
  }, []);

  // 学习记录数据
  const learnedCoursesData: CourseData[] = [
    {
      id: '1',
      name: 'GPT-4V多模态入门实战',
      instructor: '李教授',
      difficulty: '入门',
      progress: 100,
      lastStudy: '2024-01-20',
      isCompleted: true
    },
    {
      id: '2',
      name: 'CLIP模型训练与应用',
      instructor: '王博士',
      difficulty: '中级',
      progress: 75,
      lastStudy: '2024-01-19',
      isCompleted: false
    },
    {
      id: '3',
      name: 'DALL-E图像生成技术',
      instructor: '张老师',
      difficulty: '高级',
      progress: 45,
      lastStudy: '2024-01-18',
      isCompleted: false
    }
  ];

  // 收藏课程数据
  const favoriteCoursesData: FavoriteCourseData[] = [
    {
      id: '4',
      name: '多模态模型部署优化',
      instructor: '刘工程师',
      difficulty: '实战',
      favoriteTime: '2024-01-15'
    },
    {
      id: '5',
      name: 'Transformer架构详解',
      instructor: '陈教授',
      difficulty: '中级',
      favoriteTime: '2024-01-12'
    }
  ];

  // 证书数据
  const certificatesData: CertificateData[] = [
    {
      id: '1',
      name: 'GPT-4V多模态入门实战',
      date: '2024-01-15'
    },
    {
      id: '2',
      name: 'Python数据分析基础',
      date: '2024-01-10'
    },
    {
      id: '3',
      name: '机器学习基础',
      date: '2024-01-05'
    }
  ];

  // 处理全局搜索
  const handleGlobalSearchKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      const keyword = globalSearchValue.trim();
      if (keyword) {
        navigate(`/search-results?q=${encodeURIComponent(keyword)}`);
      }
    }
  };

  // 处理继续学习
  const handleContinueLearning = (courseId: string) => {
    navigate(`/course-learn?courseId=${courseId}`);
  };

  // 处理查看详情
  const handleViewCourseDetail = (courseId: string) => {
    navigate(`/course-detail?id=${courseId}`);
  };

  // 处理取消收藏
  const handleUnfavoriteCourse = (courseId: string) => {
    if (confirm('确定要取消收藏这门课程吗？')) {
      console.log('取消收藏成功');
      // 这里应该调用API来取消收藏
    }
  };

  // 处理查看证书
  const handleViewCertificate = (certificateId: string) => {
    console.log('查看证书功能需要实现');
    alert('证书查看功能正在开发中');
  };

  // 处理下载证书
  const handleDownloadCertificate = (certificateId: string) => {
    console.log('下载证书PDF功能需要实现');
    alert('证书下载功能正在开发中');
  };

  // 处理修改密码表单提交
  const handleChangePasswordSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.target as HTMLFormElement);
    const currentPassword = formData.get('current-password') as string;
    const newPassword = formData.get('new-password') as string;
    const confirmPassword = formData.get('confirm-password') as string;
    
    if (!currentPassword || !newPassword || !confirmPassword) {
      alert('请填写完整的密码信息');
      return;
    }
    
    if (newPassword !== confirmPassword) {
      alert('新密码和确认密码不一致');
      return;
    }
    
    if (newPassword.length < 6) {
      alert('新密码长度不能少于6位');
      return;
    }
    
    console.log('密码修改成功');
    alert('密码修改成功');
    (e.target as HTMLFormElement).reset();
  };

  // 处理账号解绑
  const handleUnbindAccount = () => {
    if (confirm('确定要解绑这个账号吗？')) {
      console.log('解绑账号成功');
      alert('解绑成功');
    }
  };

  // 处理账号更换
  const handleChangeAccount = () => {
    console.log('更换账号功能需要实现');
    alert('更换功能正在开发中');
  };

  // 处理编辑头像
  const handleEditAvatar = () => {
    console.log('编辑头像功能需要实现');
    alert('头像上传功能正在开发中');
  };

  // 处理编辑资料
  const handleEditProfile = () => {
    console.log('编辑资料功能需要实现');
    alert('个人资料编辑功能正在开发中');
  };

  // 获取难度标签样式
  const getDifficultyBadgeStyle = (difficulty: string) => {
    switch (difficulty) {
      case '入门':
        return 'px-2 py-1 text-xs font-medium bg-primary/10 text-primary rounded-full';
      case '中级':
        return 'px-2 py-1 text-xs font-medium bg-secondary/10 text-secondary rounded-full';
      case '高级':
        return 'px-2 py-1 text-xs font-medium bg-tertiary/10 text-tertiary rounded-full';
      case '实战':
        return 'px-2 py-1 text-xs font-medium bg-success/10 text-success rounded-full';
      default:
        return 'px-2 py-1 text-xs font-medium bg-gray-100 text-gray-600 rounded-full';
    }
  };

  return (
    <div className={styles.pageWrapper}>
      {/* 顶部导航栏 */}
      <header className="fixed top-0 left-0 right-0 bg-white/90 backdrop-blur-md border-b border-border-light z-50">
        <div className="flex items-center justify-between px-6 py-3">
          {/* Logo区域 */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-primary rounded-xl flex items-center justify-center">
              <i className="fas fa-graduation-cap text-white text-lg"></i>
            </div>
            <h1 className={`text-xl font-bold ${styles.gradientText}`}>模学苑</h1>
          </div>
          
          {/* 主导航 */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/home" className="text-text-secondary hover:text-primary py-1 transition-colors">首页</Link>
            <Link to="/course-list" className="text-text-secondary hover:text-primary py-1 transition-colors">课程</Link>
            <Link to="/community-overview" className="text-text-secondary hover:text-primary py-1 transition-colors">社区</Link>
            <Link to="/resource-center" className="text-text-secondary hover:text-primary py-1 transition-colors">资源中心</Link>
          </nav>
          
          {/* 搜索和用户区域 */}
          <div className="flex items-center space-x-4">
            {/* 全局搜索 */}
            <div className="relative hidden lg:block">
              <input 
                type="text" 
                placeholder="搜索课程、资源..." 
                value={globalSearchValue}
                onChange={(e) => setGlobalSearchValue(e.target.value)}
                onKeyPress={handleGlobalSearchKeyPress}
                className="w-80 pl-10 pr-4 py-2 border border-border-light rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary"></i>
            </div>
            
            {/* 消息通知 */}
            <button className="relative p-2 text-text-secondary hover:text-primary transition-colors">
              <i className="fas fa-bell text-lg"></i>
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-danger rounded-full"></span>
            </button>
            
            {/* 用户头像 */}
            <div className="flex items-center space-x-2 cursor-pointer">
              <img 
                src="https://s.coze.cn/image/EYYnEu7rETE/" 
                alt="用户头像" 
                className="w-8 h-8 rounded-full border-2 border-primary/20"
              />
              <span className="hidden md:block text-text-primary font-medium">张同学</span>
              <i className="fas fa-chevron-down text-text-secondary text-sm"></i>
            </div>
          </div>
        </div>
      </header>

      <div className="flex pt-16">
        {/* 左侧菜单 */}
        <aside className={`fixed left-0 top-16 bottom-0 w-60 ${styles.sidebarGradient} text-white overflow-y-auto`}>
          <div className="p-4">
            <nav className="space-y-2">
              <Link to="/home" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-home text-lg"></i>
                <span>首页</span>
              </Link>
              <Link to="/course-list" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-book text-lg"></i>
                <span>课程中心</span>
              </Link>
              <Link to="/community-overview" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-users text-lg"></i>
                <span>社区互动</span>
              </Link>
              <Link to="/resource-center" className="flex items-center space-x-3 px-4 py-3 rounded-xl hover:bg-white/10 transition-colors">
                <i className="fas fa-database text-lg"></i>
                <span>资源中心</span>
              </Link>
              <div className="flex items-center space-x-3 px-4 py-3 rounded-xl bg-white/20 backdrop-blur-sm">
                <i className="fas fa-user text-lg"></i>
                <span className="font-medium">个人中心</span>
              </div>
            </nav>
            
            {/* 学习进度卡片 */}
            <div className="mt-8 p-4 bg-white/10 backdrop-blur-sm rounded-xl">
              <h3 className="font-semibold mb-3">今日学习</h3>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>进度</span>
                  <span>75%</span>
                </div>
                <div className="w-full bg-white/20 rounded-full h-2">
                  <div className="bg-white h-2 rounded-full" style={{width: '75%'}}></div>
                </div>
                <div className="flex justify-between text-sm">
                  <span>已学时长</span>
                  <span>2.5小时</span>
                </div>
              </div>
            </div>
          </div>
        </aside>

        {/* 主内容区域 */}
        <main className="flex-1 ml-60 min-h-screen">
          <div className="max-w-7xl mx-auto p-6">
            {/* 页面头部 */}
            <div className="mb-6">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-3xl font-bold text-white mb-2">个人中心</h1>
                  <nav className="text-white/80">
                    <span>首页</span>
                    <i className="fas fa-chevron-right mx-2"></i>
                    <span className="text-white">个人中心</span>
                  </nav>
                </div>
              </div>
            </div>

            {/* 个人资料区 */}
            <section className="mb-8">
              <div className={`${styles.cardGradient} rounded-2xl p-8 shadow-card`}>
                <div className="flex items-start space-x-8">
                  {/* 头像区域 */}
                  <div className="flex-shrink-0">
                    <div className="relative">
                      <img 
                        src="https://s.coze.cn/image/0weGAcfe7aQ/" 
                        alt="用户头像" 
                        className="w-24 h-24 rounded-full border-4 border-primary/20"
                      />
                      <button 
                        onClick={handleEditAvatar}
                        className="absolute -bottom-1 -right-1 w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center hover:bg-primary/90 transition-colors"
                      >
                        <i className="fas fa-camera text-sm"></i>
                      </button>
                    </div>
                  </div>
                  
                  {/* 基本信息 */}
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-4">
                      <h2 className="text-2xl font-bold text-text-primary">张同学</h2>
                      <button 
                        onClick={handleEditProfile}
                        className="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors"
                      >
                        <i className="fas fa-edit mr-2"></i>编辑资料
                      </button>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-3">
                        <div className="flex items-center space-x-3">
                          <i className="fas fa-envelope text-text-secondary w-5"></i>
                          <span className="text-text-primary">zhangstudent@example.com</span>
                        </div>
                        <div className="flex items-center space-x-3">
                          <i className="fas fa-phone text-text-secondary w-5"></i>
                          <span className="text-text-primary">138****5678</span>
                        </div>
                        <div className="flex items-center space-x-3">
                          <i className="fas fa-venus text-text-secondary w-5"></i>
                          <span className="text-text-primary">女</span>
                        </div>
                      </div>
                      
                      <div className="space-y-3">
                        <div className="flex items-center space-x-3">
                          <i className="fas fa-calendar text-text-secondary w-5"></i>
                          <span className="text-text-primary">注册时间：2024-01-15</span>
                        </div>
                        <div className="flex items-center space-x-3">
                          <i className="fas fa-map-marker-alt text-text-secondary w-5"></i>
                          <span className="text-text-primary">北京</span>
                        </div>
                        <div className="flex items-center space-x-3">
                          <i className="fas fa-briefcase text-text-secondary w-5"></i>
                          <span className="text-text-primary">AI算法工程师</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="mt-6">
                      <h3 className="font-semibold text-text-primary mb-2">个人简介</h3>
                      <p className="text-text-secondary">
                        热爱AI技术的学习者，专注于多模态大模型的研究与应用。希望通过模学苑平台与更多志同道合的朋友交流学习。
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* 学习数据概览区 */}
            <section className="mb-8">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div className={`${styles.cardGradient} rounded-xl p-6 shadow-card text-center`}>
                  <div className={`text-3xl font-bold ${styles.gradientText} mb-2`}>12</div>
                  <div className="text-text-secondary">已完成课程</div>
                </div>
                <div className={`${styles.cardGradient} rounded-xl p-6 shadow-card text-center`}>
                  <div className={`text-3xl font-bold ${styles.gradientText} mb-2`}>86</div>
                  <div className="text-text-secondary">累计学习时长(h)</div>
                </div>
                <div className={`${styles.cardGradient} rounded-xl p-6 shadow-card text-center`}>
                  <div className={`text-3xl font-bold ${styles.gradientText} mb-2`}>5</div>
                  <div className="text-text-secondary">获得证书</div>
                </div>
                <div className={`${styles.cardGradient} rounded-xl p-6 shadow-card text-center`}>
                  <div className={`text-3xl font-bold ${styles.gradientText} mb-2`}>4.8</div>
                  <div className="text-text-secondary">平均评分</div>
                </div>
              </div>
            </section>

            {/* Tab切换区域 */}
            <section className="mb-8">
              {/* Tab切换按钮 */}
              <div className="flex space-x-4 mb-6" role="tablist">
                <button 
                  onClick={() => setActiveMainTab('learning-records')}
                  className={`px-6 py-3 text-sm font-medium rounded-lg focus:outline-none ${
                    activeMainTab === 'learning-records' ? styles.tabActive : styles.tabInactive
                  }`}
                  role="tab"
                >
                  学习记录
                </button>
                <button 
                  onClick={() => setActiveMainTab('certificates')}
                  className={`px-6 py-3 text-sm font-medium rounded-lg focus:outline-none ${
                    activeMainTab === 'certificates' ? styles.tabActive : styles.tabInactive
                  }`}
                  role="tab"
                >
                  证书管理
                </button>
                <button 
                  onClick={() => setActiveMainTab('account-security')}
                  className={`px-6 py-3 text-sm font-medium rounded-lg focus:outline-none ${
                    activeMainTab === 'account-security' ? styles.tabActive : styles.tabInactive
                  }`}
                  role="tab"
                >
                  账号安全
                </button>
              </div>

              {/* 学习记录Tab内容 */}
              {activeMainTab === 'learning-records' && (
                <div>
                  {/* 学习记录子Tab */}
                  <div className="mb-6">
                    <div className="flex space-x-4" role="tablist">
                      <button 
                        onClick={() => setActiveSubTab('learned-courses')}
                        className={`px-4 py-2 text-sm font-medium rounded-lg focus:outline-none ${
                          activeSubTab === 'learned-courses' ? styles.tabActive : styles.tabInactive
                        }`}
                        role="tab"
                      >
                        已学课程
                      </button>
                      <button 
                        onClick={() => setActiveSubTab('favorite-courses')}
                        className={`px-4 py-2 text-sm font-medium rounded-lg focus:outline-none ${
                          activeSubTab === 'favorite-courses' ? styles.tabActive : styles.tabInactive
                        }`}
                        role="tab"
                      >
                        收藏课程
                      </button>
                      <button 
                        onClick={() => setActiveSubTab('learning-report')}
                        className={`px-4 py-2 text-sm font-medium rounded-lg focus:outline-none ${
                          activeSubTab === 'learning-report' ? styles.tabActive : styles.tabInactive
                        }`}
                        role="tab"
                      >
                        学习报告
                      </button>
                    </div>
                  </div>

                  {/* 已学课程内容 */}
                  {activeSubTab === 'learned-courses' && (
                    <div className={`${styles.cardGradient} rounded-xl shadow-card overflow-hidden`}>
                      <div className="overflow-x-auto">
                        <table className="w-full">
                          <thead className="bg-bg-secondary">
                            <tr>
                              <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">课程名称</th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">讲师</th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">难度</th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">学习进度</th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">上次学习</th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">操作</th>
                            </tr>
                          </thead>
                          <tbody className="bg-white divide-y divide-border-light">
                            {learnedCoursesData.map((course) => (
                              <tr key={course.id}>
                                <td className="px-6 py-4 whitespace-nowrap">
                                  <Link 
                                    to={`/course-detail?id=${course.id}`} 
                                    className="text-primary hover:text-primary/80 font-medium"
                                  >
                                    {course.name}
                                  </Link>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-text-primary">{course.instructor}</td>
                                <td className="px-6 py-4 whitespace-nowrap">
                                  <span className={getDifficultyBadgeStyle(course.difficulty)}>{course.difficulty}</span>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap">
                                  <div className="flex items-center space-x-2">
                                    <div className="w-20 bg-bg-secondary rounded-full h-2">
                                      <div 
                                        className={`${styles.progressBar} h-2 rounded-full`} 
                                        style={{width: `${course.progress}%`}}
                                      ></div>
                                    </div>
                                    <span className="text-sm text-text-secondary">{course.progress}%</span>
                                  </div>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary">{course.lastStudy}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                  {!course.isCompleted && (
                                    <button 
                                      onClick={() => handleContinueLearning(course.id)}
                                      className="text-primary hover:text-primary/80 mr-3"
                                    >
                                      继续学习
                                    </button>
                                  )}
                                  <button 
                                    onClick={() => handleViewCourseDetail(course.id)}
                                    className={`${course.isCompleted ? 'text-primary hover:text-primary/80' : 'text-text-secondary hover:text-text-primary'}`}
                                  >
                                    查看详情
                                  </button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}

                  {/* 收藏课程内容 */}
                  {activeSubTab === 'favorite-courses' && (
                    <div className={`${styles.cardGradient} rounded-xl shadow-card overflow-hidden`}>
                      <div className="overflow-x-auto">
                        <table className="w-full">
                          <thead className="bg-bg-secondary">
                            <tr>
                              <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">课程名称</th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">讲师</th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">难度</th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">收藏时间</th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">操作</th>
                            </tr>
                          </thead>
                          <tbody className="bg-white divide-y divide-border-light">
                            {favoriteCoursesData.map((course) => (
                              <tr key={course.id}>
                                <td className="px-6 py-4 whitespace-nowrap">
                                  <Link 
                                    to={`/course-detail?id=${course.id}`} 
                                    className="text-primary hover:text-primary/80 font-medium"
                                  >
                                    {course.name}
                                  </Link>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-text-primary">{course.instructor}</td>
                                <td className="px-6 py-4 whitespace-nowrap">
                                  <span className={getDifficultyBadgeStyle(course.difficulty)}>{course.difficulty}</span>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary">{course.favoriteTime}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                  <button 
                                    onClick={() => handleViewCourseDetail(course.id)}
                                    className="text-primary hover:text-primary/80 mr-3"
                                  >
                                    查看详情
                                  </button>
                                  <button 
                                    onClick={() => handleUnfavoriteCourse(course.id)}
                                    className="text-danger hover:text-danger/80"
                                  >
                                    取消收藏
                                  </button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}

                  {/* 学习报告内容 */}
                  {activeSubTab === 'learning-report' && (
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                      <div className={`${styles.cardGradient} rounded-xl p-6 shadow-card`}>
                        <h3 className="font-semibold text-text-primary mb-4">月度学习趋势</h3>
                        <div className="space-y-4">
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-text-secondary">1月</span>
                            <div className="flex items-center space-x-2">
                              <div className="w-32 bg-bg-secondary rounded-full h-2">
                                <div className={`${styles.progressBar} h-2 rounded-full`} style={{width: '85%'}}></div>
                              </div>
                              <span className="text-sm font-medium text-text-primary">85%</span>
                            </div>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-text-secondary">12月</span>
                            <div className="flex items-center space-x-2">
                              <div className="w-32 bg-bg-secondary rounded-full h-2">
                                <div className={`${styles.progressBar} h-2 rounded-full`} style={{width: '72%'}}></div>
                              </div>
                              <span className="text-sm font-medium text-text-primary">72%</span>
                            </div>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-text-secondary">11月</span>
                            <div className="flex items-center space-x-2">
                              <div className="w-32 bg-bg-secondary rounded-full h-2">
                                <div className={`${styles.progressBar} h-2 rounded-full`} style={{width: '60%'}}></div>
                              </div>
                              <span className="text-sm font-medium text-text-primary">60%</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div className={`${styles.cardGradient} rounded-xl p-6 shadow-card`}>
                        <h3 className="font-semibold text-text-primary mb-4">技能掌握度</h3>
                        <div className="space-y-4">
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-text-secondary">多模态基础</span>
                            <div className="flex items-center space-x-2">
                              <div className="w-32 bg-bg-secondary rounded-full h-2">
                                <div className={`${styles.progressBar} h-2 rounded-full`} style={{width: '90%'}}></div>
                              </div>
                              <span className="text-sm font-medium text-text-primary">90%</span>
                            </div>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-text-secondary">模型训练</span>
                            <div className="flex items-center space-x-2">
                              <div className="w-32 bg-bg-secondary rounded-full h-2">
                                <div className={`${styles.progressBar} h-2 rounded-full`} style={{width: '75%'}}></div>
                              </div>
                              <span className="text-sm font-medium text-text-primary">75%</span>
                            </div>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-text-secondary">模型部署</span>
                            <div className="flex items-center space-x-2">
                              <div className="w-32 bg-bg-secondary rounded-full h-2">
                                <div className={`${styles.progressBar} h-2 rounded-full`} style={{width: '65%'}}></div>
                              </div>
                              <span className="text-sm font-medium text-text-primary">65%</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* 证书管理Tab内容 */}
              {activeMainTab === 'certificates' && (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {certificatesData.map((certificate) => (
                    <div key={certificate.id} className={`${styles.cardGradient} rounded-xl p-6 shadow-card`}>
                      <div className="text-center mb-4">
                        <i className="fas fa-certificate text-4xl text-warning mb-2"></i>
                        <h3 className="font-semibold text-text-primary">{certificate.name}</h3>
                        <p className="text-sm text-text-secondary mt-1">{certificate.date}</p>
                      </div>
                      <div className="space-y-2">
                        <button 
                          onClick={() => handleViewCertificate(certificate.id)}
                          className="w-full px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors text-sm"
                        >
                          <i className="fas fa-eye mr-2"></i>查看证书
                        </button>
                        <button 
                          onClick={() => handleDownloadCertificate(certificate.id)}
                          className="w-full px-4 py-2 bg-bg-secondary text-text-primary rounded-lg hover:bg-border-light transition-colors text-sm"
                        >
                          <i className="fas fa-download mr-2"></i>下载PDF
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* 账号安全Tab内容 */}
              {activeMainTab === 'account-security' && (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* 密码修改 */}
                  <div className={`${styles.cardGradient} rounded-xl p-6 shadow-card`}>
                    <h3 className="font-semibold text-text-primary mb-4">修改密码</h3>
                    <form onSubmit={handleChangePasswordSubmit} className="space-y-4">
                      <div>
                        <label htmlFor="current-password" className="block text-sm font-medium text-text-primary mb-2">当前密码</label>
                        <input 
                          type="password" 
                          id="current-password" 
                          name="current-password" 
                          className="w-full px-4 py-2 border border-border-light rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                        />
                      </div>
                      <div>
                        <label htmlFor="new-password" className="block text-sm font-medium text-text-primary mb-2">新密码</label>
                        <input 
                          type="password" 
                          id="new-password" 
                          name="new-password" 
                          className="w-full px-4 py-2 border border-border-light rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                        />
                      </div>
                      <div>
                        <label htmlFor="confirm-password" className="block text-sm font-medium text-text-primary mb-2">确认新密码</label>
                        <input 
                          type="password" 
                          id="confirm-password" 
                          name="confirm-password" 
                          className="w-full px-4 py-2 border border-border-light rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                        />
                      </div>
                      <button 
                        type="submit" 
                        className="w-full px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors"
                      >
                        修改密码
                      </button>
                    </form>
                  </div>
                  
                  {/* 账号绑定 */}
                  <div className={`${styles.cardGradient} rounded-xl p-6 shadow-card`}>
                    <h3 className="font-semibold text-text-primary mb-4">账号绑定</h3>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between p-3 bg-bg-secondary rounded-lg">
                        <div className="flex items-center space-x-3">
                          <i className="fab fa-github text-2xl text-text-secondary"></i>
                          <div>
                            <div className="font-medium text-text-primary">GitHub</div>
                            <div className="text-sm text-text-secondary">zhangstudent</div>
                          </div>
                        </div>
                        <button 
                          onClick={handleUnbindAccount}
                          className="px-4 py-2 bg-danger text-white rounded-lg hover:bg-danger/90 transition-colors text-sm"
                        >
                          解绑
                        </button>
                      </div>
                      
                      <div className="flex items-center justify-between p-3 bg-bg-secondary rounded-lg">
                        <div className="flex items-center space-x-3">
                          <i className="fab fa-weixin text-2xl text-success"></i>
                          <div>
                            <div className="font-medium text-text-primary">微信</div>
                            <div className="text-sm text-text-secondary">已绑定</div>
                          </div>
                        </div>
                        <button 
                          onClick={handleUnbindAccount}
                          className="px-4 py-2 bg-danger text-white rounded-lg hover:bg-danger/90 transition-colors text-sm"
                        >
                          解绑
                        </button>
                      </div>
                      
                      <div className="flex items-center justify-between p-3 bg-bg-secondary rounded-lg">
                        <div className="flex items-center space-x-3">
                          <i className="fas fa-envelope text-2xl text-text-secondary"></i>
                          <div>
                            <div className="font-medium text-text-primary">邮箱</div>
                            <div className="text-sm text-text-secondary">zhangstudent@example.com</div>
                          </div>
                        </div>
                        <button 
                          onClick={handleChangeAccount}
                          className="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors text-sm"
                        >
                          更换
                        </button>
                      </div>
                      
                      <div className="flex items-center justify-between p-3 bg-bg-secondary rounded-lg">
                        <div className="flex items-center space-x-3">
                          <i className="fas fa-phone text-2xl text-text-secondary"></i>
                          <div>
                            <div className="font-medium text-text-primary">手机号</div>
                            <div className="text-sm text-text-secondary">138****5678</div>
                          </div>
                        </div>
                        <button 
                          onClick={handleChangeAccount}
                          className="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors text-sm"
                        >
                          更换
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </section>
          </div>
        </main>
      </div>
    </div>
  );
};

export default UserProfilePage;

