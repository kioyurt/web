import { createBrowserRouter, Navigate, Outlet, useLocation } from 'react-router-dom';
import { useEffect } from 'react';
import { ErrorBoundary } from '../components/ErrorBoundary';

import P_home from '../pages/p-home';
import P_login from '../pages/p-login';
import P_register from '../pages/p-register';
import P_course_list from '../pages/p-course_list';
import P_course_detail from '../pages/p-course_detail';
import P_course_learn from '../pages/p-course_learn';
import P_user_profile from '../pages/p-user_profile';
import P_community_overview from '../pages/p-community_overview';
import P_discussion_forum from '../pages/p-discussion_forum';
import P_question_answer from '../pages/p-question_answer';
import P_study_group_list from '../pages/p-study_group_list';
import P_study_group_detail from '../pages/p-study_group_detail';
import P_resource_center from '../pages/p-resource_center';
import P_model_library from '../pages/p-model_library';
import P_tool_collection from '../pages/p-tool_collection';
import P_industry_news from '../pages/p-industry_news';
import P_resource_download from '../pages/p-resource_download';
import P_search_results from '../pages/p-search_results';
import NotFoundPage from './NotFoundPage';
import ErrorPage from './ErrorPage';

function Listener() {
  const location = useLocation();
  useEffect(() => {
    const pageId = 'P-' + location.pathname.replace('/', '').toUpperCase();
    console.log('当前pageId:', pageId, ', pathname:', location.pathname, ', search:', location.search);
    if (typeof window === 'object' && window.parent && window.parent.postMessage) {
      window.parent.postMessage({
        type: 'chux-path-change',
        pageId: pageId,
        pathname: location.pathname,
        search: location.search,
      }, '*');
    }
  }, [location]);

  return <Outlet />;
}

// 使用 createBrowserRouter 创建路由实例
const router = createBrowserRouter([
  {
    path: '/',
    element: <Listener />,
    children: [
      {
    path: '/',
    element: <Navigate to='/home' replace={true} />,
  },
      {
    path: '/home',
    element: (
      <ErrorBoundary>
        <P_home />
      </ErrorBoundary>
    ),
    errorElement: <ErrorPage />,
  },
      {
    path: '/login',
    element: (
      <ErrorBoundary>
        <P_login />
      </ErrorBoundary>
    ),
    errorElement: <ErrorPage />,
  },
      {
    path: '/register',
    element: (
      <ErrorBoundary>
        <P_register />
      </ErrorBoundary>
    ),
    errorElement: <ErrorPage />,
  },
      {
    path: '/course-list',
    element: (
      <ErrorBoundary>
        <P_course_list />
      </ErrorBoundary>
    ),
    errorElement: <ErrorPage />,
  },
      {
    path: '/course-detail',
    element: (
      <ErrorBoundary>
        <P_course_detail />
      </ErrorBoundary>
    ),
    errorElement: <ErrorPage />,
  },
      {
    path: '/course-learn',
    element: (
      <ErrorBoundary>
        <P_course_learn />
      </ErrorBoundary>
    ),
    errorElement: <ErrorPage />,
  },
      {
    path: '/user-profile',
    element: (
      <ErrorBoundary>
        <P_user_profile />
      </ErrorBoundary>
    ),
    errorElement: <ErrorPage />,
  },
      {
    path: '/community-overview',
    element: (
      <ErrorBoundary>
        <P_community_overview />
      </ErrorBoundary>
    ),
    errorElement: <ErrorPage />,
  },
      {
    path: '/discussion-forum',
    element: (
      <ErrorBoundary>
        <P_discussion_forum />
      </ErrorBoundary>
    ),
    errorElement: <ErrorPage />,
  },
      {
    path: '/question-answer',
    element: (
      <ErrorBoundary>
        <P_question_answer />
      </ErrorBoundary>
    ),
    errorElement: <ErrorPage />,
  },
      {
    path: '/study-group-list',
    element: (
      <ErrorBoundary>
        <P_study_group_list />
      </ErrorBoundary>
    ),
    errorElement: <ErrorPage />,
  },
      {
    path: '/study-group-detail',
    element: (
      <ErrorBoundary>
        <P_study_group_detail />
      </ErrorBoundary>
    ),
    errorElement: <ErrorPage />,
  },
      {
    path: '/resource-center',
    element: (
      <ErrorBoundary>
        <P_resource_center />
      </ErrorBoundary>
    ),
    errorElement: <ErrorPage />,
  },
      {
    path: '/model-library',
    element: (
      <ErrorBoundary>
        <P_model_library />
      </ErrorBoundary>
    ),
    errorElement: <ErrorPage />,
  },
      {
    path: '/tool-collection',
    element: (
      <ErrorBoundary>
        <P_tool_collection />
      </ErrorBoundary>
    ),
    errorElement: <ErrorPage />,
  },
      {
    path: '/industry-news',
    element: (
      <ErrorBoundary>
        <P_industry_news />
      </ErrorBoundary>
    ),
    errorElement: <ErrorPage />,
  },
      {
    path: '/resource-download',
    element: (
      <ErrorBoundary>
        <P_resource_download />
      </ErrorBoundary>
    ),
    errorElement: <ErrorPage />,
  },
      {
    path: '/search-results',
    element: (
      <ErrorBoundary>
        <P_search_results />
      </ErrorBoundary>
    ),
    errorElement: <ErrorPage />,
  },
      {
    path: '*',
    element: <NotFoundPage />,
  },
    ]
  }
]);

export default router;